#!/usr/bin/env bash
# Print a link that signs one browser in to the app, once, within 15 minutes. Run ON the computer, as root.
#   bash sign-in-link.sh you@example.com [--setup]
# For when Google sign-in is not set up or not working. The address must already have an account, or
# be invited (or in ALLOWED_EMAILS). Nobody can sign in this way before the owner exists: a fresh
# Bot HQ is set up with setup-link.sh. With --setup, the link goes on to the rest of the setup wizard
# (for an owner the installer made in the terminal). The key it uses never leaves this machine.
set -euo pipefail
email="${1:?usage: sign-in-link.sh <email> [--setup]}"
then=""; [ "${2:-}" != "--setup" ] || then="?then=setup"
ENV_FILE="${ENV_FILE:-/opt/hq/app/.env}"
val() { grep -E "^$1=" "$ENV_FILE" | tail -1 | cut -d= -f2-; }
key="$(printf 'owner-login' | openssl dgst -sha256 -hmac "$(val SESSION_SECRET)" -r | cut -d' ' -f1)"
url="$(curl -fsS -X POST "http://127.0.0.1:$(val PORT)/api/auth/owner" \
  -H "authorization: Bearer $key" -H 'content-type: application/json' \
  -d "{\"email\":\"$email\",\"link\":true}" | sed -E 's/.*"url":"([^"]+)".*/\1/')"
# In a terminal: the link highlighted on a line of its own, easy to select. Anywhere else, or with
# NO_COLOR or TERM=dumb: the link alone, for whatever reads it.
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && [ "${TERM:-dumb}" != dumb ] && [ -n "$url" ]; then
  d=$'\033[38;5;245m' n=$'\033[0m' hl=$'\033[48;5;208m\033[38;5;234m\033[1m'
  case "${COLORTERM:-}" in truecolor|24bit) d=$'\033[38;2;139;145;141m' hl=$'\033[48;2;253;127;1m\033[38;2;20;23;22m\033[1m' ;; esac
  printf '\n  Open this in your browser to sign in as %s:\n\n    %s %s %s\n\n' "$email" "$hl" "$url$then" "$n"
  printf '  %sIt works once, within 15 minutes.%s\n\n' "$d" "$n"
  exit 0
fi
echo "$url$then"
