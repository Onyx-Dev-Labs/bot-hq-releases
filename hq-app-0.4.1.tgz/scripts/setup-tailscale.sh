#!/usr/bin/env bash
# Put Bot HQ's computer on the owner's Tailscale network: a private network that links their
# computers wherever they are. Bot HQ needs it to reach coding machines behind people's routers, and
# helpers on those machines use it to reach Bot HQ. Run ON that computer, as root. Bot HQ runs it
# itself (Settings, Setup and health); it can also be run by hand.
#
#   setup-tailscale.sh --status [--port 8787]
#       Change nothing. Say whether Tailscale is here, running and logged in.
#   setup-tailscale.sh --join [--name bot-hq] [--port 8787] < key-on-standard-input
#       Install Tailscale if it is missing, keep it running under supervisor, and join the network
#       with the auth key. The key is read from standard input and handed to tailscale the same way,
#       so it is never an argument (not in the process list), never in a file, and never printed.
#   setup-tailscale.sh --serve [--port 8787]
#       Bot HQ's own computer only, once it is on the network: serve the app (127.0.0.1:<port>) at
#       this computer's private address, https://<name>.<tailnet>.ts.net, with `tailscale serve` on
#       port 443. A port 443 that already serves something else is left exactly as it is. Prints
#       private_url. Never a Funnel: the address is reachable on the private network only.
#
# Safe to run again. A computer that is already on the network is left exactly as it is, and
# Tailscale is never reinstalled or upgraded over an existing copy. The computer has no systemd and
# no tun device, so tailscaled runs under supervisor in userspace mode, with an HTTP and SOCKS5 proxy
# on 127.0.0.1:1055 that Bot HQ uses to reach the network.
#
# The last lines are key=value, for Bot HQ to read: result (already, started, joined, status or
# failed), state (Tailscale's own: Running, NeedsLogin, NeedsMachineAuth, Stopped..., or NotInstalled,
# NotRunning), name, dns, address, logged_in, key_expired, key_expiry, proxy, fleet_url, private_url
# (after --serve; result served or already), error, message,
# and four that say how programs on this computer reach the network: userspace (yes when tailscaled
# runs without a network device), socks5 (its SOCKS5 proxy's address, if it has one), cli (the
# tailscale command) and socket (the running tailscaled's socket, only when it is not the usual one),
# which `tailscale nc` needs when tailscaled has no proxy. Bot HQ's setup of a teammate's computer
# reads those; on Bot HQ's own computer they change nothing.
set -uo pipefail

TS_VERSION="${TS_VERSION:-1.104.7}"
TS_DIR=/opt/tailscale
TS_LINK=/usr/local/bin/tailscale
STATE_DIR=/var/lib/tailscale
RUN_DIR=/var/run/tailscale
LOG_DIR=/var/log/tailscale
DEFAULT_SOCK="$RUN_DIR/tailscaled.sock"
CONF=/etc/supervisor/conf.d/tailscaled.conf

# Checksums of Tailscale's static builds for the version above, as published beside each download
# (<file>.sha256). Kept here so a download is checked against a value fixed in this repo; another
# version (TS_VERSION) is checked against the published file instead.
pinned_sha256() {
  case "$1" in
    1.104.7_amd64) echo e56693ff74a64f2591b7e819c280635a100aae1ddfb0ef058fcd052b7cd8d16c ;;
    1.104.7_arm64) echo d6bed2720310b328b861f943d7b4016c5358a9bad60575eb51e8143b79068484 ;;
    *) echo "" ;;
  esac
}

mode=""
want_name="bot-hq"
port="8787"
while [ $# -gt 0 ]; do
  case "$1" in
    --status) mode="status" ;;
    --join) mode="join" ;;
    --serve) mode="serve" ;;
    --name) want_name="${2:-}"; shift ;;
    --port) port="${2:-}"; shift ;;
    *) echo "usage: setup-tailscale.sh --status|--join|--serve [--name NAME] [--port PORT]" >&2; exit 2 ;;
  esac
  shift
done
[ -n "$mode" ] || { echo "usage: setup-tailscale.sh --status|--join|--serve [--name NAME] [--port PORT]" >&2; exit 2; }

# The key comes first, before anything else can read standard input.
key=""
if [ "$mode" = join ]; then
  IFS= read -r key || true
  key="${key//[$'\r\t ']/}"
fi

# ---------- reporting ----------

result=""; state=""; name=""; dns=""; address=""; logged_in="no"; key_expired="no"; key_expiry=""
proxy=""; fleet_url=""; error=""; message=""; cli=""; sock="$DEFAULT_SOCK"; userspace="no"; socks5=""; private_url=""

# One line of text, never holding the key, short enough to show.
clean() {
  local s="$1"
  if [ -n "$key" ]; then s="${s//"$key"/[key hidden]}"; fi
  s="${s//$'\n'/ }"; s="${s//$'\r'/ }"
  printf '%s' "${s:0:400}"
}

report() {
  printf 'result=%s\n' "$result"
  printf 'state=%s\n' "$state"
  printf 'name=%s\n' "$name"
  printf 'dns=%s\n' "$dns"
  printf 'address=%s\n' "$address"
  printf 'logged_in=%s\n' "$logged_in"
  printf 'key_expired=%s\n' "$key_expired"
  printf 'key_expiry=%s\n' "$key_expiry"
  printf 'proxy=%s\n' "$proxy"
  printf 'fleet_url=%s\n' "$fleet_url"
  printf 'private_url=%s\n' "$private_url"
  printf 'userspace=%s\n' "$userspace"
  printf 'socks5=%s\n' "$socks5"
  printf 'cli=%s\n' "$cli"
  if [ "$sock" != "$DEFAULT_SOCK" ]; then printf 'socket=%s\n' "$sock"; else printf 'socket=\n'; fi
  printf 'error=%s\n' "$error"
  printf 'message=%s\n' "$(clean "$message")"
}

fail() {
  result=failed; error="$1"; message="$2"
  report
  exit 1
}

# ---------- what is here now ----------

find_cli() {
  if [ -x "$TS_LINK" ]; then echo "$TS_LINK"
  elif [ -x "$TS_DIR/tailscale" ]; then echo "$TS_DIR/tailscale"
  elif command -v tailscale >/dev/null 2>&1; then command -v tailscale
  fi
}

# The running tailscaled's command line, if there is one (the first word ends in /tailscaled).
daemon_args() {
  ps -eo args= 2>/dev/null | awk '{ n = split($1, p, "/"); if (p[n] == "tailscaled") { print; exit } }'
}

# The value of a --flag=value or --flag value in a command line.
flag_value() {
  printf '%s\n' "$1" | sed -n -E "s/.*--$2[= ]([^ ]+).*/\\1/p" | head -n1
}

# A field of `tailscale status --json`, without jq (the computer may not have it). With
# --peers=false the only node in the output is this one, so each field name appears once.
json_string() { printf '%s\n' "$1" | sed -n -E "s/^[[:space:]]*\"$2\": \"([^\"]*)\".*/\\1/p" | head -n1; }
json_bool() { printf '%s\n' "$1" | sed -n -E "s/^[[:space:]]*\"$2\": (true|false).*/\\1/p" | head -n1; }

read_status() {
  cli="$(find_cli)"
  name=""; dns=""; address=""; logged_in="no"; key_expired="no"; key_expiry=""; proxy=""; fleet_url=""; userspace="no"; socks5=""
  local args; args="$(daemon_args)"
  sock="$(flag_value "$args" socket)"; [ -n "$sock" ] || sock="$DEFAULT_SOCK"
  if [ -z "$cli" ]; then state=NotInstalled; return; fi
  if [ -z "$args" ]; then state=NotRunning; return; fi
  case "$args" in *userspace-networking*) userspace=yes; socks5="$(flag_value "$args" socks5-server)" ;; esac
  local json
  if ! json="$("$cli" --socket="$sock" status --json --peers=false 2>/dev/null)"; then state=NotRunning; return; fi
  state="$(json_string "$json" BackendState)"; [ -n "$state" ] || state=Unknown
  dns="$(json_string "$json" DNSName)"; dns="${dns%.}"
  name="${dns%%.*}"; [ -n "$name" ] || name="$(json_string "$json" HostName)"
  [ "$(json_bool "$json" Expired)" = true ] && key_expired=yes
  key_expiry="$(json_string "$json" KeyExpiry)"
  [ "$state" = Running ] && logged_in=yes
  address="$("$cli" --socket="$sock" ip -4 2>/dev/null | head -n1)"
  # Without a network device, the proxy is the only way out to the network; with one, nothing is needed.
  local listen; listen="$(flag_value "$args" outbound-http-proxy-listen)"
  case "$args" in
    *userspace-networking*) [ -z "$listen" ] || proxy="http://$listen" ;;
  esac
  if [ "$logged_in" = yes ] && [ -n "$name" ]; then fleet_url="http://$name:$port"; fi
}

# ---------- putting it in place ----------

install_tailscale() {
  # Any copy already here is kept as it is: this script never upgrades Tailscale.
  if [ -x "$TS_DIR/tailscaled" ] && [ -x "$TS_DIR/tailscale" ]; then return 0; fi
  local arch
  case "$(uname -m)" in
    x86_64|amd64) arch=amd64 ;;
    aarch64|arm64) arch=arm64 ;;
    *) fail unsupported "This computer’s processor ($(uname -m)) is not one this script installs Tailscale for." ;;
  esac
  local file="tailscale_${TS_VERSION}_${arch}.tgz"
  local url="https://pkgs.tailscale.com/stable/$file"
  local tmp; tmp="$(mktemp -d)" || fail no_space "Could not make a folder to download Tailscale into."
  # shellcheck disable=SC2064 # expand now: the folder is known now, and only this one is removed
  trap "rm -rf '$tmp'" EXIT
  curl -fsSL --retry 2 --max-time 300 -o "$tmp/$file" "$url" \
    || fail no_network "Could not download Tailscale from pkgs.tailscale.com. Check this computer’s internet connection."
  local want; want="$(pinned_sha256 "${TS_VERSION}_${arch}")"
  if [ -z "$want" ]; then
    want="$(curl -fsSL --max-time 60 "$url.sha256" | tr -d '[:space:]')" \
      || fail no_network "Could not download Tailscale’s checksum. Check this computer’s internet connection."
  fi
  local got; got="$(sha256sum "$tmp/$file" | cut -d' ' -f1)"
  if [ -z "$want" ] || [ "$got" != "$want" ]; then
    fail bad_download "The Tailscale download did not match its checksum, so it was not installed."
  fi
  tar -xzf "$tmp/$file" -C "$tmp" || fail bad_download "The Tailscale download could not be unpacked."
  local from="$tmp/tailscale_${TS_VERSION}_${arch}"
  mkdir -p "$TS_DIR"
  if ! install -m 0755 "$from/tailscaled" "$TS_DIR/tailscaled" || ! install -m 0755 "$from/tailscale" "$TS_DIR/tailscale"; then
    fail install_failed "Could not copy Tailscale into $TS_DIR."
  fi
  rm -rf "$tmp"; trap - EXIT
}

ensure_command() {
  # The tailscale command where people expect it. Left alone if anything is there already.
  if [ ! -e "$TS_LINK" ] && [ ! -L "$TS_LINK" ]; then ln -s "$TS_DIR/tailscale" "$TS_LINK"; fi
}

supervisor_entry() {
  cat <<EOF
[program:tailscaled]
command=$TS_DIR/tailscaled --tun=userspace-networking --socks5-server=127.0.0.1:1055 --outbound-http-proxy-listen=127.0.0.1:1055 --state=$STATE_DIR/tailscaled.state --socket=$DEFAULT_SOCK
autostart=true
autorestart=true
startsecs=3
stdout_logfile=$LOG_DIR/tailscaled.log
stdout_logfile_maxbytes=5MB
redirect_stderr=true
EOF
}

ensure_supervisor() {
  command -v supervisorctl >/dev/null 2>&1 || fail no_supervisor "This computer has no supervisor to keep Tailscale running."
  mkdir -p "$STATE_DIR" "$RUN_DIR" "$LOG_DIR"
  # A program supervisor already knows (from any file) is kept as it is.
  if supervisorctl status tailscaled 2>/dev/null | grep -q '^tailscaled[[:space:]]'; then return 0; fi
  if [ ! -f "$CONF" ] || [ "$(cat "$CONF")" != "$(supervisor_entry)" ]; then
    if ! supervisor_entry > "$CONF" || ! chmod 644 "$CONF"; then fail install_failed "Could not write $CONF."; fi
  fi
  # reread only loads new files; add starts this one program. Nothing else under supervisor is touched.
  supervisorctl reread >/dev/null 2>&1
  supervisorctl add tailscaled >/dev/null 2>&1 || fail install_failed "Supervisor would not add Tailscale. Its log: $LOG_DIR/tailscaled.log"
}

ensure_running() {
  if [ -z "$(daemon_args)" ]; then
    supervisorctl start tailscaled >/dev/null 2>&1 || true
  fi
  local _
  for _ in $(seq 1 30); do
    read_status
    case "$state" in NotRunning|NoState|Starting|Unknown) sleep 1 ;; *) return 0 ;; esac
  done
  fail not_running "Tailscale is installed but is not starting. Its log: $LOG_DIR/tailscaled.log"
}

# ---------- main ----------

if [ "$mode" = status ]; then
  read_status
  result=status
  report
  exit 0
fi

if [ "$mode" = serve ]; then
  read_status
  [ "$state" = Running ] || fail not_running "This computer is not on the private network yet, so it has no private address. Join first."
  [ -n "$dns" ] || fail no_name "Tailscale did not say this computer's name on the network."
  case "$port" in ""|*[!0-9]*) fail bad_port "The port must be a number." ;; esac
  target="http://127.0.0.1:$port"
  # What is served now. Ours (port 443 to the app): nothing to do. Anything else on 443: not ours to change.
  now="$("$cli" --socket="$sock" serve status --json 2>/dev/null || true)"
  compact="$(printf '%s' "$now" | tr -d '[:space:]')"
  if printf '%s' "$compact" | grep -qF "\"Proxy\":\"$target\""; then
    private_url="https://$dns"; result=already; message="The app is already served at $private_url."
    report; exit 0
  fi
  if printf '%s' "$compact" | grep -qE '"(443|:443)"|:443"'; then
    fail serve_taken "Something else is already served at this computer's private address (port 443), so Bot HQ left it alone. Serve the app by hand: tailscale serve --bg --https=443 $target"
  fi
  out="$("$cli" --socket="$sock" serve --bg --https=443 "$target" 2>&1)"; rc=$?
  if [ $rc -ne 0 ]; then
    case "$out" in
      *"not enabled"*|*HTTPS*|*https*) fail serve_off "Your Tailscale network does not allow HTTPS addresses yet. In Tailscale's admin page, DNS, switch on MagicDNS and HTTPS Certificates, then try again. ($(clean "$out"))" ;;
      *) fail serve_failed "Tailscale did not serve the app (exit $rc). $(clean "$out")" ;;
    esac
  fi
  private_url="https://$dns"; result=served; message="The app is served at $private_url on the private network."
  report; exit 0
fi

read_status
if [ "$state" = Running ]; then
  result=already; message="Already on the private network as $name."
  report
  exit 0
fi

[ "$(id -u)" = 0 ] || fail not_root "This must run as root."
case "$want_name" in
  ""|-*|*[!a-z0-9-]*) fail bad_name "The name for this computer must be lower-case letters, digits and dashes." ;;
esac
case "$port" in ""|*[!0-9]*) fail bad_port "The port must be a number." ;; esac
# A key that is plainly not one is refused before anything is installed.
case "$key" in ""|tskey-*) ;; *) fail bad_key "That is not a Tailscale auth key. Auth keys start with tskey-auth-." ;; esac

install_tailscale
ensure_command
ensure_supervisor
ensure_running

# Logged in already, only not running (stopped by hand, or just restarted): bring it up as it was.
if [ "$state" = Stopped ]; then
  "$cli" --socket="$sock" up --timeout=30s >/dev/null 2>&1 || true
  read_status
fi
if [ "$state" = Running ]; then
  result=started; message="Tailscale was not running. It is now, as $name."
  report
  exit 0
fi

# Not signed in: only now is a key needed. (Starting a stopped Tailscale above needed none.)
[ -n "$key" ] || fail no_key "Tailscale is running but not signed in. Paste an auth key to join."

# Join. The key goes in on standard input (file:/dev/stdin), so it is not in tailscale's arguments.
# --reset: only the settings given here apply, so an earlier sign-in's settings cannot block this one.
out="$(printf '%s\n' "$key" | "$cli" --socket="$sock" up --reset --auth-key=file:/dev/stdin --hostname="$want_name" --timeout=90s 2>&1)"
rc=$?
read_status
if [ "$state" = Running ]; then
  result=joined; message="Joined the private network as $name."
  key=""
  report
  exit 0
fi
detail="$(clean "$out")"
key=""
case "$state:$detail" in
  NeedsMachineAuth:*) fail needs_approval "Tailscale needs this computer approved: open Machines in Tailscale’s admin page and approve $want_name, or use a key with Pre-approved switched on." ;;
  *[Ee]xpired*) fail key_expired "That auth key has expired. Make a new one." ;;
  *"invalid key"*|*"not valid"*|*"does not exist"*|*"unable to validate"*|*"revoked"*) fail bad_key "Tailscale did not accept that auth key. Make a new one and paste it whole: it starts with tskey-auth-." ;;
  *timeout*|*"context deadline"*|*"no such host"*|*"connection refused"*) fail no_network "Tailscale could not reach its servers. Check this computer’s internet connection. ($detail)" ;;
  *) fail join_failed "Tailscale did not join (exit $rc, state ${state:-unknown}). $detail" ;;
esac
