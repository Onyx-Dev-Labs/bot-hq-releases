#!/usr/bin/env bash
# The older way to install from a pack copied to the computer, kept so it still works:
#
#   PUBLIC_URL=https://<name>-xxxx.web.orgo.dev bash install-on-computer.sh hq-app.tgz
#
# All the steps live in scripts/install.sh; this runs the copy inside the pack, so the steps always
# match the code being installed. Same as: bash install.sh --file hq-app.tgz [--url ...]
set -euo pipefail
tgz="${1:?usage: install-on-computer.sh <hq-app.tgz>}"
shift
tmp="$(mktemp -d "${TMPDIR:-/tmp}/hq-install-on-computer.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
tar -xzf "$tgz" -C "$tmp" scripts/install.sh 2>/dev/null ||
  { echo "$tgz has no scripts/install.sh. Make a new pack with scripts/release.sh (or scripts/pack.sh)." >&2; exit 1; }
bash "$tmp/scripts/install.sh" --file "$tgz" "$@"
