#!/usr/bin/env python3
"""Give the main Hermes agent the app's tools: add the `hq` MCP server to its config.yaml.

Run on the computer, after install-on-computer.sh:
    python3 add-hq-to-hermes.py [--config /root/.hermes/config.yaml] [--entry /opt/hq/data/hermes-mcp-hq.yaml] [--remove]

The edit is plain text (the file's comments and layout stay as they are), a dated copy of the file
is kept next to it, and the result is checked before it replaces the original: every other setting
must read back exactly as before. Hermes notices the change by itself; no restart. The Bot HQ
installer runs this itself on a new computer.

The check reads the file with PyYAML (Hermes's own Python has it). Where PyYAML is missing, a check
of the text stands in: it allows the edit only to a file whose layout leaves no doubt (no tabs,
block scalars, anchors, flow style or second document, and entries under mcp_servers indented by
two spaces), and checks that every other line is kept exactly as it was.
"""
import argparse, os, re, shutil, sys, time

p = argparse.ArgumentParser()
p.add_argument('--config', default='/root/.hermes/config.yaml')
p.add_argument('--entry', default='/opt/hq/data/hermes-mcp-hq.yaml')
p.add_argument('--remove', action='store_true')
a = p.parse_args()

try:
    import yaml
except ImportError:
    yaml = None

old = open(a.config, encoding='utf-8').read()
lines = old.split('\n')
block = [l for l in open(a.entry, encoding='utf-8').read().split('\n') if l.strip() and not l.lstrip().startswith('#')]

def section():
    """Line range (start, end) of the top-level mcp_servers mapping, or None."""
    for i, l in enumerate(lines):
        if re.match(r'^mcp_servers:\s*(#.*)?$', l):
            j = i + 1
            while j < len(lines) and (not lines[j].strip() or lines[j][0] in ' \t#'):
                j += 1
            return i, j
    return None

def hq_range(s, e):
    """Line range of an existing `hq:` entry inside the section, or None."""
    for i in range(s + 1, e):
        if re.match(r'^  hq:\s*(#.*)?$', lines[i]):
            j = i + 1
            while j < e and (not lines[j].strip() or re.match(r'^(   +|\t)', lines[j])):
                j += 1
            while j > i + 1 and not lines[j - 1].strip():
                j -= 1
            return i, j
    return None

sec = section()
if sec:
    had = hq_range(*sec)
    if had:
        del lines[had[0]:had[1]]
    if not a.remove:
        lines[sec[0] + 1:sec[0] + 1] = block
elif not a.remove:
    if re.search(r'^mcp_servers:', old, re.M):
        sys.exit('mcp_servers is written in a form this script does not edit; add the entry by hand.')
    if lines and lines[-1].strip():
        lines.append('')
    lines += ['mcp_servers:'] + block + ['']
new = '\n'.join(lines)
if new == old:
    print('nothing to change'); sys.exit(0)

def text_check():
    """Without PyYAML: the edit must be one whose meaning is plain from the text alone."""
    old_lines = old.split('\n')
    for i, l in enumerate(old_lines):
        if re.match(r'^\s*\t', l):
            sys.exit('refusing: the file is indented with tabs; add the entry by hand (or run this with the Python Hermes uses)')
        body = re.sub(r'(^|\s+)#.*$', '', l)
        tricky = (re.search(r':\s*[|>][-+0-9]*\s*$', body)          # a block scalar
                  or re.search(r'(^|[\s:-])[&*][A-Za-z0-9_-]+', body)  # an anchor or alias
                  or re.match(r'^\s*<<\s*:', body)                    # a merge key
                  or (re.match(r'^(---|\.\.\.)(\s|$)', l) and i > 0))  # a second document
        if tricky:
            sys.exit('refusing: the file uses YAML this check cannot follow without PyYAML; add the entry by hand (or run this with the Python Hermes uses)')
    if re.search(r'^mcp_servers:\s*[\[{]', old, re.M):
        sys.exit('refusing: mcp_servers is written in a form this script does not edit; add the entry by hand.')
    start = next((i for i, l in enumerate(old_lines) if re.match(r'^mcp_servers:\s*(#.*)?$', l)), None)
    if start is not None:
        kids = []
        for l in old_lines[start + 1:]:
            if l.strip() and l[0] not in ' \t#':
                break
            if l.strip() and not l.lstrip().startswith('#'):
                kids.append(l)
        if kids and not re.match(r'^  \S', kids[0]):
            sys.exit('refusing: the entries under mcp_servers are not indented by two spaces; add the entry by hand.')
    # Every line of the file, other than the hq entry, is kept as it was and in the same order.
    def without_hq(ls):
        out, skip = [], False
        for l in ls:
            if re.match(r'^  hq:\s*(#.*)?$', l):
                skip = True; continue
            if skip and (not l.strip() or re.match(r'^(   +|\t)', l)):
                continue
            skip = False; out.append(l)
        return [l for l in out if l.strip()]
    added = [l for l in without_hq(new.split('\n')) if l.strip() != 'mcp_servers:' or 'mcp_servers:' in old]
    if [l for l in without_hq(old_lines)] != added:
        sys.exit('refusing: the edit would change other settings')
    has_hq = any(re.match(r'^  hq:\s*(#.*)?$', l) for l in new.split('\n'))
    if a.remove and has_hq:
        sys.exit('refusing: hq is still there')
    if not a.remove:
        entry = '\n'.join(block)
        if not (re.search(r'^    url: https?://\S+$', entry, re.M) and re.search(r'^      Authorization: Bearer \S+$', entry, re.M)):
            sys.exit('refusing: the hq entry did not read back correctly')

if yaml is None:
    text_check()
    checked = 'checked as text: PyYAML is not installed for this Python'
else:
    before, after = yaml.safe_load(old) or {}, yaml.safe_load(new) or {}
    b_servers, a_servers = dict(before.get('mcp_servers') or {}), dict(after.get('mcp_servers') or {})
    b_servers.pop('hq', None); hq = a_servers.pop('hq', None)
    rest = lambda d: {k: v for k, v in d.items() if k != 'mcp_servers'}
    if rest(before) != rest(after) or b_servers != a_servers:
        sys.exit('refusing: the edit would change other settings')
    if a.remove and hq is not None:
        sys.exit('refusing: hq is still there')
    if not a.remove and not (isinstance(hq, dict) and str(hq.get('url', '')).startswith('http') and 'Authorization' in (hq.get('headers') or {})):
        sys.exit('refusing: the hq entry did not read back correctly')
    checked = 'checked with PyYAML'

backup = f"{a.config}.before-hq-{time.strftime('%Y%m%d-%H%M%S')}"
shutil.copy2(a.config, backup)
tmp = a.config + '.hq-tmp'
with open(tmp, 'w', encoding='utf-8') as f:
    f.write(new)
shutil.copymode(a.config, tmp)
st = os.stat(a.config); os.chown(tmp, st.st_uid, st.st_gid)
os.replace(tmp, a.config)
print(('removed hq' if a.remove else 'added hq') + f'; {checked}; previous file kept as {backup}')
