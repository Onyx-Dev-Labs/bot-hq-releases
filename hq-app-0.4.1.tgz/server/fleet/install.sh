#!/usr/bin/env bash
# Install the Bot HQ helper on a coding machine. Run it on that machine, as the person T3 Code runs as:
#
#   curl -fsSL <bot hq address>/fleet/install.sh | bash -s -- --server <bot hq address> --token <helper token>
#
# Optional: --t3 <the T3 Code command, default "t3">  --t3-home <its data folder, when it is not the default>
#           --base-url <this machine's T3 Code address on the private network>  --name <what to call it in Bot HQ>
#
# Or, with a one-time claim from Bot HQ in place of the token (helper version 9; Bot HQ's one-line
# machine command and its built-in machine use this): the helper redeems the claim and gets its own
# token, and Bot HQ makes its own access to T3 Code here. Nobody types a pairing code.
#
#   ... | bash -s -- --server <bot hq address> --claim <claim> --base-url <T3 Code address> [--name <name>]
# It needs Node 20 or later (T3 Code needs it too); passing a key on to a coding bot needs Node 22 or later.
#
# One helper can serve more than one Bot HQ. Running the setup command of another Bot HQ on a machine
# that has the helper already adds that Bot HQ to it; the ones it serves keep working as they were.
# Running the same Bot HQ's command again replaces that Bot HQ's token only.
#
# To remove it: bash install.sh --remove            (everything: the helper and every Bot HQ it serves)
#               bash install.sh --remove --server <bot hq address>   (that one Bot HQ; the others stay)
# To update an installed helper to the newest one its Bot HQs serve, keeping its tokens and settings:
#
#   curl -fsSL <bot hq address>/fleet/install.sh | bash -s -- --update
set -euo pipefail
server=""; token=""; claim=""; baseurl=""; name=""; t3="t3"; t3given=0; t3home=""; remove=0; update=0
while [ $# -gt 0 ]; do
  case "$1" in
    --server) server="${2%/}"; shift 2;; --token) token="$2"; shift 2;; --t3) t3="$2"; t3given=1; shift 2;; --t3-home) t3home="$2"; shift 2;;
    --claim) claim="$2"; shift 2;; --base-url) baseurl="${2%/}"; shift 2;; --name) name="$2"; shift 2;;
    --remove) remove=1; shift;; --update) update=1; shift;; *) echo "unknown option: $1" >&2; exit 2;;
  esac
done
dir="$HOME/.bothq-helper"; label="io.bothq.helper"
plist="$HOME/Library/LaunchAgents/$label.plist"
# BOTHQ_HELPER_NO_SCHEDULE=1 leaves the system's schedule alone (for trying the installer out).
schedule() { [ "${BOTHQ_HELPER_NO_SCHEDULE:-}" != 1 ]; }
find_cmd() { command -v "$1" 2>/dev/null || true; }
config_node() { local n; n="$(sed -n 's/.*"node": *"\([^"]*\)".*/\1/p' "$dir/config.json" 2>/dev/null | head -1)"; [ -x "$n" ] && echo "$n" || find_cmd node; }
# The Bot HQs in the config, one address per line (a config from before there could be more has one).
servers_of() { "$1" -e 'const c = require(process.argv[1]); for (const s of Array.isArray(c.servers) ? c.servers : [c]) if (s && s.server) console.log(String(s.server).replace(/\/+$/, ""))' "$dir/config.json"; }
# The version a helper file says it is (0 when it says nothing).
version_of() { sed -n "s/^const VERSION = '\([0-9]*\)';.*/\1/p" "$1" 2>/dev/null | head -1 | grep . || echo 0; }

remove_all() {
  if schedule; then
    if [ "$(uname)" = Darwin ]; then launchctl bootout "gui/$(id -u)/$label" 2>/dev/null || true; rm -f "$plist"
    else systemctl --user disable --now bothq-helper.timer 2>/dev/null || true; rm -f "$HOME/.config/systemd/user/bothq-helper."{service,timer}; fi
  fi
  rm -rf "$dir"
}

if [ "$remove" = 1 ]; then
  if [ -z "$server" ] || [ ! -f "$dir/config.json" ]; then remove_all; echo "Bot HQ helper removed."; exit 0; fi
  node="$(config_node)"
  served="$(servers_of "$node")"
  case $'\n'"$served"$'\n' in *$'\n'"$server"$'\n'*) ;; *) echo "This helper does not serve $server. It serves: $(echo $served)" >&2; exit 1;; esac
  if [ "$served" = "$server" ]; then remove_all; echo "Bot HQ helper removed (it served only $server)."; exit 0; fi
  umask 077
  BOTHQ_SERVER="$server" "$node" -e '
    const fs = require("fs"); const file = process.argv[1]; const gone = process.env.BOTHQ_SERVER;
    const c = JSON.parse(fs.readFileSync(file, "utf8"));
    const left = (Array.isArray(c.servers) ? c.servers : [{ server: c.server, token: c.token, ...(c.label ? { label: c.label } : {}) }]).filter((s) => String(s.server).replace(/\/+$/, "") !== gone);
    delete c.server; delete c.token; delete c.servers; delete c.label; delete c.by;
    // One left: back to the shape of a helper serving one Bot HQ.
    const out = left.length === 1 ? { ...left[0], ...c } : { servers: left, ...c };
    fs.writeFileSync(file + ".new", JSON.stringify(out, null, 2) + "\n", { mode: 0o600 }); fs.renameSync(file + ".new", file);
    // What the helper kept for that Bot HQ (its links) goes too. Sign-ins it added stay on the machine.
    try { const sf = require("path").join(require("path").dirname(file), "state.json"); const s = JSON.parse(fs.readFileSync(sf, "utf8")); if (s.links) delete s.links[gone]; fs.writeFileSync(sf, JSON.stringify(s, null, 2) + "\n", { mode: 0o600 }); } catch {}
  ' "$dir/config.json"
  echo "Bot HQ helper no longer serves $server. It still serves: $(servers_of "$node" | tr '\n' ' ')"; exit 0
fi

if [ "$update" = 1 ]; then
  [ -f "$dir/config.json" ] || { echo "No helper is installed here. Set it up from Bot HQ first." >&2; exit 1; }
  node="$(config_node)"
  umask 077
  # Each Bot HQ it serves may serve a different helper: the newest wins, and it is never replaced by an older one.
  have="$(version_of "$dir/helper.mjs")"; best=""; bestv="$have"
  for s in ${server:-$(servers_of "$node")}; do
    if curl -fsSL "${s%/}/fleet/helper.mjs" -o "$dir/helper.mjs.new" 2>/dev/null && head -1 "$dir/helper.mjs.new" | grep -q '^#!/usr/bin/env node'; then
      v="$(version_of "$dir/helper.mjs.new")"
      if [ "$v" -gt "$bestv" ]; then mv "$dir/helper.mjs.new" "$dir/helper.mjs.best"; best="$s"; bestv="$v"; fi
    else echo "Could not download the helper from $s." >&2; fi
    rm -f "$dir/helper.mjs.new"
  done
  if [ -n "$best" ]; then mv "$dir/helper.mjs.best" "$dir/helper.mjs"; echo "Updated the helper from version $have to $bestv (from $best)."
  else echo "The helper here (version $have) is already the newest its Bot HQs serve."; fi
  "$node" "$dir/helper.mjs" || { echo "The helper's round failed for at least one Bot HQ. See the messages above." >&2; exit 1; }
  echo "Bot HQ helper updated. It keeps checking in every 5 minutes, and looks in every 30 seconds for anything that cannot wait."; exit 0
fi

[ -n "$server" ] && { [ -n "$token" ] || [ -n "$claim" ]; } || { echo "usage: install.sh --server <bot hq address> --token <helper token>   (or --claim <claim>)" >&2; exit 2; }
node="$(find_cmd node)"
[ -n "$node" ] || { echo "Node was not found on this machine. Install Node 20 or later and run this again." >&2; exit 1; }
"$node" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 20 ? 0 : 1)' || { echo "Node 20 or later is needed (found $("$node" -v))." >&2; exit 1; }

umask 077
mkdir -p "$dir"
# A helper here already: this Bot HQ is added to it (or, if it is one it serves, given its new token).
adding=0; [ -f "$dir/config.json" ] && adding=1
curl -fsSL "${server%/}/fleet/helper.mjs" -o "$dir/helper.mjs.new"
head -1 "$dir/helper.mjs.new" | grep -q '^#!/usr/bin/env node' || { rm -f "$dir/helper.mjs.new"; echo "That did not download the helper. Check the address." >&2; exit 1; }
# Never an older helper in place of a newer one another Bot HQ installed.
if [ "$adding" = 1 ] && [ -f "$dir/helper.mjs" ] && [ "$(version_of "$dir/helper.mjs.new")" -lt "$(version_of "$dir/helper.mjs")" ]; then rm -f "$dir/helper.mjs.new"
else mv "$dir/helper.mjs.new" "$dir/helper.mjs"; fi
[ "$adding" = 1 ] && cp "$dir/config.json" "$dir/config.json.before"

# A claim in place of a token: redeem it at Bot HQ for this helper's own token. It names this machine
# by its T3 Code environment id, which T3 Code writes when it first starts. The token is never printed.
label=""
if [ -z "$token" ] && [ -n "$claim" ]; then
  envfile="${t3home:-$HOME/.t3}/userdata/environment-id"
  for _ in $(seq 1 "${BOTHQ_ENV_WAIT:-60}"); do [ -s "$envfile" ] && break; sleep 1; done
  [ -s "$envfile" ] || { echo "T3 Code here has not started yet (no $envfile). Start it, then run this again with a new claim from Bot HQ." >&2; exit 1; }
  redeemed="$(BOTHQ_SERVER="$server" BOTHQ_CLAIM="$claim" BOTHQ_ENV="$(head -1 "$envfile")" BOTHQ_NAME="${name:-$(hostname -s 2>/dev/null || hostname)}" BOTHQ_BASE_URL="$baseurl" "$node" -e '
    const e = process.env;
    fetch(`${e.BOTHQ_SERVER}/api/fleet/claim`, { method: "POST", headers: { "content-type": "application/json" }, signal: AbortSignal.timeout(30000),
      body: JSON.stringify({ claim: e.BOTHQ_CLAIM, environmentId: e.BOTHQ_ENV.trim(), name: e.BOTHQ_NAME, baseUrl: e.BOTHQ_BASE_URL || null }) })
      .then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok || !j.token) { console.error(j.error || `Bot HQ answered ${r.status}`); process.exit(1); } console.log(`${j.token} ${j.clientName || ""}`); })
      .catch(() => { console.error("Bot HQ did not answer at that address."); process.exit(1); });
  ')" || { [ "$adding" = 1 ] && rm -f "$dir/config.json.before"; echo "The claim was not accepted. Make a new one in Bot HQ and run this again." >&2; exit 1; }
  token="${redeemed%% *}"; label="${redeemed#* }"; [ "$label" = "$redeemed" ] && label=""
fi
# Where each tool is, found now so the scheduled run does not depend on a login shell's PATH. A tool
# not found now keeps what an earlier setup found.
BOTHQ_SERVER="$server" BOTHQ_TOKEN="$token" BOTHQ_LABEL="$label" BOTHQ_BASE_URL="$baseurl" BOTHQ_NODE="$node" BOTHQ_CODEX="$(find_cmd codex)" BOTHQ_CLAUDE="$(find_cmd claude)" BOTHQ_GH="$(find_cmd gh)" \
BOTHQ_T3="$( [ "$t3given" = 1 ] || [ "$adding" = 0 ] && find_cmd "$t3" || true)" BOTHQ_T3_HOME="$t3home" \
"$node" -e '
  const fs = require("fs"); const e = process.env; const file = process.argv[1];
  let c = {}; try { c = JSON.parse(fs.readFileSync(file, "utf8")); } catch {}
  const list = Array.isArray(c.servers) ? c.servers : c.server ? [{ server: c.server, token: c.token, ...(c.label ? { label: c.label } : {}), ...(c.by ? { by: c.by } : {}) }] : [];
  const norm = (s) => String(s).replace(/\/+$/, "");
  const i = list.findIndex((s) => norm(s.server) === norm(e.BOTHQ_SERVER));
  // The name this Bot HQ registers under in T3 Code here (from a claim), so leaving can revoke its sessions.
  const entry = { server: e.BOTHQ_SERVER, token: e.BOTHQ_TOKEN, ...(e.BOTHQ_LABEL ? { label: e.BOTHQ_LABEL } : {}) };
  if (i >= 0) list[i] = entry; else list.push(entry);
  delete c.server; delete c.token; delete c.servers; delete c.label; delete c.by;
  c.node = e.BOTHQ_NODE;
  for (const [k, v] of [["codex", e.BOTHQ_CODEX], ["claude", e.BOTHQ_CLAUDE], ["gh", e.BOTHQ_GH], ["t3", e.BOTHQ_T3], ["t3Home", e.BOTHQ_T3_HOME], ["baseUrl", e.BOTHQ_BASE_URL]]) if (v) c[k] = v;
  // One Bot HQ: the same shape as always. More: a list of them, each with its own token.
  const out = list.length === 1 ? { ...list[0], ...c } : { servers: list, ...c };
  fs.writeFileSync(file + ".new", JSON.stringify(out, null, 2) + "\n", { mode: 0o600 }); fs.renameSync(file + ".new", file);
' "$dir/config.json"

echo "Found: node $("$node" -v)$( [ -n "$(find_cmd codex)" ] && echo ', codex')$( [ -n "$(find_cmd claude)" ] && echo ', claude')$( [ -n "$(find_cmd gh)" ] && echo ', gh')$( [ -n "$(find_cmd "$t3")" ] && echo ", $t3")"
[ -n "$(find_cmd "$t3")" ] || echo "Note: the T3 Code command \"$t3\" was not found, so this helper cannot renew Bot HQ's access here. Pass --t3 <command>."

# One round now for this Bot HQ, so a wrong address or token shows at once. If it fails, the helper
# is left as it was before this command.
if ! BOTHQ_HELPER_ONLY="$server" "$node" "$dir/helper.mjs"; then
  if [ "$adding" = 1 ]; then mv "$dir/config.json.before" "$dir/config.json"; echo "The first round with $server failed, so it was not added. Check the address and token, then run this again." >&2
  else echo "The first round failed. Check the address and token, then run this again." >&2; fi
  exit 1
fi
rm -f "$dir/config.json.before"

if ! schedule; then echo "Bot HQ helper installed (not scheduled: BOTHQ_HELPER_NO_SCHEDULE is set)."; exit 0; fi
if [ "$(uname)" = Darwin ]; then
  mkdir -p "$HOME/Library/LaunchAgents"
  cat > "$plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$label</string>
  <key>ProgramArguments</key><array><string>$node</string><string>$dir/helper.mjs</string><string>--scheduled</string></array>
  <key>StartInterval</key><integer>30</integer>
  <key>RunAtLoad</key><false/>
  <key>StandardOutPath</key><string>$dir/helper.log</string>
  <key>StandardErrorPath</key><string>$dir/helper.log</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$(dirname "$node"):/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string><key>HOME</key><string>$HOME</string></dict>
</dict></plist>
PLIST
  launchctl bootout "gui/$(id -u)/$label" 2>/dev/null || true
  launchctl bootstrap "gui/$(id -u)" "$plist"
else
  mkdir -p "$HOME/.config/systemd/user"
  printf '[Unit]\nDescription=Bot HQ helper\n[Service]\nType=oneshot\nExecStart=%s %s --scheduled\n' "$node" "$dir/helper.mjs" > "$HOME/.config/systemd/user/bothq-helper.service"
  # Every 30 seconds: a full round every 5 minutes, and in between only a quick question to each Bot HQ.
  printf '[Unit]\nDescription=Bot HQ helper, every 30 seconds\n[Timer]\nOnBootSec=2min\nOnUnitActiveSec=30s\n[Install]\nWantedBy=timers.target\n' > "$HOME/.config/systemd/user/bothq-helper.timer"
  systemctl --user daemon-reload
  systemctl --user enable --now bothq-helper.timer
fi
if [ "$adding" = 1 ]; then echo "Bot HQ helper now serves: $(servers_of "$node" | tr '\n' ' ')It checks in with each every 5 minutes, and looks in every 30 seconds for anything that cannot wait. Log: $dir/helper.log"
else echo "Bot HQ helper installed. It checks in every 5 minutes, and looks in every 30 seconds for anything that cannot wait. Log: $dir/helper.log"; fi
