#!/usr/bin/env node
// Bot HQ helper for a coding machine. One run does one round and exits. The system runs it every 30
// seconds (`--scheduled`): a full round every 5 minutes, and in between only a quick question to
// each Bot HQ, whether anything cannot wait (a key someone is giving a coding bot here).
//
//   1. Tell Bot HQ which accounts are signed in here (Codex, Claude Code). That is read from this
//      machine only: it costs no usage and asks no provider anything.
//   2. For the accounts Bot HQ asks about, ask the tool what is left on the plan and pass the answer on.
//      Bot HQ asks one machine per subscription, so a fleet on one subscription asks once.
//   3. If Bot HQ's access to T3 Code here is about to run out, make a pairing code and hand it over,
//      so the access is renewed with nobody approving in a browser.
//   4. Link this machine's T3 Code to the owner's other machines, when the owner asked for that in
//      Bot HQ, and keep the links renewed. A link takes both machines' helpers, so when Bot HQ says
//      there is link work, the helper stays a few minutes asking for it instead of exiting at once.
//   5. Update itself when Bot HQ serves a newer helper (set "autoUpdate": false in the config to stop that).
//   6. Add a teammate's own Codex or Claude sign-in to T3 Code here, when they ask in Bot HQ: a new
//      sign-in with its own folder, and the tool's sign-in started in the form that needs no screen
//      here. The person signs in in their own browser; the tool keeps the sign-in in that folder.
//   7. Add a teammate's GitHub account to the GitHub CLI (`gh`) here, when they ask in Bot HQ, so their
//      coding Bots can push and open pull requests as them. gh has one list of accounts on a machine
//      and one of them is the default, which other people's Bots use; adding an account never
//      changes which one that is.
//   8. Pass on a key or password someone gave a coding bot here on its card in Bot HQ: T3 Code's own
//      pending request for it is answered on this machine, through T3 Code's local API (the
//      `secrets.answerRequest` call its own app makes), with a session from T3 Code's command that
//      can do only that and is revoked at once. The bot gets the key exactly as if it had been typed
//      into T3 Code here. The helper keeps nothing: the key is in memory for that one call and is
//      never written to a file or the log. While a bot here waits for a key, Bot HQ says so and the
//      helper stays asking every few seconds.
//   9. List the skills a bot here would have, so Bot HQ's / list can offer them: for each sign-in,
//      and for the project folders Bot HQ names (the ones its coding bots here work in). Only each
//      skill's name and one-line description are read (from the header of its SKILL.md) and sent,
//      never anything else in those files. Sent on a full round, and only when it changed.
//  10. Report the disk's free space and T3 Code's working copies here (how many, how much space, how
//      many are finished), and remove finished ones T3 Code's own way: on its own when Bot HQ's cleanup
//      setting is on, or when someone chooses "Clean up now". Only a copy with nothing uncommitted or
//      unpushed, that no thread uses and nothing changed in for days, is ever removed (see "working copies").
//  11. Join another Bot HQ, or leave one (version 9). A Bot HQ that shares this machine hands over
//      `join {server, claim}`: the helper redeems the one-time claim at that other Bot HQ, gets its own
//      token there, and adds it to the config; that Bot HQ then makes its own access to T3 Code here
//      with a pairing code, as a renewal does. `leave {server}` drops a Bot HQ from the config and
//      revokes its sessions in T3 Code here (the ones named after it, "Bot HQ (<its name>)"). A Bot HQ
//      may make the helper leave itself, or one it shared this machine with; never any other.
//
// It reports every sign-in T3 Code has here, not only the default one of each tool, and the GitHub
// accounts gh has (their names only). It sends what the tools answered, as they answered it. It
// never reads or sends a sign-in token, and it never sends a prompt to a model.
//
// One helper can serve more than one Bot HQ (two companies using the same machines). Each Bot HQ
// gets its own round in turn, and one that fails or does not answer does not stop the others. The
// machine's sign-ins are the machine's, so each Bot HQ is told about all of them; what a Bot HQ asks
// for (a pairing code, a link, a sign-in) is answered to that Bot HQ alone.
//
// Config: ~/.bothq-helper/config.json
//   { server, token, label?, node?, codex?, claude?, gh?, t3?, t3Home?, baseUrl?, autoUpdate?, signInsDir? }
// or, serving more than one Bot HQ, "servers" in place of server and token:
//   { "servers": [{ "server": "<address>", "token": "<helper token>", "label"?, "by"? }, ...], "node": ..., ... }
// `label` is the name a Bot HQ registers under in T3 Code here; `by` the Bot HQ that shared this
// machine with it (version 9); `baseUrl` this machine's T3 Code address on the private network.
// Beside it, state.json is what this helper keeps between rounds: which Bot HQ added which sign-in,
// and which links each Bot HQ keeps. It holds no secret.
import { spawn, execFile } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const VERSION = '9';
const HOME = path.join(os.homedir(), '.bothq-helper');
const CONFIG = process.env.BOTHQ_HELPER_CONFIG ?? path.join(HOME, 'config.json');
const cfg = JSON.parse(fs.readFileSync(CONFIG, 'utf8'));
const log = (...a) => console.log(new Date().toISOString(), ...a);

/** The Bot HQs this helper serves: "servers", or the one "server" and "token" of a config from before there could be more. */
const SERVERS = (Array.isArray(cfg.servers) ? cfg.servers : [cfg])
  .map((s) => ({ server: String(s?.server ?? '').trim().replace(/\/+$/, ''), token: String(s?.token ?? '').trim(), label: typeof s?.label === 'string' ? s.label : null, by: typeof s?.by === 'string' ? s.by : null }))
  .filter((s) => /^https?:\/\//.test(s.server) && s.token)
  .map((s) => ({ ...s, name: new URL(s.server).host }));
/** The first Bot HQ is the one the helper was set up for; sign-ins made before it could serve more than one are its. */
const FIRST = SERVERS[0]?.server ?? null;

// ---------- what this helper keeps between rounds ----------

const STATE = path.join(path.dirname(CONFIG), 'state.json');
const state = (() => { try { const s = JSON.parse(fs.readFileSync(STATE, 'utf8')); return s && typeof s === 'object' ? s : {}; } catch { return {}; } })();
state.instances ??= {}; // T3 Code sign-in id -> the Bot HQ that added it
state.github ??= {}; // GitHub account added from Bot HQ -> [{ server, signin }]: the Bot HQs that still want it here
state.links ??= {}; // Bot HQ -> { keeps: { out, in } | null, linked: [environment id], dropped: [environment id] }
function saveState() {
  try {
    const tmp = `${STATE}.${process.pid}`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2) + '\n', { mode: 0o600 });
    fs.renameSync(tmp, STATE);
  } catch (e) { log('could not save state.json:', e.message); }
}
const linkState = (srv) => (state.links[srv.server] ??= { keeps: null, linked: [], dropped: [] });

/** Talk to a tool over its own line-by-line protocol; `ask` sends one request and resolves with the reply (null on silence). */
function session(command, args, { match, frame, env }) {
  const child = spawn(command, args, { stdio: ['pipe', 'pipe', 'ignore'], cwd: os.tmpdir(), env: { ...process.env, ...env } });
  const waiting = new Map();
  let n = 0;
  let failed = false;
  child.on('error', () => { failed = true; for (const r of waiting.values()) r(null); });
  readline.createInterface({ input: child.stdout }).on('line', (line) => {
    try { const hit = match(JSON.parse(line)); if (hit && waiting.has(hit.id)) { waiting.get(hit.id)(hit.value); waiting.delete(hit.id); } } catch { /* not for us */ }
  });
  return {
    ask: (payload, ms = 25_000) => new Promise((resolve) => {
      if (failed) return resolve(null);
      const id = ++n;
      waiting.set(id, resolve);
      try { child.stdin.write(JSON.stringify(frame(id, payload)) + '\n'); } catch { return resolve(null); }
      setTimeout(() => { if (waiting.delete(id)) resolve(null); }, ms);
    }),
    tell: (message) => { try { child.stdin.write(JSON.stringify(message) + '\n'); } catch { /* gone */ } },
    close: () => { try { child.kill(); } catch { /* gone */ } },
  };
}

/** Codex: who is signed in (read from its saved sign-in), and, when asked, what is left. `home`: that sign-in's own folder (CODEX_HOME). */
async function codex(wantLimits, home = null) {
  if (!cfg.codex) return null;
  const s = session(cfg.codex, ['app-server'], {
    match: (m) => (m.id !== undefined ? { id: m.id, value: m.result ?? null } : null),
    frame: (id, p) => ({ jsonrpc: '2.0', id, method: p.method, params: p.params }),
    env: home ? { CODEX_HOME: home } : {},
  });
  try {
    if (!(await s.ask({ method: 'initialize', params: { clientInfo: { name: 'bothq-helper', title: 'Bot HQ helper', version: VERSION } } }))) return null;
    s.tell({ jsonrpc: '2.0', method: 'initialized' });
    const account = await s.ask({ method: 'account/read', params: {} });
    const limits = wantLimits && account ? await s.ask({ method: 'account/rateLimits/read', params: null }) : undefined;
    return account ? { account, limits } : null;
  } finally { s.close(); }
}

/** Claude Code: who is signed in comes from its own settings file; what is left is asked of the tool, with no prompt sent. */
function claudeAccount(home = null) {
  try {
    const a = JSON.parse(fs.readFileSync(path.join(home ?? process.env.CLAUDE_CONFIG_DIR ?? os.homedir(), '.claude.json'), 'utf8')).oauthAccount;
    if (!a) return null;
    const keep = ['accountUuid', 'organizationUuid', 'emailAddress', 'organizationType', 'planDisplayName', 'billingType'];
    return Object.fromEntries(keep.filter((k) => a[k] != null).map((k) => [k, a[k]]));
  } catch { return null; }
}
async function claudeLimits(home = null) {
  if (!cfg.claude) return null;
  const s = session(cfg.claude, ['-p', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose'], {
    match: (m) => (m.type === 'control_response' && m.response ? { id: Number(String(m.response.request_id).slice(4)), value: m.response.subtype === 'success' ? m.response.response ?? {} : null } : null),
    frame: (id, request) => ({ type: 'control_request', request_id: `req_${id}`, request }),
    env: home ? { CLAUDE_CONFIG_DIR: home } : {},
  });
  try {
    if (!(await s.ask({ subtype: 'initialize' }))) return null;
    return await s.ask({ subtype: 'get_usage', skip_behaviors: true });
  } finally { s.close(); }
}

/** Send something to one Bot HQ, with its own token. Nothing meant for one Bot HQ is ever sent to another. */
async function post(srv, route, body) {
  const res = await fetch(`${srv.server}/api/fleet/${route}`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${srv.token}` }, body: JSON.stringify(body), signal: AbortSignal.timeout(60_000),
  });
  if (!res.ok) throw new Error(`Bot HQ answered ${res.status} to ${route}`);
  return res.json();
}

/** A one-time pairing code from T3 Code here, good for a few minutes, with what Bot HQ needs to run coding Bots. */
function pairingCode() {
  return new Promise((resolve) => {
    if (!cfg.t3) return resolve(null);
    const args = ['auth', 'pairing', 'create', ...(cfg.t3Home ? ['--base-dir', cfg.t3Home] : []),
      '--scope', 'orchestration:read', '--scope', 'orchestration:operate', '--scope', 'settings:write', '--scope', 'source-control:write',
      '--ttl', '5m', '--label', 'Bot HQ (renewed by its helper)', '--json'];
    execFile(cfg.t3, args, { timeout: 60_000, env: { ...process.env, ...(cfg.t3Home ? { T3CODE_HOME: cfg.t3Home } : {}) } }, (_err, stdout) => {
      try { resolve(JSON.parse(String(stdout).slice(String(stdout).indexOf('{'))).credential ?? null); } catch { resolve(null); }
    });
  });
}

// ---------- T3 Code here ----------

const T3_HOME = cfg.t3Home || path.join(os.homedir(), '.t3');
const SETTINGS = path.join(T3_HOME, 'userdata', 'settings.json');

/** Run the T3 Code command; resolves with its output, or null when it failed. Output may hold a secret: it is never logged. */
function t3(args, timeout = 60_000) {
  return new Promise((resolve) => {
    if (!cfg.t3) return resolve(null);
    execFile(cfg.t3, [...args, ...(cfg.t3Home ? ['--base-dir', cfg.t3Home] : [])], { timeout, env: { ...process.env, ...(cfg.t3Home ? { T3CODE_HOME: cfg.t3Home } : {}) } }, (err, stdout, stderr) => {
      resolve({ ok: !err, out: String(stdout ?? ''), err: String(stderr ?? '').split('\n').filter((l) => /error/i.test(l)).map((l) => l.replace(/^\[[^\]]*\]\s*/, '')).join(' ').slice(0, 300) });
    });
  });
}
const jsonIn = (text, open = '[') => { try { const i = text.indexOf(open); return i < 0 ? null : JSON.parse(text.slice(i)); } catch { return null; } };

/** Change T3 Code's settings file the way T3 Code itself does: whole, in one step. It reloads it by itself. */
function changeSettings(change) {
  let s = {};
  try { s = JSON.parse(fs.readFileSync(SETTINGS, 'utf8')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  if (!change(s)) return;
  fs.mkdirSync(path.dirname(SETTINGS), { recursive: true });
  const tmp = `${SETTINGS}.bothq-${process.pid}`;
  fs.writeFileSync(tmp, JSON.stringify(s, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, SETTINGS);
}
/** Linking needs T3 Code's "Linked environments" setting (Settings → Labs) on, on both machines. */
const allowLinks = () => changeSettings((s) => (s.linkedEnvironmentsEnabled === true ? false : ((s.linkedEnvironmentsEnabled = true), true)));

const environmentId = () => { try { return fs.readFileSync(path.join(T3_HOME, 'userdata', 'environment-id'), 'utf8').trim() || null; } catch { return null; } };

/** What this machine is linked to. Only what Bot HQ shows: no secret is in this list. */
async function links() {
  const r = await t3(['environment', 'list', '--json']);
  const list = r?.ok ? jsonIn(r.out) : null;
  return Array.isArray(list) ? list.map((l) => ({ environmentId: l.environmentId, label: l.label, status: l.status, expiresAt: l.expiresAt, access: l.access, lastError: l.lastError })) : null;
}

/**
 * Links between machines, when more than one Bot HQ is served. T3 Code keeps one link to a machine,
 * so two Bot HQs asking for the same link share it: either may renew it (that renews it for both,
 * and each sees the new end date in the next report). Unlinking takes the link off the machine only
 * when no other Bot HQ here still keeps it; otherwise the Bot HQ that asked just stops keeping it,
 * and it is left out of what that Bot HQ is told from then on.
 */
const linksFor = (srv, list) => (Array.isArray(list) ? list.filter((l) => !linkState(srv).dropped.includes(l.environmentId)) : list);
/** A Bot HQ from version 4 says which links it keeps; for an older one, those it made through this helper. */
const keptOut = (srv) => linkState(srv).keeps?.out ?? linkState(srv).linked;
const othersKeep = (srv, test) => SERVERS.some((o) => o.server !== srv.server && test(o));

// ---------- keys given on a coding bot's card ----------

/**
 * What this helper can do for a Bot HQ beyond the round itself, said with each request. 'secrets':
 * pass a key on to T3 Code here. That takes Node's built-in WebSocket (Node 22 or later) and the
 * T3 Code command; without them it says why not.
 */
const CAN = typeof WebSocket !== 'function' ? ['secrets-no:websocket'] : !cfg.t3 ? ['secrets-no:t3'] : ['secrets'];

/** Where T3 Code here serves its own app: from the file it writes when it starts. */
function localT3() {
  try {
    const rt = JSON.parse(fs.readFileSync(path.join(T3_HOME, 'userdata', 'server-runtime.json'), 'utf8'));
    const port = Number(rt.port);
    if (!Number.isInteger(port) || port <= 0) return null;
    const host = typeof rt.host === 'string' && rt.host && !['0.0.0.0', '::', '[::]'].includes(rt.host) ? rt.host : '127.0.0.1';
    return `http://${host.includes(':') && !host.startsWith('[') ? `[${host}]` : host}:${port}`;
  } catch { return null; }
}

/** One call to T3 Code's own API over its websocket; resolves with its exit (Success or Failure). */
function wsCall(url, tag, payload, ms = 20_000) {
  return new Promise((resolve) => {
    let ws;
    const done = (v) => { clearTimeout(timer); try { ws?.close(); } catch { /* gone */ } resolve(v); };
    const timer = setTimeout(() => done({ reason: 'no-answer' }), ms);
    try { ws = new WebSocket(url); } catch { return done({ reason: 'unreachable' }); }
    ws.onopen = () => { try { ws.send(JSON.stringify({ _tag: 'Request', id: '1', tag, payload, headers: [] })); } catch { done({ reason: 'unreachable' }); } };
    ws.onmessage = (e) => {
      let m; try { m = JSON.parse(String(e.data)); } catch { return; }
      for (const x of Array.isArray(m) ? m : [m]) {
        if (x?._tag === 'Ping') { try { ws.send(JSON.stringify({ _tag: 'Pong' })); } catch { /* gone */ } }
        if (x?._tag === 'Exit' && x.requestId === '1') return done({ exit: x.exit });
      }
    };
    ws.onerror = () => done({ reason: 'unreachable' });
    ws.onclose = () => done({ reason: 'unreachable' });
  });
}

/**
 * Answer T3 Code's pending secret request here: the key (`save`) or a no (`decline`). The session
 * it takes is issued for two minutes, with the one scope the call needs, and revoked right after.
 * Only a reason code comes back, never anything of the key.
 */
async function answerSecret(task) {
  const answer = task.answer;
  delete task.answer;
  const out = (more) => ({ kind: 'secret', id: task.id, ...more });
  if (!CAN.includes('secrets')) return out({ ok: false, reason: CAN[0] === 'secrets-no:t3' ? 'no-t3' : 'no-websocket', error: 'cannot pass keys on here' });
  if (!answer || (answer.type !== 'save' && answer.type !== 'decline') || typeof task.threadId !== 'string' || typeof task.turnItemId !== 'string') return out({ ok: false, reason: 'bad-task', error: 'bad-task' });
  const base = localT3();
  if (!base) return out({ ok: false, reason: 'not-running', error: 'not-running' });
  const issued = await t3(['auth', 'session', 'issue', '--scope', 'orchestration:operate', '--ttl', '2m', '--label', 'Bot HQ helper (passing on a key)', '--json']);
  const session = issued?.ok ? jsonIn(issued.out, '{') : null;
  if (!session?.token || !session?.sessionId) return out({ ok: false, reason: 'no-session', error: 'no-session' });
  try {
    let ticket = null;
    try {
      const r = await fetch(`${base}/api/auth/websocket-ticket`, { method: 'POST', headers: { authorization: `Bearer ${session.token}` }, signal: AbortSignal.timeout(15_000) });
      ticket = r.ok ? (await r.json())?.ticket : null;
    } catch { /* not reachable */ }
    if (typeof ticket !== 'string' || !ticket) return out({ ok: false, reason: 'unreachable', error: 'unreachable' });
    const r = await wsCall(`${base.replace(/^http/, 'ws')}/ws?orchestrationProtocol=2&wsTicket=${encodeURIComponent(ticket)}`, 'secrets.answerRequest', { threadId: task.threadId, turnItemId: task.turnItemId, answer });
    if (r.exit?._tag === 'Success') return out({ ok: true });
    // T3 Code's own reason (already_answered, agent_stopped, ...), a code and nothing else.
    const fail = (Array.isArray(r.exit?.cause) ? r.exit.cause : [r.exit?.cause]).find((c) => c?._tag === 'Fail')?.error;
    const reason = r.reason ?? (typeof fail?.reason === 'string' ? fail.reason : typeof fail?._tag === 'string' ? fail._tag : 'refused');
    const code = String(reason).replace(/[^A-Za-z_-]/g, '').slice(0, 40) || 'refused';
    return out({ ok: false, reason: code, error: code });
  } finally {
    await t3(['auth', 'session', 'revoke', String(session.sessionId)]);
  }
}

// ---------- the system's schedule ----------

const LABEL = process.env.BOTHQ_HELPER_LABEL || 'io.bothq.helper';
/** The scripts the schedule may name for this helper: as it was run, and the file itself. */
const SELF = [...new Set([process.argv[1], fileURLToPath(import.meta.url)].filter(Boolean).map((p) => path.resolve(p)))];

/**
 * A helper from before version 5 was run every 5 minutes. Move this machine's schedule to every 30
 * seconds, with `--scheduled`, so a key given on a card reaches the bot quickly. Only the schedule
 * that runs this very file is changed, and only once. On a Mac the job is reloaded after this run
 * ends (reloading it now would stop this run); the earlier schedule is put back if that fails.
 */
function keepSchedule() {
  if (process.env.BOTHQ_HELPER_NO_SCHEDULE === '1') return;
  const platform = process.env.BOTHQ_HELPER_OS || process.platform;
  try {
    if (platform === 'darwin') {
      const plist = process.env.BOTHQ_HELPER_PLIST || path.join(os.homedir(), 'Library', 'LaunchAgents', `${LABEL}.plist`);
      let text; try { text = fs.readFileSync(plist, 'utf8'); } catch { return; }
      const mine = SELF.find((p) => text.includes(`<string>${p}</string>`));
      if (!mine || (/<key>StartInterval<\/key>\s*<integer>30<\/integer>/.test(text) && text.includes('<string>--scheduled</string>'))) return;
      let next = text.replace(/<key>StartInterval<\/key>\s*<integer>\d+<\/integer>/, '<key>StartInterval</key><integer>30</integer>');
      if (!next.includes('<string>--scheduled</string>')) next = next.replace(`<string>${mine}</string>`, `<string>${mine}</string><string>--scheduled</string>`);
      if (next === text) return;
      fs.writeFileSync(`${plist}.before-5`, text, { mode: 0o600 });
      fs.writeFileSync(`${plist}.new`, next, { mode: 0o644 });
      fs.renameSync(`${plist}.new`, plist);
      const domain = `gui/${process.getuid()}`;
      const q = (v) => `'${String(v).replace(/'/g, `'\\''`)}'`;
      // In a session of its own, so it is not stopped with this run's job.
      spawn('/bin/sh', ['-c', `while kill -0 ${process.pid} 2>/dev/null; do sleep 1; done; sleep 1; launchctl bootout ${domain}/${LABEL} 2>/dev/null; launchctl bootstrap ${domain} ${q(plist)} || { cp ${q(`${plist}.before-5`)} ${q(plist)}; launchctl bootstrap ${domain} ${q(plist)}; }`],
        { detached: true, stdio: 'ignore', env: { ...process.env, PATH: process.env.PATH || '/bin:/usr/bin' } }).unref();
      log('from now on this helper runs every 30 seconds (a full round still every 5 minutes)');
    } else {
      const dir = process.env.BOTHQ_HELPER_SYSTEMD || path.join(os.homedir(), '.config', 'systemd', 'user');
      const service = path.join(dir, 'bothq-helper.service');
      const timer = path.join(dir, 'bothq-helper.timer');
      let svc, tmr; try { svc = fs.readFileSync(service, 'utf8'); tmr = fs.readFileSync(timer, 'utf8'); } catch { return; }
      const mine = SELF.find((p) => svc.includes(p));
      if (!mine || (/OnUnitActiveSec=30s/.test(tmr) && svc.includes('--scheduled'))) return;
      const svc2 = svc.includes('--scheduled') ? svc : svc.replace(/^(ExecStart=.*?)[ \t]*$/m, '$1 --scheduled');
      const tmr2 = tmr.replace(/OnUnitActiveSec=\S+/, 'OnUnitActiveSec=30s').replace(/every 5 minutes/, 'every 30 seconds');
      fs.writeFileSync(service, svc2);
      fs.writeFileSync(timer, tmr2);
      // Changing the timer does not stop this run.
      execFile('systemctl', ['--user', 'daemon-reload'], () => execFile('systemctl', ['--user', 'restart', 'bothq-helper.timer'], () => {}));
      log('from now on this helper runs every 30 seconds (a full round still every 5 minutes)');
    }
  } catch (e) { log('could not move the helper to every 30 seconds:', e.message); }
}

// ---------- sign-ins ----------

const expand = (p) => (typeof p === 'string' && p.trim() ? path.resolve(p.trim().replace(/^~(?=$|\/)/, os.homedir())) : null);
const readSettings = () => { try { return JSON.parse(fs.readFileSync(SETTINGS, 'utf8')); } catch { return {}; } };
const isOn = (c) => c?.enabled !== false && c?.config?.enabled !== false;

/**
 * Every Codex and Claude sign-in T3 Code has here: the default one of each tool, and each extra
 * "provider instance" with its own folder (CODEX_HOME or CLAUDE_CONFIG_DIR) for the tool.
 */
function signIns() {
  const s = readSettings();
  const inst = s.providerInstances && typeof s.providerInstances === 'object' ? s.providerInstances : {};
  const out = [];
  for (const id of ['codex', 'claudeAgent']) {
    if (!isOn(inst[id]) || s.providers?.[id]?.enabled === false) continue;
    out.push({ instance: id, driver: id, name: inst[id]?.displayName ?? null, home: expand(inst[id]?.config?.homePath) ?? expand(s.providers?.[id]?.homePath) });
  }
  for (const [id, c] of Object.entries(inst)) {
    if (id === 'codex' || id === 'claudeAgent' || !['codex', 'claudeAgent'].includes(c?.driver) || !isOn(c)) continue;
    out.push({ instance: id, driver: c.driver, name: c.displayName ?? null, home: expand(c.config?.homePath) });
  }
  return out;
}
/** Who is signed in to one of them, and when asked, what is left on its plan. */
async function accountIn(si, wantLimits) {
  if (si.driver === 'codex') {
    const c = await codex(wantLimits, si.home);
    return c ? { account: c.account, limits: c.limits } : null;
  }
  const account = claudeAccount(si.home);
  return account ? { account, limits: wantLimits ? await claudeLimits(si.home) : undefined } : null;
}

const SIGN_INS_DIR = expand(cfg.signInsDir) ?? path.join(HOME, 'sign-ins');
const running = new Map(); // sign-in id -> { srv, child, tool, home, out, done }
/** The sign-ins running for one Bot HQ: what it is told about, and what keeps the helper there. */
const runningFor = (srv) => [...running].filter(([, job]) => job.srv.server === srv.server);
const plain = (t) => t.replace(/\x1b\][^\x07\x1b]*(\x07|\x1b\\)?/g, ' ').replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '').replace(/\r/g, '');

/** Is a new sign-in in this folder finished? Read from the tool's own files; no token is read. */
function signedInAt(tool, home) {
  if (tool === 'codex') return fs.existsSync(path.join(home, 'auth.json'));
  return !!claudeAccount(home);
}

/** Stand-ins for what would open a browser or copy to the clipboard on this machine: the person signs in on their own computer. */
function noBrowser() {
  const nob = path.join(SIGN_INS_DIR, '.no-browser');
  fs.mkdirSync(nob, { recursive: true });
  for (const n of ['open', 'xdg-open', 'pbcopy', 'xclip', 'xsel', 'wl-copy']) fs.writeFileSync(path.join(nob, n), '#!/bin/sh\nexit 0\n', { mode: 0o755 });
  return nob;
}

/** Start a sign-in's program in a process group of its own, so stopping it stops everything it started, and keep what it prints. */
function track(srv, signin, tool, cmd, args, env, more = {}) {
  const child = spawn(cmd, args, { env, cwd: os.tmpdir(), stdio: ['pipe', 'pipe', 'pipe'], detached: true });
  child.stop = () => { try { process.kill(-child.pid, 'SIGTERM'); } catch { try { child.kill(); } catch { /* gone */ } } };
  const job = { srv, child, tool, out: '', done: null, ...more };
  running.set(signin, job);
  const take = (d) => { job.out = (job.out + d).slice(-20_000); };
  child.stdout.on('data', take);
  child.stderr.on('data', take);
  return job;
}

/** Wait (up to 25 seconds) for the program to print the page to open, and the code when there is one. */
async function pageOf(job, find) {
  for (let i = 0; i < 100 && !job.done; i++) {
    const hit = find(plain(job.out));
    if (hit) return hit;
    await new Promise((r) => setTimeout(r, 250));
  }
  job.child.stop();
  return { error: job.done?.error ?? 'the tool did not print a sign-in page' };
}

/**
 * Add a sign-in to T3 Code here, in a folder of its own, and start the tool's sign-in that needs no
 * screen: Codex's device code; Claude Code's sign-in where a code is pasted back. Answers with the
 * page to open (and Codex's code) as soon as the tool prints them.
 */
async function startSignIn(srv, task) {
  if (task.tool === 'github') return startGitHub(srv, task);
  const tool = task.tool;
  const bin = tool === 'codex' ? cfg.codex : cfg.claude;
  if (!bin) return { error: `${tool === 'codex' ? 'Codex' : 'Claude Code'} is not installed here (or the helper was set up before it was)` };
  const home = path.join(SIGN_INS_DIR, task.instance);
  fs.mkdirSync(home, { recursive: true, mode: 0o700 });
  changeSettings((s) => {
    s.providerInstances = { ...(s.providerInstances ?? {}), [task.instance]: { driver: tool === 'codex' ? 'codex' : 'claudeAgent', displayName: task.name, config: { homePath: home } } };
    return true;
  });
  // Only the Bot HQ that added it may take it away again.
  state.instances[task.instance] = srv.server;
  saveState();
  const nob = noBrowser();
  const env = { ...process.env, PATH: `${nob}:${process.env.PATH ?? '/usr/bin:/bin'}`, BROWSER: path.join(nob, 'open'), ...(tool === 'codex' ? { CODEX_HOME: home } : { CLAUDE_CONFIG_DIR: home }) };
  // Claude Code takes the pasted code only in a terminal, so it gets one (`script`). `script` will
  // not read from a socket (what Node gives a child) or a named pipe, only a plain pipe, so bash
  // makes one with `cat` and `script` takes its place; the `cat` goes when the group is stopped.
  const [cmd, args] = tool === 'codex' ? [bin, ['login', '--device-auth']]
    : ['/bin/bash', ['-c', process.platform === 'darwin'
      ? 'exec script -q /dev/null "$0" auth login --claudeai < <(cat)'
      : 'exec script -qfec "\\"$0\\" auth login --claudeai" /dev/null < <(cat)', bin]];
  const job = track(srv, task.signin, tool, cmd, args, env, { home });
  const { child } = job;
  child.on('exit', () => child.stop());
  child.on('error', (e) => { job.done ??= { ok: false, error: String(e.message).slice(0, 200) }; });
  child.on('exit', (code) => { job.done ??= signedInAt(tool, home) ? { ok: true } : { ok: false, error: code === 0 ? 'the tool finished without a sign-in' : `the tool stopped (${code})` }; });
  return pageOf(job, (text) => {
    const url = (text.match(/https:\/\/[^\s"'<>]+/g) ?? []).find((u) => (tool === 'codex' ? /auth\.openai\.com/.test(u) : /oauth\/authorize/.test(u)));
    const code = tool === 'codex' ? /one-time code[\s\S]{0,80}?\b([A-Z0-9]{4}-[A-Z0-9]{4,6})\b/.exec(text)?.[1] : null;
    return url && (tool !== 'codex' || code) ? { url, code } : null;
  });
}

/** A T3 Code sign-in is removed only for the Bot HQ that added it (one added before this helper served more than one is the first's). */
const mayRemove = (srv, instance) => (state.instances[instance] ? state.instances[instance] === srv.server : srv.server === FIRST);

/** Take a sign-in out of T3 Code here and delete its folder (only ever a folder this helper made). */
async function removeSignIn(srv, task) {
  if (task.tool === 'github') return removeGitHub(srv, task);
  const job = running.get(task.signin);
  if (job && job.srv.server === srv.server) { job.child.stop(); running.delete(task.signin); }
  if (!mayRemove(srv, task.instance)) return { ok: true, kept: 'another Bot HQ added this sign-in' };
  changeSettings((s) => (s.providerInstances?.[task.instance] ? (delete s.providerInstances[task.instance], true) : false));
  const home = path.join(SIGN_INS_DIR, task.instance);
  if (path.dirname(home) === SIGN_INS_DIR && /^[a-z0-9-]+$/.test(task.instance)) fs.rmSync(home, { recursive: true, force: true });
  delete state.instances[task.instance];
  saveState();
  return { ok: true };
}

// ---------- GitHub ----------

/** GitHub's own host. Another one only to try this helper against a stand-in for GitHub. */
const GH_HOST = cfg.githubHost || 'github.com';
const onPath = (name) => {
  for (const dir of [...String(process.env.PATH ?? '').split(':'), '/opt/homebrew/bin', '/usr/local/bin']) {
    if (!dir) continue;
    try { fs.accessSync(path.join(dir, name), fs.constants.X_OK); return path.join(dir, name); } catch { /* not here */ }
  }
  return null;
};
const ghBin = () => cfg.gh || onPath('gh');
/** gh as itself: its own saved accounts (never a token from this helper's surroundings), and no questions. */
function ghEnv(more = {}) {
  const e = { ...process.env, GH_NO_UPDATE_NOTIFIER: '1', GH_PROMPT_DISABLED: '1', NO_COLOR: '1', ...more };
  for (const k of ['GH_TOKEN', 'GITHUB_TOKEN', 'GH_ENTERPRISE_TOKEN', 'GITHUB_ENTERPRISE_TOKEN', 'GH_HOST']) delete e[k];
  return e;
}
/** Run gh; resolves with what it printed, or null when it is not here. Its output is never logged. */
function gh(args, timeout = 30_000) {
  return new Promise((resolve) => {
    const bin = ghBin();
    if (!bin) return resolve(null);
    execFile(bin, args, { timeout, env: ghEnv(), cwd: os.tmpdir() }, (err, stdout, stderr) => {
      resolve({ ok: !err, out: String(stdout ?? ''), err: String(stderr ?? '').trim().split('\n').pop()?.slice(0, 200) ?? '' });
    });
  });
}

/**
 * The GitHub accounts gh has here and which one is the default (gh calls it active): their names
 * only. gh shows no token unless asked to. Null when gh is not here or did not say.
 */
async function githubAccounts() {
  const r = await gh(['auth', 'status', '--hostname', GH_HOST, '--json', 'hosts']);
  const hosts = jsonIn(r?.out ?? '', '{')?.hosts;
  if (!hosts || typeof hosts !== 'object') return null;
  const list = Array.isArray(hosts[GH_HOST]) ? hosts[GH_HOST] : [];
  return list.filter((a) => typeof a?.login === 'string').map((a) => ({ login: a.login, active: a.active === true }));
}
const defaultOf = (accounts) => accounts?.find((a) => a.active)?.login ?? null;
/** One GitHub sign-in at a time on a machine, whichever Bot HQ asked: each puts the default account back when it ends. */
let githubBusy = false;

/**
 * Add a GitHub account to gh here: `gh auth login --web` prints a one-time code and GitHub's page
 * for it, and waits while the person enters the code on their own computer. gh makes the account it
 * signs in the default one, so the default from before is put back as soon as it is done.
 */
async function startGitHub(srv, task) {
  const bin = ghBin();
  if (!bin) return { error: 'the GitHub CLI (gh) is not installed here' };
  if (githubBusy) return { error: 'another GitHub sign-in is being added on this machine; try again in a few minutes' };
  const before = await githubAccounts();
  if (!before) return { error: 'gh did not say which GitHub accounts it has here' };
  // With no account here the new one would become the machine's own; only its owner may do that.
  if (!before.length && !task.first) return { error: 'this machine has no GitHub account of its own yet; its owner signs in to one first' };
  githubBusy = true;
  const nob = noBrowser();
  const job = track(srv, task.signin, 'github', bin, ['auth', 'login', '--hostname', GH_HOST, '--git-protocol', 'https', '--web'],
    ghEnv({ PATH: `${nob}:${process.env.PATH ?? '/usr/bin:/bin'}`, BROWSER: path.join(nob, 'open') }), { before });
  job.child.stdin.end();
  const finish = (result) => { job.done ??= result; githubBusy = false; };
  job.child.on('error', (e) => finish({ ok: false, error: String(e.message).slice(0, 200) }));
  job.child.on('exit', (code) => {
    job.child.stop();
    afterGitHub(srv, task, job, code).then(finish, (e) => finish({ ok: false, error: String(e?.message ?? e).slice(0, 200) }));
  });
  return pageOf(job, (text) => {
    const url = (text.match(/https:\/\/[^\s"'<>]+/g) ?? []).find((u) => /\/login\/device\b/.test(u));
    const code = /one-time code[\s\S]{0,80}?\b([A-Z0-9]{4}-[A-Z0-9]{4})\b/i.exec(text)?.[1];
    return url && code ? { url, code } : null;
  });
}

/** gh has finished (signed in, failed, or was stopped): put the default account back, and say who signed in. */
async function afterGitHub(srv, task, job, code) {
  const before = job.before;
  const was = defaultOf(before);
  let after = await githubAccounts();
  for (let i = 0; !after && i < 5; i++) { await new Promise((r) => setTimeout(r, 1000)); after = await githubAccounts(); }
  // gh makes the account it just signed in the default one: that is who signed in.
  const login = code === 0 ? defaultOf(after) : null;
  if (was && after && defaultOf(after) !== was) {
    await gh(['auth', 'switch', '--hostname', GH_HOST, '--user', was]);
    if (defaultOf(await githubAccounts()) !== was) log(`could not make ${was} the default GitHub account again; run: gh auth switch --user ${was}`);
  }
  if (job.cancelled || !login) {
    // Cancelled or stopped just as it finished: leave no account behind that was not here before.
    const newcomer = (after ?? []).find((a) => !before.some((b) => b.login === a.login) && !state.github[a.login]);
    if (newcomer && newcomer.login !== was) await gh(['auth', 'logout', '--hostname', GH_HOST, '--user', newcomer.login]);
    return { ok: false, error: job.cancelled ? 'cancelled' : code === 0 ? 'gh finished without a sign-in' : `gh stopped (${code ?? 'stopped'})` };
  }
  const added = !before.some((a) => a.login === login);
  // Signed out again from Bot HQ only if Bot HQ added it: an account someone signed in to here by hand stays.
  if (added || state.github[login]) {
    state.github[login] = [...(state.github[login] ?? []), { server: srv.server, signin: task.signin }];
    saveState();
  }
  return { ok: true, login };
}

/** Remove a GitHub sign-in added from Bot HQ: that one account is signed out, once no Bot HQ here still wants it, and never the default one. */
async function removeGitHub(srv, task) {
  const job = running.get(task.signin);
  if (job && job.srv.server === srv.server) { job.cancelled = true; job.child.stop(); running.delete(task.signin); }
  for (const [login, holders] of Object.entries(state.github)) {
    const left = holders.filter((h) => !(h.server === srv.server && h.signin === task.signin));
    if (left.length === holders.length) continue;
    if (left.length) { state.github[login] = left; continue; }
    const accounts = await githubAccounts();
    if (accounts?.some((a) => a.login === login) && defaultOf(accounts) !== login) {
      const r = await gh(['auth', 'logout', '--hostname', GH_HOST, '--user', login]);
      if (!r?.ok) { saveState(); return { ok: false, error: `gh could not sign ${login} out: ${r?.err || 'no reason given'}` }; }
    }
    delete state.github[login];
  }
  saveState();
  return { ok: true };
}

/**
 * Make T3 Code look at a sign-in again. It checks one when its entry is added to the settings and
 * keeps that answer, which for a new sign-in is "not signed in": it was added before the person
 * signed in. Saving the settings unchanged does not make it look again (seen on T3 Code 0.1.9, where
 * a finished sign-in never showed as ready). Taking the entry out and putting it back does.
 */
async function lookAgain(instance) {
  let entry = null;
  changeSettings((s) => {
    entry = s.providerInstances?.[instance] ?? null;
    if (!entry) return false;
    delete s.providerInstances[instance];
    return true;
  });
  if (!entry) return;
  try {
    await new Promise((r) => setTimeout(r, Number(process.env.BOTHQ_LOOK_AGAIN_MS ?? 4000)));
  } finally {
    // Whatever happens in between, the entry goes back.
    changeSettings((s) => { s.providerInstances = { ...(s.providerInstances ?? {}), [instance]: entry }; return true; });
  }
  log('had T3 Code look at', instance, 'again, now that it is signed in');
}

/** One Bot HQ's sign-ins that finished since the last look, as results for it. */
async function finishedSignIns(srv) {
  const out = [];
  for (const [id, job] of runningFor(srv)) {
    // Claude Code may stay open after signing in; the account in its folder is what counts.
    if (!job.done && job.home && signedInAt(job.tool, job.home)) { job.done = { ok: true }; job.child.stop(); }
    if (!job.done) continue;
    running.delete(id);
    if (job.done.ok && job.tool !== 'github' && job.home) await lookAgain(path.basename(job.home));
    out.push({ kind: 'signin-done', signin: id, ...job.done });
  }
  return out;
}
const stopSignIns = (srv) => { for (const [, job] of runningFor(srv)) job.child.stop(); };

// The scopes a full-access link needs; T3 Code refuses full access to a code without them.
const LINK_SCOPES = ['orchestration:read', 'orchestration:operate', 'settings:write', 'source-control:write'];

/** What a Bot HQ from version 4 says it keeps: the machines this one links to, and those linking to it. */
function noteKeeps(srv, keeps) {
  if (!keeps || !Array.isArray(keeps.out) || !Array.isArray(keeps.in)) return;
  linkState(srv).keeps = { out: keeps.out.filter((e) => typeof e === 'string'), in: keeps.in.filter((e) => typeof e === 'string') };
}

/** One piece of work a Bot HQ handed over. The result goes back to that Bot HQ only; a pairing code only when making one was the work. */
async function doTask(srv, task) {
  const done = (more) => ({ kind: task.kind, link: task.link, signin: task.signin, id: task.id, ...more });
  try {
    if (task.kind === 'pair') {
      allowLinks();
      const r = await t3(['auth', 'pairing', 'create', ...LINK_SCOPES.flatMap((s) => ['--scope', s]), '--ttl', '3m', '--label', 'Link from another machine (Bot HQ)', '--json']);
      const code = r?.ok ? jsonIn(r.out, '{')?.credential : null;
      return done(code ? { code } : { error: r?.err || 'no pairing code made' });
    }
    if (task.kind === 'link') {
      allowLinks();
      const r = await t3(['environment', 'link', task.url, '--pairing-code', task.code, '--access', 'full-access'], 90_000);
      if (!r?.ok) return done({ ok: false, error: r?.err || 'the link command failed' });
      const all = jsonIn((await t3(['environment', 'list', '--json']))?.out ?? '') ?? [];
      const made = all.find((l) => Array.isArray(l.urls) && l.urls.includes(new URL(task.url).origin));
      if (made?.environmentId) {
        const ls = linkState(srv);
        ls.linked = [...new Set([...ls.linked, made.environmentId])];
        ls.dropped = ls.dropped.filter((e) => e !== made.environmentId);
        saveState();
      }
      return done({ ok: true, environmentId: made?.environmentId ?? null, linkedAt: made?.linkedAt ?? null, expiresAt: made?.expiresAt ?? null });
    }
    if (task.kind === 'revoke' && othersKeep(srv, (o) => (linkState(o).keeps?.in ?? []).length > 0)) {
      // Another Bot HQ keeps a link to this machine, and the session may be the one it uses. Left to run out by itself.
      return done({ sessionId: null, revoked: [], kept: 'another Bot HQ keeps a link to this machine' });
    }
    if (task.kind === 'adopt' || task.kind === 'revoke') {
      const list = jsonIn((await t3(['auth', 'session', 'list', '--json']))?.out ?? '') ?? [];
      let sessionId = null;
      if (task.kind === 'adopt') {
        // The session a link made here: an outside client named after the machine that linked, made when the link was.
        const near = list.filter((s) => s.subject === 'mcp-client' && String(s.client?.label ?? '').startsWith('T3 Code · ') && (!task.label || s.client.label === task.label))
          .map((s) => ({ id: s.sessionId, off: Math.abs(Date.parse(s.issuedAt) - task.around) })).filter((s) => s.off < 120_000).sort((a, b) => a.off - b.off);
        sessionId = near[0]?.id ?? null;
      }
      const revoked = [];
      for (const id of task.kind === 'adopt' ? task.revoke : task.sessions) {
        if (id === sessionId) continue;
        if (!list.some((s) => s.sessionId === id)) { revoked.push(id); continue; } // already gone
        if ((await t3(['auth', 'session', 'revoke', id]))?.ok) revoked.push(id);
      }
      return done({ sessionId, revoked });
    }
    if (task.kind === 'signin') return { kind: 'signin', signin: task.signin, ...(await startSignIn(srv, task)) };
    if (task.kind === 'signin-code') {
      const job = running.get(task.signin);
      const ours = job && job.srv.server === srv.server;
      if (ours && !job.done && job.tool === 'claude') job.child.stdin.write(`${task.code}\r`);
      return { kind: 'signin-code', signin: task.signin, ok: !!ours };
    }
    if (task.kind === 'signin-remove') return { kind: 'signin-remove', signin: task.signin, ...(await removeSignIn(srv, task)) };
    if (task.kind === 'secret') return await answerSecret(task);
    if (task.kind === 'copies-check' || task.kind === 'copies-clean') return await copiesTask(srv, task);
    if (task.kind === 'read-doc') return readDoc(task);
    if (task.kind === 'join') return await join(srv, task);
    if (task.kind === 'leave') return await leave(srv, task);
    if (task.kind === 'unlink') {
      if (othersKeep(srv, (o) => keptOut(o).includes(task.environmentId))) {
        // Another Bot HQ still keeps this link: it stays on the machine, and this Bot HQ stops seeing it.
        const ls = linkState(srv);
        ls.dropped = [...new Set([...ls.dropped, task.environmentId])];
        ls.linked = ls.linked.filter((e) => e !== task.environmentId);
        saveState();
        return done({ ok: true, kept: 'another Bot HQ still keeps this link' });
      }
      const r = await t3(['environment', 'unlink', task.environmentId]);
      if (r?.ok) {
        for (const ls of Object.values(state.links)) { ls.linked = ls.linked.filter((e) => e !== task.environmentId); ls.dropped = ls.dropped.filter((e) => e !== task.environmentId); }
        saveState();
      }
      return done({ ok: !!r?.ok, error: r?.err });
    }
  } catch (e) {
    // A key's task carries nothing back but a code, whatever went wrong.
    if (task.kind === 'secret') { delete task.answer; return { kind: 'secret', id: task.id, ok: false, reason: 'failed', error: 'failed' }; }
    return done({ ok: false, error: String(e?.message ?? e).slice(0, 200) });
  }
  return done({ ok: false, error: 'this helper does not know that work' });
}

// ---------- joining and leaving Bot HQs (version 9) ----------

const norm = (s) => String(s ?? '').trim().replace(/\/+$/, '');
const ADDRESS = /^https?:\/\/[^/\s]+$/;

/** The Bot HQs in the config as it is on disk now (another run may have changed it since this one started). */
function configNow() {
  const c = JSON.parse(fs.readFileSync(CONFIG, 'utf8'));
  const list = Array.isArray(c.servers) ? c.servers : c.server ? [{ server: c.server, token: c.token, ...(c.label ? { label: c.label } : {}), ...(c.by ? { by: c.by } : {}) }] : [];
  return { c, list };
}
/** Change the list of Bot HQs in the config, in one step, keeping everything else. One left: the shape of a helper serving one. */
function changeServers(change) {
  const { c, list } = configNow();
  const next = change(list.map((s) => ({ ...s })));
  for (const k of ['server', 'token', 'label', 'by', 'servers']) delete c[k];
  const out = next.length === 1 ? { ...next[0], ...c } : { servers: next, ...c };
  const tmp = `${CONFIG}.${process.pid}.new`;
  fs.writeFileSync(tmp, JSON.stringify(out, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, CONFIG);
}

/**
 * Join another Bot HQ that this one (`srv`) shared this machine with: redeem the claim there, which
 * answers with this helper's own token for it, and add it to the config. Its first round comes with
 * the next run: it makes its own access to T3 Code here with a pairing code, as a renewal does.
 */
async function join(srv, task) {
  const out = (more) => ({ kind: 'join', id: task.id, ...more });
  const server = norm(task.server);
  if (!ADDRESS.test(server)) return out({ ok: false, error: 'that is not a Bot HQ address' });
  if (server === srv.server) return out({ ok: false, error: 'a Bot HQ cannot share a machine with itself' });
  let res, j;
  try {
    res = await fetch(`${server}/api/fleet/claim`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, signal: AbortSignal.timeout(30_000),
      body: JSON.stringify({ claim: task.claim, environmentId: environmentId(), name: os.hostname(), baseUrl: cfg.baseUrl ?? null }),
    });
    j = await res.json().catch(() => null);
  } catch { return out({ ok: false, error: `${new URL(server).host} did not answer` }); }
  if (!res.ok || typeof j?.token !== 'string' || !j.token) return out({ ok: false, error: String(j?.error ?? `${new URL(server).host} answered ${res.status}`).slice(0, 200) });
  changeServers((list) => [...list.filter((s) => norm(s.server) !== server), { server, token: j.token, ...(typeof j.clientName === 'string' ? { label: j.clientName } : {}), by: srv.server }]);
  log(`[${srv.name}]`, `now also serving ${new URL(server).host}, shared from here; it connects on the next round`);
  return out({ ok: true });
}

/**
 * Stop serving a Bot HQ: the Bot HQ asking (`self`), or one it shared this machine with. Its entry
 * and what this helper kept for it (its links) go, and its sessions in T3 Code here are revoked: the
 * ones named after it. Sign-ins it added stay on the machine (they are the person's, and the machine's).
 */
async function leave(srv, task) {
  const out = (more) => ({ kind: 'leave', id: task.id, ...more });
  const target = task.self ? srv.server : norm(task.server);
  const entry = configNow().list.find((s) => norm(s.server) === target);
  if (!entry) return out({ ok: true, revoked: 0, note: 'not served here' });
  if (target !== srv.server && norm(entry.by) !== srv.server) return out({ ok: false, error: 'only that Bot HQ, or the one that shared this machine with it, can take it off this machine' });
  changeServers((list) => list.filter((s) => norm(s.server) !== target));
  delete state.links[target];
  delete state.rounds?.[target];
  saveState();
  // Its sessions here, by the name it registered under. Never one another Bot HQ here goes by.
  const label = typeof entry.label === 'string' ? entry.label : typeof task.label === 'string' ? task.label : null;
  let revoked = 0;
  const others = configNow().list.map((s) => s.label);
  if (label && /^Bot HQ \(.+\)$/.test(label) && !others.includes(label)) {
    const list = jsonIn((await t3(['auth', 'session', 'list', '--json']))?.out ?? '') ?? [];
    for (const s of Array.isArray(list) ? list : []) {
      if (s?.client?.label === label && typeof s.sessionId === 'string' && (await t3(['auth', 'session', 'revoke', s.sessionId]))?.ok) revoked++;
    }
  }
  if (target === srv.server) srv.left = true;
  log(`[${srv.name}]`, `no longer serving ${new URL(target).host}; revoked ${revoked} of its session(s) in T3 Code here`);
  return out({ ok: true, revoked });
}

// ---------- a Markdown file a Bot linked (version 8) ----------

/** The most of one file that is sent back; a longer one is cut, and says so. */
const DOC_MAX_BYTES = 1_000_000;
const DOC_FILE = /\.(md|markdown|mdx)$/i;

/**
 * Read one Markdown file a Bot linked in its chat, for Bot HQ to show and download. Only a Markdown
 * file, only inside one of the folders Bot HQ names (the Bot's project and its working copy), links
 * followed first so none leads out of them, and at most DOC_MAX_BYTES of it.
 */
function readDoc(task) {
  const out = (more) => ({ kind: 'read-doc', id: task.id, ...more });
  const want = typeof task.path === 'string' ? task.path : '';
  if (!want || want.includes('\0') || !DOC_FILE.test(want)) return out({ ok: false, error: 'not a Markdown file' });
  const roots = (Array.isArray(task.roots) ? task.roots : []).filter((r) => typeof r === 'string' && path.isAbsolute(r)).slice(0, 10);
  for (const root of roots) {
    let realRoot, real;
    try {
      realRoot = fs.realpathSync(root);
      real = fs.realpathSync(path.isAbsolute(want) ? want : path.join(root, want));
    } catch { continue; }
    if (!real.startsWith(realRoot + path.sep) || !DOC_FILE.test(real)) continue;
    let fd;
    try {
      const st = fs.statSync(real);
      if (!st.isFile()) continue;
      fd = fs.openSync(real, 'r');
      const buf = Buffer.alloc(Math.min(st.size, DOC_MAX_BYTES));
      const n = fs.readSync(fd, buf, 0, buf.length, 0);
      return out({ ok: true, path: real, name: path.basename(real), size: st.size, truncated: st.size > DOC_MAX_BYTES, text: buf.subarray(0, n).toString('utf8') });
    } catch (e) {
      return out({ ok: false, error: String(e?.message ?? e).slice(0, 200) });
    } finally { if (fd !== undefined) try { fs.closeSync(fd); } catch { /* closed */ } }
  }
  return out({ ok: false, error: 'not found in the Bot’s project or working copy' });
}

/** Do the work one Bot HQ hands over, and stay asking it for more for as long as it says, within a hard limit. */
async function stayForWork(srv, first) {
  const say = (...a) => log(`[${srv.name}]`, ...a);
  const hardStop = Date.now() + 20 * 60_000;
  let answer = first;
  let until = Date.now() + (first.stay ?? 0) * 1000;
  try {
    while (Date.now() < hardStop) {
      const results = [];
      const work = answer.work ?? [];
      answer = null;
      for (const task of work) { results.push(await doTask(srv, task)); say('did', task.kind, results.at(-1).ok === false || results.at(-1).error ? `(failed: ${results.at(-1).error ?? 'no reason given'})` : ''); }
      work.length = 0;
      results.push(...(await finishedSignIns(srv)));
      if (!results.length && Date.now() >= until && !runningFor(srv).length) return;
      if (!results.length) await new Promise((r) => setTimeout(r, 3000));
      answer = await post(srv, 'work', { results, signingIn: runningFor(srv).map(([id]) => id), can: CAN });
      // This Bot HQ asked the helper to stop serving it, and has been told it is done.
      if (srv.left) return;
      until = Date.now() + (answer.stay ?? 0) * 1000;
      if (!answer.work?.length && !answer.stay && !runningFor(srv).length) return;
    }
  } finally { stopSignIns(srv); }
}

/** Replace this script with the newer one a Bot HQ serves. The next round runs it. */
async function update(srv, version) {
  if (cfg.autoUpdate === false) return log(`a newer helper (version ${version}) is available; run the update command Bot HQ shows`);
  const res = await fetch(`${srv.server}/fleet/helper.mjs`, { signal: AbortSignal.timeout(60_000) });
  const text = await res.text();
  if (!res.ok || !text.startsWith('#!/usr/bin/env node') || !text.includes(`const VERSION = '${version}'`)) return log('the newer helper did not download cleanly; keeping this one');
  const self = fileURLToPath(import.meta.url);
  fs.writeFileSync(`${self}.new`, text, { mode: 0o600 });
  fs.renameSync(`${self}.new`, self);
  log(`updated the helper to version ${version} from ${srv.name}`);
}

// ---------- skills ----------

/**
 * The skills a bot here would have, for Bot HQ's / list. Each is read from the header of its
 * SKILL.md (the lines between the first two `---`): `name` and `description`, and `user-invocable`
 * only to leave out one a person may not ask for. Nothing else in those files is read, and only the
 * name and a one-line description are sent. Where they are read from, for each sign-in (its own
 * settings folder):
 *
 *  - Claude Code: `<settings folder>/skills/<name>/SKILL.md`, and the skills of each plugin named in
 *    `<settings folder>/plugins/installed_plugins.json` for the person (not one put in for one project),
 *    unless the folder's settings.json turns it off: `<plugin>/skills/<name>/SKILL.md`, asked for as
 *    `plugin:name`. The settings folder is the sign-in's own (CLAUDE_CONFIG_DIR), or ~/.claude.
 *  - Codex: `$CODEX_HOME/skills`, the shared `~/.agents/skills` (every Codex sign-in reads it),
 *    each plugin config.toml turns on (`$CODEX_HOME/plugins/cache/<marketplace>/<plugin>/<version>/skills`,
 *    as `plugin:name`), and its bundled ones (`$CODEX_HOME/skills/.system`). A skill config.toml turns
 *    off is left out.
 *  - T3 Code's own list for that sign-in (`<T3 Code folder>/caches/<sign-in>.json`), for any it knows
 *    that the above missed. It can be a day old, so it is only an extra, and a skill whose file is
 *    gone since is left out.
 *
 * A project's own skills depend on the folder a bot works in, so Bot HQ names those folders and each
 * is listed apart: `.claude/skills` for Claude Code, `.agents/skills` for Codex.
 */
const SKILL_CAP = { signIn: 150, project: 50, folders: 20, description: 200 };
/** A name a skill can be asked for by (`$name`): as Bot HQ checks it. */
const SKILL_NAME = /^(?=[a-zA-Z0-9:_-]*[a-zA-Z])[a-zA-Z0-9][a-zA-Z0-9:_-]{0,79}$/;
const SKILL_HEADER_BYTES = 8192;
const SKILL_FOLDERS_MAX = 500;

const oneLine = (text) => {
  const t = typeof text === 'string' ? text.replace(/\s+/g, ' ').trim() : '';
  if (!t) return null;
  return t.length > SKILL_CAP.description ? `${t.slice(0, SKILL_CAP.description - 1).trimEnd()}…` : t;
};

/** The few header fields a SKILL.md gives, read from its first few kilobytes only. */
function skillHeader(file) {
  let text = '';
  let fd;
  try {
    fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(SKILL_HEADER_BYTES);
    text = buf.subarray(0, fs.readSync(fd, buf, 0, SKILL_HEADER_BYTES, 0)).toString('utf8');
  } catch { return null; } finally { if (fd !== undefined) { try { fs.closeSync(fd); } catch { /* closed */ } } }
  const m = /^﻿?---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/.exec(text);
  if (!m) return null;
  const lines = m[1].split(/\r?\n/);
  const out = {};
  for (let i = 0; i < lines.length; i++) {
    const k = /^([A-Za-z][A-Za-z0-9_-]*):[ \t]*(.*?)[ \t]*$/.exec(lines[i]);
    if (!k) continue;
    // What belongs to this field: the lines after it that are indented or blank.
    const more = [];
    while (i + 1 < lines.length && (/^\s/.test(lines[i + 1]) || !lines[i + 1].trim())) more.push(lines[++i].trim());
    if (!['name', 'description', 'user-invocable'].includes(k[1])) continue;
    const v = k[2];
    let value;
    if (/^[|>][+-]?\d*$/.test(v)) value = more.filter(Boolean).join(' ');
    else if (v.startsWith('"')) {
      const q = /^"((?:[^"\\]|\\.)*)"/.exec([v, ...more].join(' '));
      try { value = q ? JSON.parse(`"${q[1]}"`) : v.slice(1); } catch { value = q[1]; }
    } else if (v.startsWith("'")) {
      const q = /^'((?:[^']|'')*)'/.exec([v, ...more].join(' '));
      value = q ? q[1].replace(/''/g, "'") : v.slice(1);
    } else value = [v, ...more].filter(Boolean).join(' ');
    out[k[1]] = String(value).replace(/\s+/g, ' ').trim();
  }
  return out;
}

/** The skills in one skills folder (`<folder>/<name>/SKILL.md`), named `prefix:name` for a plugin's. */
function skillsIn(dir, prefix = '', into = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return into; }
  for (const e of entries.slice(0, SKILL_FOLDERS_MAX)) {
    if (e.name.startsWith('.') || !(e.isDirectory() || e.isSymbolicLink())) continue;
    const file = path.join(dir, e.name, 'SKILL.md');
    const h = skillHeader(file);
    if (!h || /^false$/i.test(h['user-invocable'] ?? '')) continue;
    const base = SKILL_NAME.test(h.name ?? '') ? h.name : e.name;
    const name = prefix ? `${prefix}:${base}` : base;
    if (SKILL_NAME.test(name)) into.push({ name, description: oneLine(h.description), file });
  }
  return into;
}

const readJson = (file) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; } };

/** Claude Code plugins installed for the person in one settings folder, and their skills. */
function claudePluginSkills(dir, into) {
  const installed = readJson(path.join(dir, 'plugins', 'installed_plugins.json'))?.plugins;
  if (!installed || typeof installed !== 'object') return;
  // Only whether each is turned off is read from the settings.
  const enabled = readJson(path.join(dir, 'settings.json'))?.enabledPlugins;
  for (const [key, v] of Object.entries(installed).slice(0, 200)) {
    if (enabled && typeof enabled === 'object' && enabled[key] === false) continue;
    const entry = (Array.isArray(v) ? v : [v]).find((x) => x && typeof x.installPath === 'string' && (!x.scope || x.scope === 'user'));
    const at = entry ? expand(entry.installPath) : null;
    const plugin = key.split('@')[0];
    if (at && SKILL_NAME.test(plugin)) skillsIn(path.join(at, 'skills'), plugin, into);
  }
}

/** From a Codex config.toml: the plugins it turns on, and the skill files it turns off. Nothing else is kept. */
function codexConfig(home) {
  let text = '';
  try { text = fs.readFileSync(path.join(home, 'config.toml'), 'utf8'); } catch { /* none */ }
  const plugins = [];
  const skills = [];
  let cur = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    let m;
    if ((m = /^\[plugins\.(?:"([^"]+)"|'([^']+)'|([A-Za-z0-9_@.-]+))\]$/.exec(line))) { cur = { key: m[1] ?? m[2] ?? m[3], enabled: true }; plugins.push(cur); continue; }
    if (/^\[\[skills\.config\]\]$/.test(line)) { cur = { path: null, enabled: true }; skills.push(cur); continue; }
    if (line.startsWith('[')) { cur = null; continue; }
    if (!cur) continue;
    if ((m = /^enabled\s*=\s*(true|false)\b/.exec(line))) cur.enabled = m[1] === 'true';
    if ('path' in cur && (m = /^path\s*=\s*(?:"((?:[^"\\]|\\.)*)"|'([^']*)')/.exec(line))) {
      try { cur.path = m[1] !== undefined ? JSON.parse(`"${m[1]}"`) : m[2]; } catch { cur.path = m[1]; }
    }
  }
  return {
    plugins: plugins.filter((p) => p.enabled).map((p) => p.key),
    off: new Set(skills.filter((s) => !s.enabled && s.path).map((s) => expand(s.path))),
  };
}

/** One Codex plugin's skills: from the newest copy of it Codex keeps. */
function codexPluginSkills(home, key, into) {
  const [plugin, market] = key.split('@');
  if (!plugin || !market || !SKILL_NAME.test(plugin) || !/^[A-Za-z0-9_.-]+$/.test(market) || market.startsWith('.')) return;
  const base = path.join(home, 'plugins', 'cache', market, plugin);
  let copies;
  try { copies = fs.readdirSync(base, { withFileTypes: true }).filter((d) => !d.name.startsWith('.') && (d.isDirectory() || d.isSymbolicLink())); } catch { return; }
  const newest = copies.map((d) => { const p = path.join(base, d.name); let t = 0; try { t = fs.statSync(p).mtimeMs; } catch { /* gone */ } return { p, t }; }).sort((a, b) => b.t - a.t)[0];
  if (newest) skillsIn(path.join(newest.p, 'skills'), plugin, into);
}

/** What T3 Code last listed for a sign-in, for skills the folders above did not give. */
function cachedSkills(instance) {
  if (!/^[A-Za-z0-9_-]+$/.test(instance)) return [];
  const list = readJson(path.join(T3_HOME, 'caches', `${instance}.json`))?.skills;
  return (Array.isArray(list) ? list : []).slice(0, 1000).flatMap((s) => {
    if (!s || typeof s.name !== 'string' || !SKILL_NAME.test(s.name) || s.enabled === false) return [];
    // A project's skills depend on the folder T3 Code looked in; those come from Bot HQ's folders.
    if (typeof s.scope === 'string' && !['user', 'system', 'admin', 'plugin'].includes(s.scope)) return [];
    if (typeof s.path === 'string' && s.path && !fs.existsSync(s.path)) return [];
    return [{ name: s.name, description: oneLine(s.description) }];
  });
}

/** One list from several: each name once (the first wins), only its name and description, in order of name, capped. */
function skillList(lists, cap) {
  const seen = new Set();
  const out = [];
  for (const s of lists.flat()) {
    const k = s.name.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push({ name: s.name, description: s.description ?? null });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name)).slice(0, cap);
}

/** The skills a bot running under one sign-in has, wherever it works. */
function signInSkills(si) {
  const mine = [];
  if (si.driver === 'codex') {
    const home = si.home ?? expand(process.env.CODEX_HOME) ?? path.join(os.homedir(), '.codex');
    const c = codexConfig(home);
    skillsIn(path.join(home, 'skills'), '', mine);
    skillsIn(path.join(os.homedir(), '.agents', 'skills'), '', mine);
    for (const key of c.plugins.slice(0, 100)) codexPluginSkills(home, key, mine);
    skillsIn(path.join(home, 'skills', '.system'), '', mine);
    const kept = mine.filter((s) => !c.off.has(path.resolve(s.file)));
    return skillList([kept, cachedSkills(si.instance)], SKILL_CAP.signIn);
  }
  const dir = si.home ?? expand(process.env.CLAUDE_CONFIG_DIR) ?? path.join(os.homedir(), '.claude');
  skillsIn(path.join(dir, 'skills'), '', mine);
  claudePluginSkills(dir, mine);
  return skillList([mine, cachedSkills(si.instance)], SKILL_CAP.signIn);
}

/** A project folder's own skills, for each tool. */
const projectSkills = (folder) => ({
  folder,
  claudeAgent: skillList([skillsIn(path.join(folder, '.claude', 'skills'))], SKILL_CAP.project),
  codex: skillList([skillsIn(path.join(folder, '.agents', 'skills'))], SKILL_CAP.project),
});

/** The project folders a Bot HQ names: whole paths only, each once, capped. */
const cleanFolders = (list) => [...new Set((Array.isArray(list) ? list : [])
  .filter((f) => typeof f === 'string' && f.length < 1000 && /^(\/|~(\/|$))/.test(f.trim()))
  .map(expand))].sort().slice(0, SKILL_CAP.folders);

state.skillFolders ??= {}; // Bot HQ -> the project folders it last named
let signInsListed = null;
const projectsListed = new Map();
/** What one Bot HQ is told: every sign-in's skills, and those of the folders it named. The hash says whether it changed. */
function skillsFor(srv, sis) {
  try {
    signInsListed ??= sis.map((si) => ({ instance: si.instance, driver: si.driver, name: si.name, skills: signInSkills(si) }));
    const projects = cleanFolders(state.skillFolders[srv.server]).map((f) => { if (!projectsListed.has(f)) projectsListed.set(f, projectSkills(f)); return projectsListed.get(f); });
    const lists = { signIns: signInsListed, projects };
    return { hash: crypto.createHash('sha256').update(JSON.stringify(lists)).digest('hex').slice(0, 32), ...lists };
  } catch (e) { log('could not list the skills here:', e.message); return null; }
}

/** After a check-in: note the folders that Bot HQ named, and send the list when what it has is not this. */
async function reportSkills(srv, told, report, sis) {
  const folders = cleanFolders(told.projects);
  if (JSON.stringify(folders) !== JSON.stringify(cleanFolders(state.skillFolders[srv.server]))) {
    state.skillFolders[srv.server] = folders;
    report = skillsFor(srv, sis);
  }
  if (!report || report.hash === told.hash) return null;
  await post(srv, 'skills', report);
  return report;
}

// ---------- working copies ----------

/**
 * The working copies (git worktrees) T3 Code made here: `<its worktrees folder>/<project>/<name>`, a
 * folder whose `.git` is a file pointing into the project's own repository. A bot with its own copy,
 * every helper it starts, a refreshed session that cannot reuse a folder, and every @mention thread
 * gets one, usually with the project's installed packages inside, and T3 Code removes none of them by
 * itself unless its own storage cleanup is set up. What the helper does with them:
 *
 *  - **Reports** the disk's free space and size, and how many copies there are, their size, and how
 *    many may be removed. Sent on a full round when it changed (a fingerprint, as for skills).
 *    Measuring a copy walks every file in it, so each is measured at most every 6 hours, within a
 *    time budget a round; which may be removed is worked out at most every 30 minutes.
 *  - **Removes** the ones that may be removed: on its own, at most once an hour, when Bot HQ's cleanup
 *    setting is on; or when someone chooses "Clean up now", after showing what would go.
 *
 * A copy may be removed only when every one of these holds, and when any of them cannot be checked
 * it is kept:
 *
 *  - It is one of T3 Code's own: a linked working copy directly inside its worktrees folder (not a
 *    link, not the project's own folder, not locked), of the T3 Code Bot HQ talks to here. Bot HQ says
 *    which that is (its environment id); another app's T3 Code folder is never looked in.
 *  - Nothing is uncommitted: `git status` lists no changed, staged or untracked file (ignored files
 *    such as installed packages do not count), no merge or rebase is under way, and it has no submodules.
 *  - Nothing is unpushed: every commit on it is on a remote branch here, or on the project's default branch.
 *  - Nobody is using it: no thread in T3 Code here that is running, queued or waiting works in it, nor
 *    one that failed in the last days (it may carry on once a usage limit resets), nor any thread a Bot
 *    HQ this helper serves says it uses (a conversation's current thread, one a refresh reads, an
 *    @mention thread); and nothing in it changed for the days set in Bot HQ.
 *
 * It is removed T3 Code's own way: its `vcs.removeWorktree` call (what its app uses), without force,
 * which runs `git worktree remove` and so refuses a copy with changes all over again. The branch stays,
 * and so does the thread: T3 Code makes the copy again from that branch when the thread is next given
 * work, so a thread a person opens later carries on (its installed packages need installing again).
 */
const COPIES = {
  max: 500, every: 30 * 60_000, measureEvery: 6 * 3600_000, measureBudget: 40_000,
  walkEntries: 2_000_000, walkMs: 120_000, autoEvery: 3600_000, toldFresh: 20 * 60_000, gitMs: 30_000, threadReads: 400,
};
const DAY = 86_400_000;
/** Thread states in which a thread is at work or about to be. */
const BUSY = ['preparing', 'queued', 'starting', 'running', 'waiting'];
state.copies ??= {};
state.copies.sizes ??= {}; // copy path -> { bytes, newest, at, partial }
state.copies.told ??= {}; // Bot HQ -> { environmentId, auto, days, keep: [thread id], at }
state.copies.unsent ??= {}; // Bot HQ -> removals it has not been told about yet

const gitBin = () => cfg.git || onPath('git') || '/usr/bin/git';
/** Run git in a folder; resolves with what it printed, or null when it failed. Never takes a lock it does not need. */
function git(cwd, args, ms = COPIES.gitMs) {
  return new Promise((resolve) => {
    execFile(gitBin(), ['-C', cwd, '-c', 'core.fsmonitor=false', ...args], { timeout: ms, maxBuffer: 32 * 1024 * 1024, cwd: os.tmpdir(), env: { ...process.env, GIT_OPTIONAL_LOCKS: '0', GIT_TERMINAL_PROMPT: '0', LC_ALL: 'C' } },
      (err, stdout) => resolve(err ? null : String(stdout)));
  });
}
const inside = (root, p) => { const r = path.relative(root, p); return !!r && r !== '..' && !r.startsWith(`..${path.sep}`) && !path.isAbsolute(r); };
const real = (p) => { try { return fs.realpathSync(p); } catch { return null; } };

/** T3 Code's worktrees folders here: its own, the one its settings name instead, and those it used before. */
function copyRoots() {
  const s = readSettings();
  const named = [path.join(T3_HOME, 'worktrees'), expand(s.worktreesDirectory), ...(Array.isArray(s.previousWorktreesDirectories) ? s.previousWorktreesDirectories.map(expand) : [])];
  const home = real(os.homedir());
  const out = [];
  for (const d of named) {
    const r = d ? real(d) : null;
    if (r && r !== path.parse(r).root && r !== home && !out.includes(r)) out.push(r);
  }
  return out;
}

/** The copies in those folders: `<folder>/<project>/<name>` with a `.git` file. Links and anything else are not looked at. */
function listCopies(roots) {
  const out = [];
  for (const root of roots) {
    let projects; try { projects = fs.readdirSync(root, { withFileTypes: true }); } catch { continue; }
    for (const p of projects) {
      if (!p.isDirectory() || p.name.startsWith('.')) continue;
      let names; try { names = fs.readdirSync(path.join(root, p.name), { withFileTypes: true }); } catch { continue; }
      for (const n of names) {
        if (!n.isDirectory() || n.name.startsWith('.')) continue;
        const at = path.join(root, p.name, n.name);
        try { if (!fs.lstatSync(path.join(at, '.git')).isFile()) continue; } catch { continue; }
        out.push({ path: at, root, folder: p.name });
        if (out.length >= COPIES.max) return out;
      }
    }
  }
  return out;
}

/**
 * Everything in a folder, without following links: the space it takes and when anything in it last
 * changed. A file with more than one link is not counted, since removing the folder does not free it
 * (a package manager's shared store). Stops at a limit and says so (`partial`).
 */
function walk(dir, ms = COPIES.walkMs) {
  const end = Date.now() + ms;
  let bytes = 0, newest = 0, entries = 0;
  const stack = [dir];
  while (stack.length) {
    if (entries >= COPIES.walkEntries || Date.now() > end) return { bytes, newest, partial: true };
    const d = stack.pop();
    let names; try { names = fs.readdirSync(d); } catch { return { bytes, newest, partial: true }; }
    for (const name of names) {
      let st; try { st = fs.lstatSync(path.join(d, name)); } catch { continue; } // gone meanwhile
      entries++;
      newest = Math.max(newest, st.mtimeMs);
      if (st.isDirectory()) stack.push(path.join(d, name));
      if (st.isDirectory() || st.nlink <= 1) bytes += typeof st.blocks === 'number' ? st.blocks * 512 : st.size;
    }
  }
  return { bytes, newest, partial: false };
}

/** When git last moved this copy along (a commit, a checkout): from its own records in the repository. */
function gitChangedAt(gitDir, common, branch) {
  let t = 0;
  for (const f of [path.join(gitDir, 'HEAD'), path.join(gitDir, 'logs', 'HEAD'), path.join(gitDir, 'ORIG_HEAD'), ...(branch ? [path.join(common, 'logs', 'refs', 'heads', ...branch.split('/'))] : [])]) {
    try { t = Math.max(t, fs.statSync(f).mtimeMs); } catch { /* none */ }
  }
  return t;
}

/**
 * What git says about one copy: whether it is one T3 Code made for a project and has nothing that
 * is not saved elsewhere. Every git call that fails, or answers what it should not, keeps it.
 */
async function inspectCopy(c, roots) {
  const keep = (reason, more = {}) => ({ path: c.path, folder: c.folder, project: c.folder, branch: null, removable: false, reason, ...more });
  const at = real(c.path);
  const parent = real(path.dirname(c.path));
  if (!at || !parent) return keep('could not be read');
  if (at !== path.join(parent, path.basename(c.path))) return keep('is a link');
  if (!roots.some((r) => inside(r, at))) return keep('is outside T3 Code’s working copies folder');
  const revs = (await git(at, ['rev-parse', '--path-format=absolute', '--show-toplevel', '--git-dir', '--git-common-dir']))?.trim().split('\n');
  if (!revs || revs.length !== 3) return keep('git could not read it');
  const [top, gitDir, common] = revs.map((p) => real(p) ?? p);
  if (top !== at) return keep('is not the top of a working copy');
  if (path.dirname(gitDir) !== path.join(common, 'worktrees')) return keep('is not a linked working copy');
  // The project's own folder is the first git lists; this copy must be one of the others.
  const listed = await git(at, ['worktree', 'list', '--porcelain']);
  if (listed === null) return keep('git could not list the project’s working copies');
  const blocks = listed.split(/\n\n+/).map((b) => b.split('\n').filter(Boolean)).filter((b) => b[0]?.startsWith('worktree '));
  const pathOf = (b) => real(b[0].slice(9)) ?? path.resolve(b[0].slice(9));
  const main = blocks[0] ? pathOf(blocks[0]) : null;
  const mine = blocks.slice(1).find((b) => pathOf(b) === at);
  if (!main || main === at || roots.some((r) => main === r || inside(r, main) || inside(main, r))) return keep('is a project’s own folder');
  if (!mine) return keep('git does not list it as one of the project’s working copies');
  const project = path.basename(main);
  const branch = mine.find((l) => l.startsWith('branch refs/heads/'))?.slice(18) ?? null;
  const more = { project, branch, main, gitDir, common };
  if (mine.some((l) => l === 'locked' || l.startsWith('locked '))) return keep('is locked in git', more);
  if (mine.some((l) => l === 'prunable' || l.startsWith('prunable '))) return keep('git says it is missing', more);
  for (const f of ['MERGE_HEAD', 'CHERRY_PICK_HEAD', 'REVERT_HEAD', 'BISECT_LOG', 'rebase-merge', 'rebase-apply', 'sequencer']) {
    if (fs.existsSync(path.join(gitDir, f))) return keep('has a merge, rebase or similar under way', more);
  }
  if (fs.existsSync(path.join(at, '.gitmodules')) || fs.existsSync(path.join(gitDir, 'modules'))) return keep('has submodules', more);
  const status = await git(at, ['status', '--porcelain=v1', '-z', '--untracked-files=all', '--ignore-submodules=none']);
  if (status === null) return keep('git could not say whether it has changes', more);
  const lines = status.split('\0').filter(Boolean);
  if (lines.some((l) => !l.startsWith('??'))) return keep('has uncommitted changes', more);
  if (lines.length) return keep('has untracked files', more);
  const head = (await git(at, ['rev-parse', '--verify', '--quiet', 'HEAD^{commit}']))?.trim();
  if (!head || !/^[0-9a-f]{40,64}$/.test(head)) return keep('has no commits', more);
  // Pushed: no commit on it that is not on a remote branch here or on the project's default branch.
  const defaults = await defaultBranches(at);
  if (defaults === null) return keep('git could not say whether it is pushed', more);
  const unpushed = await git(at, ['rev-list', '-n', '1', head, '--not', '--remotes', ...defaults]);
  if (unpushed === null) return keep('git could not say whether it is pushed', more);
  if (unpushed.trim()) return keep('has commits that are not pushed', more);
  return { ...more, path: c.path, real: at, folder: c.folder, head, removable: true, reason: null, gitChanged: gitChangedAt(gitDir, common, branch) };
}

/** The project's default branch here, as a ref: the one its remote names, else main or master. Null when git could not say. */
async function defaultBranches(at) {
  const remotes = await git(at, ['remote']);
  if (remotes === null) return null;
  const names = [];
  for (const remote of remotes.split('\n').map((r) => r.trim()).filter(Boolean)) {
    const ref = (await git(at, ['symbolic-ref', '--quiet', `refs/remotes/${remote}/HEAD`]))?.trim();
    if (ref?.startsWith(`refs/remotes/${remote}/`)) names.push(ref.slice(`refs/remotes/${remote}/`.length));
  }
  for (const name of [...new Set([...names, 'main', 'master'])]) {
    if ((await git(at, ['rev-parse', '--verify', '--quiet', `refs/heads/${name}^{commit}`])) !== null) return [`refs/heads/${name}`];
  }
  return [];
}

/** T3 Code's MCP endpoint here, with a session the helper issued: enough to read threads. */
function localMcp(base, token) {
  let sid = null, n = 0, ready = null;
  const post = async (body) => {
    const r = await fetch(`${base}/mcp`, { method: 'POST', signal: AbortSignal.timeout(30_000), headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json', accept: 'application/json, text/event-stream', ...(sid ? { 'mcp-session-id': sid } : {}) }, body: JSON.stringify(body) });
    sid = r.headers.get('mcp-session-id') ?? sid;
    const text = await r.text();
    if (!r.ok) throw new Error(`T3 Code answered ${r.status}`);
    let msg = null;
    for (const line of text.split('\n')) { if (line.startsWith('data:')) { try { const d = JSON.parse(line.slice(5)); if (d && (d.result !== undefined || d.error !== undefined)) msg = d; } catch { /* partial */ } } }
    if (!msg) { try { msg = JSON.parse(text); } catch { /* none */ } }
    return msg;
  };
  return {
    async call(name, args) {
      try {
        ready ??= (async () => {
          if (!(await post({ jsonrpc: '2.0', id: ++n, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'bothq-helper', version: VERSION } } }))?.result) throw new Error('no answer');
          await post({ jsonrpc: '2.0', method: 'notifications/initialized' });
        })();
        await ready;
        const res = (await post({ jsonrpc: '2.0', id: ++n, method: 'tools/call', params: { name, arguments: args } }))?.result;
        if (!res) return { ok: false, code: 'protocol' };
        let v = res.structuredContent;
        if (v === undefined) { try { v = JSON.parse((res.content ?? []).filter((c) => c?.type === 'text').map((c) => c.text).join('\n')); } catch { v = null; } }
        return res.isError ? { ok: false, code: String(v?.code ?? 'failed') } : { ok: true, value: v };
      } catch { return { ok: false, code: 'unreachable' }; }
    },
  };
}

/**
 * The folders in use: those of the threads named (by every Bot HQ here) and of every thread in T3
 * Code here that is at work, or failed in the last `days`. Asked of T3 Code itself, with a read-only
 * session revoked straight after. `error` when it could not be asked, in which case nothing is removed.
 */
async function foldersInUse(named, days, given = []) {
  const base = localT3();
  if (!base) return { error: 'T3 Code is not running here' };
  const issued = await t3(['auth', 'session', 'issue', '--scope', 'orchestration:read', '--subject', 'mcp-client', '--ttl', '2m', '--label', 'Bot HQ helper (checking working copies)', '--json']);
  const s = issued?.ok ? jsonIn(issued.out, '{') : null;
  if (!s?.token || !s?.sessionId) return { error: 'could not ask T3 Code which threads are at work' };
  try {
    const mcp = localMcp(base, s.token);
    const ids = new Set(named);
    for (const statuses of [BUSY, ['failed']]) {
      let cursor = 0;
      for (let page = 0; cursor !== null && cursor !== undefined; page++) {
        if (page >= 20) return { error: 'too many threads to check' };
        const r = await mcp.call('t3_thread_list', { allProjects: true, includeSubagents: true, statuses, limit: 100, cursor });
        if (!r.ok || !Array.isArray(r.value?.threads)) return { error: 'could not ask T3 Code which threads are at work' };
        for (const t of r.value.threads) {
          if (typeof t?.threadId !== 'string') continue;
          if (statuses === BUSY || !(Date.parse(t.updatedAt) < Date.now() - days * DAY)) ids.add(t.threadId);
        }
        cursor = r.value.nextCursor;
      }
    }
    if (ids.size > COPIES.threadReads) return { error: 'too many threads to check' };
    const folders = new Set(given.map((f) => real(f) ?? path.resolve(f)));
    for (const id of ids) {
      const r = await mcp.call('t3_thread_read', { threadId: id, limit: 1, runLimit: 1 });
      if (!r.ok && r.code === 'thread_not_found') continue; // deleted: it has no folder to keep
      if (!r.ok || !r.value?.thread) return { error: 'could not read a thread’s folder from T3 Code' };
      const wp = r.value.thread.worktreePath;
      if (typeof wp === 'string' && wp.trim()) folders.add(real(wp) ?? path.resolve(wp));
    }
    return { folders };
  } finally { await t3(['auth', 'session', 'revoke', String(s.sessionId)]); }
}

const OTHER_T3 = 'this is not the T3 Code that Bot HQ uses here';
const UNKNOWN_T3 = 'Bot HQ does not know which T3 Code it uses here';
/**
 * What the Bot HQs here said about working copies, together: every one's threads are kept, the most
 * days any of them asks for are waited, and removal is refused (`error`) unless every one of them
 * has said so lately, of this T3 Code. `asking`: a Bot HQ's word given with a task, newer than the check-in's.
 */
function copyRules(asking) {
  const env = environmentId();
  const tolds = SERVERS.map((srv) => (srv.server === asking?.server ? asking.told : state.copies.told[srv.server]) ?? null);
  const known = tolds.filter(Boolean);
  const days = Math.max(1, ...known.map((t) => t.days));
  if (!known.length) return { error: 'Bot HQ has not said which threads it uses', none: true, days, keep: [], folders: [], auto: false };
  if (known.some((t) => !t.environmentId)) return { error: UNKNOWN_T3, other: 'unknown-t3', days, keep: [], folders: [], auto: false };
  if (!env || known.some((t) => t.environmentId !== env)) return { error: OTHER_T3, other: 'other-t3', days, keep: [], folders: [], auto: false };
  const keep = new Set(known.flatMap((t) => t.keep));
  const folders = [...new Set(known.flatMap((t) => t.folders))];
  // Every Bot HQ here may have conversations on this machine: one that has not said lately which threads it uses blocks removal.
  if (tolds.some((t) => !t || !(Date.now() - t.at < COPIES.toldFresh))) return { error: 'a Bot HQ this helper serves has not said lately which threads it uses', days, keep: [...keep], folders, auto: false };
  // Removing by itself takes every Bot HQ here having switched it on: one that has it off was promised nothing goes unasked.
  return { days, keep: [...keep], folders, auto: known.every((t) => t.auto) };
}

/** One look at every copy: what git says, its size as last measured, and (for the ones git would let go) whether anyone uses it. */
async function assessCopies(rules, { fresh = false } = {}) {
  const roots = copyRoots();
  const list = listCopies(roots);
  const out = [];
  for (const c of list) out.push(await inspectCopy(c, roots));
  const cutoff = Date.now() - rules.days * DAY;
  const sized = (c) => {
    const m = state.copies.sizes[c.path];
    return { ...c, bytes: m?.bytes ?? null, newest: Math.max(m?.newest ?? 0, c.gitChanged ?? 0), measured: !!m && !m.partial };
  };
  let all = out.map(sized);
  for (const c of all) {
    if (!c.removable) continue;
    if (fresh) {
      const w = walk(c.real);
      state.copies.sizes[c.path] = { bytes: w.bytes, newest: w.newest, partial: w.partial, at: Date.now() };
      Object.assign(c, sized(c));
    }
    if (!c.measured) Object.assign(c, { removable: false, reason: c.bytes === null ? 'has not been measured yet' : 'could not be measured in full' });
    else if (!(c.newest < cutoff)) Object.assign(c, { removable: false, reason: `changed in the last ${rules.days} day${rules.days === 1 ? '' : 's'}` });
  }
  const left = all.filter((c) => c.removable);
  if (left.length) {
    const used = rules.error ? { error: rules.error } : await foldersInUse(rules.keep, rules.days, rules.folders);
    for (const c of left) {
      if (used.error) Object.assign(c, { removable: false, reason: used.error });
      else if ([...used.folders].some((f) => f === c.real || inside(c.real, f))) Object.assign(c, { removable: false, reason: 'a thread is using it' });
    }
  }
  for (const k of Object.keys(state.copies.sizes)) if (!list.some((c) => c.path === k)) delete state.copies.sizes[k];
  return all;
}

/** Measure the copies whose size is missing or old, oldest first, within a round's budget. */
function measureCopies() {
  const end = Date.now() + COPIES.measureBudget;
  const list = listCopies(copyRoots()).map((c) => ({ ...c, m: state.copies.sizes[c.path] })).sort((a, b) => (a.m?.at ?? 0) - (b.m?.at ?? 0));
  for (const c of list) {
    if (Date.now() > end) break;
    if (c.m && Date.now() - c.m.at < COPIES.measureEvery) continue;
    const at = real(c.path);
    if (!at) continue;
    const w = walk(at, Math.max(1000, Math.min(COPIES.walkMs, end - Date.now())));
    state.copies.sizes[c.path] = { bytes: w.bytes, newest: w.newest, partial: w.partial, at: Date.now() };
  }
}

/** Remove one copy T3 Code's way (its `vcs.removeWorktree`, no force). Resolves with null, or why not. */
async function removeOne(base, token, c) {
  if (typeof WebSocket !== 'function') {
    // Node before 22 has no WebSocket: the same command T3 Code runs, from here.
    return (await git(c.main, ['-c', 'status.showUntrackedFiles=normal', 'worktree', 'remove', c.real], 300_000)) === null ? 'git would not remove it' : null;
  }
  let ticket = null;
  try {
    const r = await fetch(`${base}/api/auth/websocket-ticket`, { method: 'POST', headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(15_000) });
    ticket = r.ok ? (await r.json())?.ticket : null;
  } catch { /* not reachable */ }
  if (typeof ticket !== 'string' || !ticket) return 'T3 Code could not be reached';
  const r = await wsCall(`${base.replace(/^http/, 'ws')}/ws?orchestrationProtocol=2&wsTicket=${encodeURIComponent(ticket)}`, 'vcs.removeWorktree', { cwd: c.main, path: c.real, force: false }, 300_000);
  return r.exit?._tag === 'Success' ? null : r.reason === 'no-answer' ? 'T3 Code did not answer' : 'T3 Code would not remove it';
}

/**
 * Remove the copies that may go (only those in `only`, when given): each is looked at afresh first,
 * every file walked, and T3 Code asked again who uses it, straight before. Answers what went and what stayed.
 */
async function cleanCopies(rules, only = null, by = 'auto') {
  if (rules.error) return { removed: [], kept: [], error: rules.error };
  const all = await assessCopies(rules, { fresh: true });
  // Who uses what is asked again during a long run of removals.
  let used = { folders: new Set(), at: 0 };
  const inUse = async (c) => {
    if (Date.now() - used.at > 60_000) {
      const u = await foldersInUse(rules.keep, rules.days, rules.folders);
      if (u.error) return u.error;
      used = { folders: u.folders, at: Date.now() };
    }
    return [...used.folders].some((f) => f === c.real || inside(c.real, f)) ? 'a thread is using it' : null;
  };
  const chosen = all.filter((c) => !only || only.includes(c.path));
  const go = chosen.filter((c) => c.removable);
  const removed = [];
  const kept = chosen.filter((c) => !c.removable).map((c) => ({ path: c.path, project: c.project, branch: c.branch, reason: c.reason }));
  if (!go.length) return { removed, kept };
  const base = localT3();
  const issued = base ? await t3(['auth', 'session', 'issue', '--scope', 'source-control:write', '--ttl', '10m', '--label', 'Bot HQ helper (removing finished working copies)', '--json']) : null;
  const s = issued?.ok ? jsonIn(issued.out, '{') : null;
  if (!s?.token || !s?.sessionId) return { removed, kept: [...kept, ...go.map((c) => ({ path: c.path, project: c.project, branch: c.branch, reason: base ? 'could not get T3 Code’s leave to remove it' : 'T3 Code is not running here' }))] };
  try {
    for (const c of go) {
      // Its commit, and that it is still clean, once more: a moment may have passed since the look above.
      const again = await inspectCopy({ path: c.path, folder: c.folder }, copyRoots());
      if (!again.removable || again.head !== c.head) { kept.push({ path: c.path, project: c.project, branch: c.branch, reason: again.reason ?? 'changed while being checked' }); continue; }
      const why = (await inUse(c)) ?? (await removeOne(base, s.token, c));
      if (why) { kept.push({ path: c.path, project: c.project, branch: c.branch, reason: why }); continue; }
      delete state.copies.sizes[c.path];
      removed.push({ path: c.path, project: c.project, branch: c.branch, bytes: c.bytes ?? 0, at: Date.now(), by });
      log('removed the working copy', c.path, c.branch ? `(branch ${c.branch} kept)` : '');
    }
  } finally { await t3(['auth', 'session', 'revoke', String(s.sessionId)]); }
  if (removed.length) for (const srv of SERVERS) state.copies.unsent[srv.server] = [...(state.copies.unsent[srv.server] ?? []), ...removed].slice(-500);
  return { removed, kept };
}

/** The disk T3 Code's data is on: free space and size. Null when the system will not say. */
function diskSpace() {
  try {
    const s = fs.statfsSync(real(T3_HOME) ?? os.homedir());
    return { free: Number(s.bavail) * Number(s.bsize), size: Number(s.blocks) * Number(s.bsize) };
  } catch { return null; }
}

const GB = 1024 ** 3;
/** What Bot HQ is told about the copies, from the last look. Its hash changes only when something worth showing does. */
function copiesReport() {
  const disk = diskSpace();
  const last = state.copies.last ?? null;
  const report = { disk, copies: last ? { count: last.count, bytes: last.bytes, removable: last.removable, removableBytes: last.removableBytes, checkedAt: last.at } : null, error: state.copies.error ?? null };
  const round = (n, step) => (typeof n === 'number' ? Math.round(n / step) : null);
  const print = { free: round(disk?.free, GB), size: round(disk?.size, GB), c: last && [last.count, round(last.bytes, 0.1 * GB), last.removable, round(last.removableBytes, 0.1 * GB)], e: report.error };
  return { hash: crypto.createHash('sha256').update(JSON.stringify(print)).digest('hex').slice(0, 32), ...report };
}

/** Look again at which copies may go (every 30 minutes, or when asked), and keep the totals for the report. */
async function lookAtCopies(force = false) {
  const rules = copyRules();
  if (rules.none) return rules;
  if (rules.other) {
    // Another app's folder (or one Bot HQ cannot vouch for): nothing in it is counted.
    state.copies.error = rules.other;
    state.copies.last = null;
    return rules;
  }
  const was = state.copies.error ?? null;
  state.copies.error = null;
  if (!force && was === null && state.copies.last && Date.now() - state.copies.last.at < COPIES.every) return rules;
  measureCopies();
  // A Bot HQ that has not said lately which threads it uses stops removal, not the counting (none counts as removable then).
  const all = await assessCopies(rules);
  const sum = (l) => l.reduce((n, c) => n + (c.bytes ?? 0), 0);
  const go = all.filter((c) => c.removable);
  state.copies.last = { at: Date.now(), count: all.length, bytes: sum(all), removable: go.length, removableBytes: sum(go) };
  return rules;
}

/** What one Bot HQ said in its check-in answer about copies, kept for rounds to come. */
function noteCopies(srv, told) {
  if (!told || typeof told !== 'object') return;
  const days = Math.min(365, Math.max(1, Math.round(Number(told.days)) || 7));
  state.copies.told[srv.server] = {
    environmentId: typeof told.environmentId === 'string' ? told.environmentId : null,
    auto: told.auto === true, days,
    keep: (Array.isArray(told.keep) ? told.keep : []).filter((k) => typeof k === 'string').slice(0, 2000),
    folders: (Array.isArray(told.folders) ? told.folders : []).filter((f) => typeof f === 'string' && path.isAbsolute(f)).slice(0, 500),
    at: Date.now(),
  };
}

/** After every Bot HQ's check-in: look again when due, clean up on its own when that is on and due, and send what changed. */
async function copiesRound(full, toldCopies) {
  let rules = await lookAtCopies();
  if (!rules.error && rules.auto && !(Date.now() - (state.copies.autoAt ?? 0) < COPIES.autoEvery)) {
    state.copies.autoAt = Date.now();
    const r = await cleanCopies(rules, null, 'auto');
    if (r.removed.length) log(`removed ${r.removed.length} finished working cop${r.removed.length === 1 ? 'y' : 'ies'} on its own (Bot HQ’s cleanup is on)`);
    if (r.removed.length) rules = await lookAtCopies(true);
  }
  for (const srv of full) {
    const told = toldCopies.get(srv.server);
    if (!told) continue;
    const report = copiesReport();
    const unsent = state.copies.unsent[srv.server] ?? [];
    if (report.hash === told.hash && !unsent.length) continue;
    try {
      await post(srv, 'worktrees', { ...report, removed: unsent });
      state.copies.unsent[srv.server] = (state.copies.unsent[srv.server] ?? []).slice(unsent.length);
    } catch (e) { log(`[${srv.name}]`, 'could not report working copies:', e.message); }
  }
}

/** "Clean up now" from Bot HQ: first what would go (`copies-check`), then removing what was shown (`copies-clean`). */
async function copiesTask(srv, task) {
  const told = { environmentId: typeof task.environmentId === 'string' ? task.environmentId : null, auto: false, days: Math.min(365, Math.max(1, Math.round(Number(task.days)) || 7)), keep: (Array.isArray(task.keep) ? task.keep : []).filter((k) => typeof k === 'string'), folders: (Array.isArray(task.folders) ? task.folders : []).filter((f) => typeof f === 'string' && path.isAbsolute(f)), at: Date.now() };
  const rules = copyRules({ server: srv.server, told });
  if (rules.error) return { kind: task.kind, id: task.id, ok: false, error: rules.error };
  if (task.kind === 'copies-check') {
    measureCopies();
    const all = await assessCopies(rules, { fresh: true });
    return { kind: task.kind, id: task.id, ok: true, disk: diskSpace(), copies: all.map((c) => ({ path: c.path, project: c.project, branch: c.branch, bytes: c.bytes, removable: c.removable, reason: c.reason })) };
  }
  const only = (Array.isArray(task.paths) ? task.paths : []).filter((p) => typeof p === 'string');
  const r = await cleanCopies(rules, only, 'manual');
  if (r.removed.length) await lookAtCopies(true);
  // Every Bot HQ here is told again with its next report (this one too, should this answer not reach it); each keeps a removal once.
  return { kind: task.kind, id: task.id, ok: !r.error, error: r.error, removed: r.removed, kept: r.kept };
}

// ---------- the round ----------

// The installer's first round after adding a Bot HQ is for that one alone (BOTHQ_HELPER_ONLY=<its address>).
const ONLY = process.env.BOTHQ_HELPER_ONLY ? process.env.BOTHQ_HELPER_ONLY.trim().replace(/\/+$/, '') : null;
const serving = ONLY ? SERVERS.filter((s) => s.server === ONLY) : SERVERS;
if (!serving.length) { log(ONLY ? `${ONLY} is not one of the Bot HQs in ${CONFIG}` : `no Bot HQ is set up in ${CONFIG}`); process.exit(1); }

keepSchedule();

// Run by the schedule (every 30 seconds), a Bot HQ checked in with less than its `every` ago (5
// minutes) is only asked whether anything cannot wait: one small request, nothing read on this
// machine, nothing logged when there is nothing to do. Any other run is a full round for each.
const SCHEDULED = process.argv.includes('--scheduled');
state.rounds ??= {}; // Bot HQ -> { at, every }: when its last full round was, and how often it wants one
const quick = (srv) => {
  const r = state.rounds[srv.server];
  return SCHEDULED && r && Number.isFinite(r.at) && Date.now() - r.at >= 0 && Date.now() - r.at < Math.max(60, Number(r.every) || 300) * 1000 - 15_000;
};

let failed = 0;
const stays = [];
const offers = [];
for (const srv of serving.filter(quick)) {
  try {
    const told = await post(srv, 'work', { results: [], signingIn: [], can: CAN });
    if (told.work?.length || told.stay) stays.push({ srv, told });
  } catch { /* the full round says when a Bot HQ cannot be reached */ }
}
const full = serving.filter((s) => !quick(s));

const here = full.length ? signIns() : [];
const accounts = [];
for (const si of here) { const a = await accountIn(si, false); accounts.push({ instance: si.instance, driver: si.driver, name: si.name, account: a?.account ?? null }); }
// The default sign-ins in the shape a version 1 Bot HQ reads too.
const who = { codex: accounts.find((a) => a.instance === 'codex')?.account ?? null, claude: accounts.find((a) => a.instance === 'claudeAgent')?.account ?? null };
const envId = full.length ? environmentId() : null;
const linkList = full.length ? await links() : null;
const githubList = full.length ? await githubAccounts() : null;
const github = githubList ? { host: GH_HOST, accounts: githubList } : null;

// Each Bot HQ in turn. One that fails, or does not answer within a minute, does not stop the rest.
const toldCopies = new Map(); // Bot HQ -> what its answer said about working copies
for (const srv of full) {
  const say = (...a) => log(`[${srv.name}]`, ...a);
  try {
    // The skills go as a hash only; the list itself only when this Bot HQ's copy is not the same.
    const skills = skillsFor(srv, here);
    // The working copies go the same way: a hash, and the report itself only when Bot HQ's is not the same.
    // Version 9: the Bot HQs this one shared this machine with that the helper still serves (their addresses only), so its "Also used by" stays true.
    const shared = SERVERS.filter((o) => o.by === srv.server).map((o) => o.server);
    const told = await post(srv, 'checkin', { version: VERSION, host: os.hostname(), tools: who, accounts, environmentId: envId, links: linksFor(srv, linkList), github, can: CAN, shared, ...(skills ? { skills: { hash: skills.hash } } : {}), copies: { hash: copiesReport().hash } });
    state.rounds[srv.server] = { at: Date.now(), every: Number(told.every) || 300 };
    noteKeeps(srv, told.keeps);
    say('checked in;', 'signed in:', accounts.filter((a) => (a.driver === 'codex' ? a.account?.account : a.account)).map((a) => a.instance).join(', ') || 'nothing', '| asked to fetch:', told.fetch?.join(', ') || 'nothing', '| renew:', !!told.renew, '| work:', told.work?.length ?? 0);
    if (told.fetch?.length) {
      // Bot HQ names the sign-ins to ask about by their T3 Code id ('codex', 'claudeAgent', or an added one).
      const out = [];
      for (const si of here.filter((x) => told.fetch.includes(x.instance))) { const a = await accountIn(si, true); if (a) out.push({ instance: si.instance, driver: si.driver, ...a }); }
      await post(srv, 'limits', { accounts: out });
      say('reported limits for', out.map((a) => a.instance).join(', ') || 'nothing');
    }
    if (told.renew) {
      const code = await pairingCode();
      const r = await post(srv, 'renew', { code });
      say(r.ok ? 'renewed Bot HQ’s access to this machine' : `renewing did not work: ${r.error ?? 'no reason given'}`);
    }
    // A Bot HQ from before skills could be listed says nothing of them, and is sent nothing more.
    if (told.skills && typeof told.skills === 'object') {
      try {
        const sent = await reportSkills(srv, told.skills, skills, here);
        if (sent) say('listed skills:', sent.signIns.map((s) => `${s.instance} ${s.skills.length}`).join(', ') || 'no sign-ins', sent.projects.length ? `| ${sent.projects.length} project folder(s)` : '');
      } catch (e) { say('could not list skills:', e.message); }
    }
    // A Bot HQ from before working copies were reported says nothing of them, and is sent nothing more.
    if (told.copies && typeof told.copies === 'object') { noteCopies(srv, told.copies); toldCopies.set(srv.server, told.copies); }
    if (told.work?.length || told.stay) stays.push({ srv, told });
    if (told.update && Number(told.update) > Number(VERSION)) offers.push({ srv, version: String(told.update) });
  } catch (e) { failed++; say('this round failed:', e.message); }
}
if (full.length) saveState();
if (toldCopies.size) {
  try { await copiesRound(full, toldCopies); } catch (e) { log('could not look at the working copies here:', e.message); }
  saveState();
}

// Work that takes a while (links, sign-ins) is done for each Bot HQ side by side, so one that keeps
// the helper waiting does not hold up another.
await Promise.all(stays.map(({ srv, told }) => stayForWork(srv, told).catch((e) => { failed++; log(`[${srv.name}]`, 'staying for work failed:', e.message); })));
if (full.length || stays.length) saveState();

// Two Bot HQs may serve different helpers: the newest wins, and an older Bot HQ reads what it sends as it always has.
const newest = offers.sort((a, b) => Number(b.version) - Number(a.version))[0];
if (newest) await update(newest.srv, newest.version).catch((e) => log('updating the helper failed:', e.message));
if (failed) process.exitCode = 1;
