#!/usr/bin/env bash
# Set up a new coding machine for Bot HQ, with nobody typing a pairing code. Bot HQ shows this
# command (Settings, Coding machines, Add a new machine); run it on the new machine, as the person who
# codes there, after the machine has joined your Tailscale network:
#
#   curl -fsSL <bot hq address>/fleet/machine.sh | bash -s -- --server <bot hq address> --claim <claim>
#
#  1. Checks: a Mac with Apple silicon, or Linux on x86_64 or arm64; Node 20 or later; Tailscale
#     running. It stops, changing nothing, and says what to do when one is missing.
#  2. T3 Code: used as it is when stock T3 Code is here already (~/.local/bin/t3-stock). Otherwise it
#     installs T3 Code 0.1.9 the way Bot HQ's fleet machines have it (docs/fleet-rollout-codex-prompt.md):
#     the npm package `t3`, checked against its published checksum, unpacked in ~/.t3-stock, a command
#     ~/.local/bin/t3-stock, and a service that keeps it running on 127.0.0.1 only (a LaunchAgent on a
#     Mac, a systemd user service on Linux). Its first start downloads T3 Code's own program (about
#     350 MB) from T3 Code's releases, which it checks itself.
#  3. Shares T3 Code on your private network only (`tailscale serve`, never Funnel), if it is not already.
#  4. Installs the Bot HQ helper, which redeems the claim: Bot HQ then connects the machine by itself.
#
# Nothing else is changed: no shell profile, no global package, no other service or Serve entry. A
# T3 Code under another name here (such as a plain `t3`) is left alone.
#
# Options: --name <what to call it in Bot HQ>   --t3-port <T3 Code's port, default 3775 or the next free one>
#          --serve-port <its HTTPS port on the private network, default 8444 or the next free one>
set -euo pipefail
server=""; claim=""; name=""; t3port=""; serveport=""
while [ $# -gt 0 ]; do
  case "$1" in
    --server) server="${2%/}"; shift 2;; --claim) claim="$2"; shift 2;; --name) name="$2"; shift 2;;
    --t3-port) t3port="$2"; shift 2;; --serve-port) serveport="$2"; shift 2;;
    *) echo "unknown option: $1" >&2; exit 2;;
  esac
done
[ -n "$server" ] && [ -n "$claim" ] || { echo "usage: machine.sh --server <bot hq address> --claim <claim>  (Bot HQ shows the whole command)" >&2; exit 2; }

T3_VERSION=0.1.9
# The npm registry's dist.shasum for t3@0.1.9 (the same as on the fleet's machines).
T3_SHA1="${BOTHQ_T3_SHA1:-aa46bf50e9483fedec9edcd7b0422a3aa5bede49}"
T3_TARBALL="${BOTHQ_T3_TARBALL:-https://registry.npmjs.org/t3/-/t3-$T3_VERSION.tgz}"
T3S="$HOME/.t3-stock"
WRAP="$HOME/.local/bin/t3-stock"
OS="${BOTHQ_MACHINE_OS:-$(uname -s)}"
ARCH="${BOTHQ_MACHINE_ARCH:-$(uname -m)}"
say() { echo "• $*"; }
stop() { echo "Stopped: $*" >&2; exit 1; }
find_cmd() { command -v "$1" 2>/dev/null || true; }

# ---------- 1. checks (nothing is changed before they pass) ----------

case "$OS/$ARCH" in
  Darwin/arm64) ;;
  Darwin/*) stop "T3 Code $T3_VERSION has no build for Intel Macs. Use a Mac with Apple silicon, or a Linux machine." ;;
  Linux/x86_64|Linux/amd64|Linux/aarch64|Linux/arm64) ;;
  *) stop "This sets up a Mac with Apple silicon or a Linux machine (x86_64 or arm64); this one is $OS $ARCH." ;;
esac
node="$(find_cmd node)"
[ -n "$node" ] || stop "Node was not found. Install Node 20 or later (nodejs.org), then run this again."
"$node" -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>20||(a===20&&b>=11)?0:1)' || stop "Node 20.11 or later is needed (found $("$node" -v)). Update Node, then run this again."
node="$("$node" -e 'console.log(require("fs").realpathSync(process.execPath))')"
ts="${BOTHQ_TAILSCALE:-$(find_cmd tailscale)}"
[ -z "$ts" ] && [ -x /Applications/Tailscale.app/Contents/MacOS/Tailscale ] && ts=/Applications/Tailscale.app/Contents/MacOS/Tailscale
[ -n "$ts" ] || stop "Tailscale is not installed here. Install it (tailscale.com/download), sign in to your team's network, then run this again."
self="$("$ts" status --self --json 2>/dev/null | "$node" -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const j=JSON.parse(s);console.log(j.BackendState+" "+String(j.Self?.DNSName??"").replace(/\.$/,""))}catch{console.log("unknown ")}})')"
[ "${self%% *}" = Running ] || stop "Tailscale is not connected here. Open Tailscale, sign in to your team's network, then run this again."
dns="${self#* }"
[ -n "$dns" ] || stop "Tailscale did not say this machine's name on the network. Check that MagicDNS is on in Tailscale's admin page, DNS."
curl -fsS -o /dev/null --max-time 15 "$server/fleet/install.sh" || stop "This machine cannot reach Bot HQ at $server. Check that Tailscale is connected to the same network as Bot HQ."

port_free() { "$node" -e 'const s=require("net").connect(+process.argv[1],"127.0.0.1");s.on("connect",()=>{s.destroy();process.exit(1)});s.on("error",()=>process.exit(0))' "$1"; }
answers() { [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "http://127.0.0.1:$1/" || true)" != 000 ]; }

# ---------- 2. T3 Code ----------

if [ -x "$WRAP" ] && [ -d "$T3S" ]; then
  # Stock T3 Code is here already: where it runs, from the file it writes when it starts.
  port="$("$node" -e 'try{const r=require(process.argv[1]);console.log(Number(r.port)||"")}catch{console.log("")}' "$T3S/userdata/server-runtime.json")"
  [ -n "$t3port" ] && port="$t3port"
  [ -n "$port" ] && answers "$port" || stop "T3 Code is installed here ($WRAP) but is not running. Start it, then run this again."
  say "T3 Code is here already, on port $port. Using it as it is."
else
  port="$t3port"
  if [ -z "$port" ]; then for p in $(seq 3775 3799); do port_free "$p" && { port="$p"; break; }; done; fi
  [ -n "$port" ] || stop "No free port for T3 Code between 3775 and 3799."
  say "Installing T3 Code $T3_VERSION in $T3S (its first start downloads about 350 MB)…"
  tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
  curl -fsSL "$T3_TARBALL" -o "$tmp/t3.tgz" || stop "Could not download T3 Code."
  sum="$( (command -v shasum >/dev/null && shasum -a 1 "$tmp/t3.tgz" || sha1sum "$tmp/t3.tgz") | cut -d' ' -f1)"
  [ "$sum" = "$T3_SHA1" ] || stop "The T3 Code download did not match its published checksum, so it was not installed."
  tar -xzf "$tmp/t3.tgz" -C "$tmp"
  mkdir -p "$T3S/logs" "$T3S/workdir" "$(dirname "$WRAP")"
  [ -e "$T3S/launcher" ] || mv "$tmp/package" "$T3S/launcher"
  cat > "$WRAP" <<EOF
#!/bin/sh
# Stock T3 Code for Bot HQ, with its own data folder (~/.t3-stock).
export T3CODE_HOME="\$HOME/.t3-stock"
exec "$node" "\$HOME/.t3-stock/launcher/bin/t3.mjs" "\$@"
EOF
  chmod 755 "$WRAP"
  "$WRAP" --version >/dev/null || stop "T3 Code did not start (\"$WRAP --version\" failed). Its download from T3 Code's releases may have failed; run this again."
  # The service's PATH: T3 Code starts Codex, Claude Code, git and gh from it.
  svcpath="$HOME/.local/bin"
  for c in node codex claude git gh; do d="$(dirname "$(find_cmd "$c")" 2>/dev/null)"; [ -n "$(find_cmd "$c")" ] && case ":$svcpath:" in *":$d:"*) ;; *) svcpath="$svcpath:$d";; esac; done
  svcpath="$svcpath:/usr/bin:/bin:/usr/sbin:/sbin"
  if [ "$OS" = Darwin ]; then
    pl="$HOME/Library/LaunchAgents/io.bothq.t3stock.plist"
    mkdir -p "$(dirname "$pl")"
    cat > "$pl" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>io.bothq.t3stock</string>
  <key>ProgramArguments</key><array><string>$WRAP</string><string>serve</string><string>--host</string><string>127.0.0.1</string><string>--port</string><string>$port</string><string>--base-dir</string><string>$T3S</string><string>--no-browser</string><string>$T3S/workdir</string></array>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$svcpath</string><key>T3CODE_HOME</key><string>$T3S</string></dict>
  <key>KeepAlive</key><true/><key>RunAtLoad</key><true/><key>ThrottleInterval</key><integer>10</integer>
  <key>WorkingDirectory</key><string>$T3S/workdir</string>
  <key>StandardOutPath</key><string>/dev/null</string><key>StandardErrorPath</key><string>$T3S/logs/serve.err.log</string>
</dict></plist>
EOF
    launchctl bootout "gui/$(id -u)/io.bothq.t3stock" 2>/dev/null || true
    launchctl bootstrap "gui/$(id -u)" "$pl" || stop "macOS would not start T3 Code's service. This needs the person logged in at the Mac's screen."
  else
    unit="$HOME/.config/systemd/user/bothq-t3.service"
    mkdir -p "$(dirname "$unit")"
    printf '[Unit]\nDescription=T3 Code for Bot HQ\n[Service]\nEnvironment=PATH=%s\nEnvironment=T3CODE_HOME=%s\nWorkingDirectory=%s\nExecStart=%s serve --host 127.0.0.1 --port %s --base-dir %s --no-browser %s\nRestart=always\nRestartSec=10\n[Install]\nWantedBy=default.target\n' \
      "$svcpath" "$T3S" "$T3S/workdir" "$WRAP" "$port" "$T3S" "$T3S/workdir" > "$unit"
    systemctl --user daemon-reload && systemctl --user enable --now bothq-t3.service || stop "systemd would not start T3 Code's service (systemctl --user). On a machine without a user systemd, start \"$WRAP serve --host 127.0.0.1 --port $port --base-dir $T3S\" some other way, then run this again."
    echo "  To keep T3 Code running when nobody is logged in, run once: sudo loginctl enable-linger $(id -un)"
  fi
  for _ in $(seq 1 90); do answers "$port" && break; sleep 1; done
  answers "$port" || stop "T3 Code's service started but does not answer on 127.0.0.1:$port. Its log: $T3S/logs/serve.err.log"
  say "T3 Code is running on 127.0.0.1:$port."
fi

# ---------- 3. on the private network only ----------

base="$("$ts" serve status --json 2>/dev/null | "$node" -e '
  let s=""; process.stdin.on("data",(d)=>(s+=d)).on("end",()=>{
    let j={}; try { j=JSON.parse(s||"{}"); } catch {}
    for (const [hostport, w] of Object.entries(j.Web ?? {})) {
      if (w?.Handlers?.["/"]?.Proxy === `http://127.0.0.1:${process.argv[1]}`) return console.log(`https://${hostport.replace(/:443$/, "")}`);
    }
    console.log("");
  });' "$port")"
if [ -z "$base" ]; then
  used="$("$ts" serve status --json 2>/dev/null | "$node" -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{console.log(Object.keys(JSON.parse(s||"{}").TCP??{}).join(" "))}catch{console.log("")}})')"
  sp="$serveport"
  if [ -z "$sp" ]; then for p in $(seq 8444 8499); do case " $used " in *" $p "*) ;; *) sp="$p"; break;; esac; done; fi
  "$ts" serve --bg --https="$sp" "http://127.0.0.1:$port" >/dev/null 2>&1 \
    || stop "Tailscale would not share T3 Code on your network. Run this yourself (with sudo on Linux): tailscale serve --bg --https=$sp http://127.0.0.1:$port   then run this again."
  base="https://$dns:$sp"
  say "Shared T3 Code on your private network only, at $base."
else
  say "T3 Code is shared on your private network at $base."
fi

# ---------- 4. the helper, which redeems the claim ----------

say "Installing the Bot HQ helper and connecting this machine…"
curl -fsSL "$server/fleet/install.sh" | bash -s -- --server "$server" --claim "$claim" --t3 "$WRAP" --t3-home "$T3S" --base-url "$base" ${name:+--name "$name"}
say "Done. Bot HQ connects this machine by itself within a minute; it shows under Settings, Coding machines."
