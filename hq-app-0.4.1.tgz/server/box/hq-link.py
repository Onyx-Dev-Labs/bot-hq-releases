#!/usr/bin/env python3
"""Bot HQ's link on a person's own Orgo computer: the way its agent's tool calls reach Bot HQ.

An Orgo computer has no network device for Tailscale, so Tailscale runs there in userspace mode, and
an ordinary program cannot open a connection to an address on the private network. This program
listens on 127.0.0.1 and, for every connection made to it, opens a way through to Bot HQ's
private-network host and port, then copies bytes both ways until the connection is done. The agent's
`hq` tool server points at it (http://127.0.0.1:<port>/mcp/<bot>), so the agent needs no proxy
settings of its own. There are two ways through:

    hq-link.py --listen 127.0.0.1:PORT --proxy http://127.0.0.1:1055 --target bot-hq:8787
    hq-link.py --listen 127.0.0.1:PORT --proxy socks5://127.0.0.1:1055 --target bot-hq:8787
        tailscaled's own proxy, when it was started with one (--outbound-http-proxy-listen or
        --socks5-server). The proven way, used whenever there is one.

    hq-link.py --listen 127.0.0.1:PORT --tailscale-nc /usr/bin/tailscale [--socket PATH] --target bot-hq:8787
        `tailscale nc HOST PORT`, one for each connection, through the tailscaled that already runs
        (--socket: its socket, when it is not the usual one). It needs nothing changed on the
        computer, so it is the way for a Tailscale the person runs themselves without a proxy.
        `tailscale nc` ends the whole connection as soon as its input ends, so a client that
        half-closes (stops sending, still waiting for the answer) is not passed on: its input is kept
        open until Bot HQ has answered and closed. A client that has gone away for good looks the
        same from here, so once a client has stopped sending and nothing has come back for a minute
        (HQ_LINK_LINGER seconds), the connection is taken to be over and ended: a far side that
        keeps idle connections open does not leave a process behind for each request. A client that
        is still connected is never timed out, however quiet. Each `tailscale nc` is ended and reaped when its
        connection ends, however it ends, and all of them when this program is stopped (and, as their
        input closes with this program, even if it is killed outright).

It works on bytes, not on HTTP, so it never looks inside a request. It has no idle timeout: a tool
call can stream for half an hour with quiet gaps. When the proxy or Bot HQ cannot be reached, that
one connection is closed, the reason goes in the log, and the program keeps running. Port 0 picks a
free port; the port in use is printed on the first line ("listening on 127.0.0.1:PORT"). Python 3.8
or later, standard library only. Supervisor keeps it running (program bothq-link); Bot HQ's setup
(server/box/hq-remote.sh) puts it there.
"""
import argparse
import asyncio
import os
import ipaddress
import signal
import socket
import sys
from urllib.parse import urlsplit

CHUNK = 64 * 1024
# Only opening the tunnel has a time limit; once it is open, a connection may be quiet for as long as it likes.
OPEN_TIMEOUT = 30
# Through `tailscale nc` only: how long a connection whose client has stopped sending may stay with nothing coming back.
LINGER = float(os.environ.get('HQ_LINK_LINGER', '60'))


def log(*parts):
    print(*parts, file=sys.stderr, flush=True)


def host_port(text, default_host='127.0.0.1'):
    """'host:port', '[v6]:port' or ':port' -> (host, port)."""
    text = text.strip()
    if text.startswith('['):
        host, _, rest = text[1:].partition(']')
        port = rest.lstrip(':')
    else:
        host, _, port = text.rpartition(':')
    if not port.isdigit():
        raise ValueError('no port in %r' % text)
    # A proxy that listens on every address (":1055", "0.0.0.0:1055") is reached on this computer's own.
    if host in ('', '0.0.0.0', '*'):
        host = default_host
    elif host == '::':
        host = '::1'
    return host, int(port)


def proxy_of(url):
    u = urlsplit(url if '://' in url else 'http://' + url)
    kind = {'http': 'http', 'socks5': 'socks5', 'socks5h': 'socks5'}.get(u.scheme)
    if not kind:
        raise ValueError('a proxy must be http:// or socks5://, not %r' % url)
    return kind, host_port(u.netloc)


async def tunnel_http(proxy, host, port):
    """An HTTP CONNECT tunnel. Returns the streams and any bytes that came after the proxy's answer."""
    reader, writer = await asyncio.open_connection(*proxy, limit=CHUNK)
    try:
        target = '[%s]:%d' % (host, port) if ':' in host else '%s:%d' % (host, port)
        writer.write(('CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n' % (target, target)).encode('ascii'))
        await writer.drain()
        head = await reader.readuntil(b'\r\n\r\n')
        status = head.split(b'\r\n', 1)[0].split()
        if len(status) < 2 or not status[1].startswith(b'2'):
            raise ConnectionError('the proxy refused the tunnel: %s' % head.split(b'\r\n', 1)[0].decode('latin-1'))
        return reader, writer
    except BaseException:
        writer.close()
        raise


async def tunnel_socks5(proxy, host, port):
    """A SOCKS5 tunnel, no sign-in, with the name resolved by the proxy (as tailscaled needs)."""
    reader, writer = await asyncio.open_connection(*proxy, limit=CHUNK)
    try:
        writer.write(b'\x05\x01\x00')
        await writer.drain()
        if await reader.readexactly(2) != b'\x05\x00':
            raise ConnectionError('the SOCKS5 proxy wants a sign-in')
        try:
            ip = ipaddress.ip_address(host)
            addr = (b'\x01' if ip.version == 4 else b'\x04') + ip.packed
        except ValueError:
            name = host.encode('idna')
            addr = b'\x03' + bytes([len(name)]) + name
        writer.write(b'\x05\x01\x00' + addr + port.to_bytes(2, 'big'))
        await writer.drain()
        ver, rep, _, atyp = await reader.readexactly(4)
        if ver != 5 or rep != 0:
            raise ConnectionError('the SOCKS5 proxy refused the tunnel (reply %d)' % rep)
        size = {1: 4, 4: 16}.get(atyp)
        if size is None:
            size = (await reader.readexactly(1))[0]
        await reader.readexactly(size + 2)
        return reader, writer
    except BaseException:
        writer.close()
        raise


async def pipe(reader, writer, other):
    """Copy one direction until it ends. At its end, say so to the far side and keep the other direction open."""
    try:
        while True:
            data = await reader.read(CHUNK)
            if not data:
                break
            writer.write(data)
            await writer.drain()
        if writer.can_write_eof() and not writer.is_closing():
            writer.write_eof()
    except (ConnectionError, OSError, asyncio.IncompleteReadError):
        # One side went away: there is nothing more to send either way.
        writer.close()
        other.close()


def keepalive(writer):
    """Let the system notice a far side that vanished without a word. It never closes a quiet, healthy connection."""
    sock = writer.get_extra_info('socket')
    if sock is not None:
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        except OSError:
            pass


async def read_tail(stream, keep=2000):
    """Everything a stream says until it ends, keeping only the last `keep` bytes."""
    got = b''
    while True:
        data = await stream.read(CHUNK)
        if not data:
            return got
        got = (got + data)[-keep:]


def last_line(raw):
    """The last line of `tailscale nc`'s standard error, without the time Go's log puts before it."""
    lines = [l.strip() for l in raw.decode('utf-8', 'replace').splitlines() if l.strip()]
    if not lines:
        return ''
    line = lines[-1]
    parts = line.split(' ', 2)
    if len(parts) == 3 and parts[0].count('/') == 2 and parts[1].count(':') == 2:
        line = parts[2]
    return line[:400]


async def end_child(proc):
    """End a `tailscale nc` and reap it. Its input closing is enough for it to stop; failing that, it is told to, then made to."""
    if proc.returncode is None:
        try:
            proc.stdin.close()
        except Exception:
            pass
        try:
            await asyncio.wait_for(proc.wait(), 1)
        except asyncio.TimeoutError:
            pass
    if proc.returncode is None:
        try:
            proc.terminate()
            await asyncio.wait_for(proc.wait(), 2)
        except ProcessLookupError:
            pass
        except asyncio.TimeoutError:
            pass
    if proc.returncode is None:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
    await proc.wait()


class Link:
    def __init__(self, target, proxy_kind=None, proxy=None, tailscale=None, socket_path=None):
        self.open_tunnel = tunnel_http if proxy_kind == 'http' else tunnel_socks5
        self.proxy = proxy
        self.tailscale = tailscale
        self.socket_path = socket_path
        self.target = target
        self.count = 0
        self.children = set()
        self.tasks = set()

    async def handle(self, client_reader, client_writer):
        self.count += 1
        n = self.count
        task = asyncio.current_task()
        self.tasks.add(task)
        try:
            keepalive(client_writer)
            if self.tailscale:
                await self.through_nc(n, client_reader, client_writer)
            else:
                await self.through_proxy(n, client_reader, client_writer)
        finally:
            self.tasks.discard(task)

    async def through_proxy(self, n, client_reader, client_writer):
        try:
            up_reader, up_writer = await asyncio.wait_for(self.open_tunnel(self.proxy, *self.target), OPEN_TIMEOUT)
        except Exception as e:  # the proxy or Bot HQ is down: close this one, keep running
            log('connection %d: could not reach %s:%d: %s' % (n, self.target[0], self.target[1], str(e) or type(e).__name__))
            client_writer.close()
            return
        keepalive(up_writer)
        try:
            await asyncio.gather(
                pipe(client_reader, up_writer, client_writer),
                pipe(up_reader, client_writer, up_writer),
            )
        finally:
            for w in (up_writer, client_writer):
                w.close()

    async def through_nc(self, n, client_reader, client_writer):
        host, port = self.target
        args = [self.tailscale] + (['--socket=' + self.socket_path] if self.socket_path else []) + ['nc', host, str(port)]
        try:
            proc = await asyncio.create_subprocess_exec(
                *args, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                limit=CHUNK)
        except OSError as e:
            log('connection %d: could not start %s: %s' % (n, self.tailscale, e))
            client_writer.close()
            return
        self.children.add(proc)
        said = asyncio.ensure_future(read_tail(proc.stderr))
        sent = 0
        loop = asyncio.get_running_loop()
        quiet_since = [None]  # set when the client has stopped sending; moved on by anything that comes back

        async def up():
            """The client to `tailscale nc`. When the client stops sending, its input is kept open (see above)."""
            try:
                while True:
                    data = await client_reader.read(CHUNK)
                    if not data:
                        quiet_since[0] = loop.time()
                        return
                    try:
                        proc.stdin.write(data)
                        await proc.stdin.drain()
                    except (ConnectionError, OSError):
                        return  # it has stopped; what it said, and why, comes out on the other side
            except (ConnectionError, OSError, asyncio.IncompleteReadError):
                # The client went away: so does this connection's `tailscale nc`.
                try:
                    proc.stdin.close()
                except Exception:
                    pass
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass

        sending = asyncio.ensure_future(up())
        try:
            # `tailscale nc` to the client, until Bot HQ is done (or the process ended).
            tick = min(5.0, max(0.1, LINGER / 4))
            while True:
                try:
                    # Looked at now and then only to notice a client that left: a read that is given up loses nothing.
                    data = await asyncio.wait_for(proc.stdout.read(CHUNK), tick)
                except asyncio.TimeoutError:
                    if quiet_since[0] is not None and loop.time() - quiet_since[0] >= LINGER:
                        break
                    continue
                if not data:
                    break
                sent += len(data)
                if quiet_since[0] is not None:
                    quiet_since[0] = loop.time()
                client_writer.write(data)
                await client_writer.drain()
            if client_writer.can_write_eof() and not client_writer.is_closing():
                client_writer.write_eof()
        except (ConnectionError, OSError):
            pass  # the client went away
        finally:
            sending.cancel()
            client_writer.close()
            try:
                await end_child(proc)
            finally:
                self.children.discard(proc)
            why = last_line(await said)
            if proc.returncode not in (0, -signal.SIGTERM) or (why and not sent):
                if not sent:
                    log('connection %d: could not reach %s:%d through tailscale nc: %s' % (n, host, port, why or 'it stopped (exit %s) without saying why' % proc.returncode))
                else:
                    log('connection %d: tailscale nc ended (exit %s)%s' % (n, proc.returncode, ': ' + why if why else ''))

    async def stop(self):
        """Stopping: every connection is ended, and every `tailscale nc` with it."""
        for t in list(self.tasks):
            t.cancel()
        if self.tasks:
            await asyncio.gather(*list(self.tasks), return_exceptions=True)
        for proc in list(self.children):
            await end_child(proc)
            self.children.discard(proc)


async def main():
    p = argparse.ArgumentParser(description='Forward local connections to Bot HQ over the private network.')
    p.add_argument('--listen', default='127.0.0.1:0')
    way = p.add_mutually_exclusive_group(required=True)
    way.add_argument('--proxy', help='tailscaled\'s proxy: http://HOST:PORT or socks5://HOST:PORT')
    way.add_argument('--tailscale-nc', metavar='TAILSCALE', help='the tailscale command, run as `tailscale nc` for each connection')
    p.add_argument('--socket', help='with --tailscale-nc: the socket of the running tailscaled, when it is not the usual one')
    p.add_argument('--target', required=True)
    a = p.parse_args()
    target = host_port(a.target)
    listen = host_port(a.listen)
    if a.proxy:
        if a.socket:
            raise ValueError('--socket goes with --tailscale-nc, not with --proxy')
        kind, proxy = proxy_of(a.proxy)
        link = Link(target, proxy_kind=kind, proxy=proxy)
        through = a.proxy
    else:
        link = Link(target, tailscale=a.tailscale_nc, socket_path=a.socket)
        through = 'tailscale nc (%s%s)' % (a.tailscale_nc, ', socket ' + a.socket if a.socket else '')
    server = await asyncio.start_server(link.handle, listen[0], listen[1], limit=CHUNK, backlog=256)
    port = server.sockets[0].getsockname()[1]
    print('listening on %s:%d, to %s:%d through %s' % (listen[0], port, target[0], target[1], through), flush=True)
    stopping = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stopping.set)
    await stopping.wait()
    server.close()
    await link.stop()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except (ValueError, OSError) as e:
        log('hq-link: %s' % e)
        sys.exit(2)
