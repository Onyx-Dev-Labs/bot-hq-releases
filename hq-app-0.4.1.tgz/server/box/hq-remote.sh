#!/usr/bin/env bash
# Bot HQ's helper on a person's own Orgo computer, where one of their Bots lives.
#
# Bot HQ sends this file over Orgo's API with every call and runs one step of it, so each step can
# be reported and a failure named. The last line of the output says how it went:
#   HQ-OK <json>      the step worked; the JSON is what Bot HQ needs from it
#   HQ-FAIL <text>    it did not; the text is said to the person as it is, so it is plain words
#
# Steps (arguments are base64, so nothing in them needs quoting):
#   check <mode>                     is Hermes here? mode 'new' may start from a bare home, 'adopt' may not
#   api <key>                        make sure Hermes's API server is on; keeps a key that is already set
#   tailnet <authkey> <name> <port> <setup-tailscale.sh>
#                                    join the private network unless already on it; say how programs
#                                    here reach it (directly, through tailscaled's proxy, or through
#                                    `tailscale nc` when tailscaled has no proxy)
#   link <proxy> <host:port> <hq-link.py>
#   link tailscale-nc <host:port> <hq-link.py> <tailscale command> <socket or empty>
#                                    keep Bot HQ's link running: a forwarder on 127.0.0.1 that takes
#                                    the agent's tool calls that way to Bot HQ
#   reach <url> <Bot HQ's address>   can this computer reach Bot HQ the way its tools will?
#   hq <entry yaml> <python script>  add (or replace) the `hq` MCP server in Hermes's config
#   unhq <python script>             take it out again, and Bot HQ's link with it
#   signin <provider or ->           open a sign-in terminal on the computer's own screen
#   usage <provider>                 what the provider says is left on the signed-in plan
#   library, libfile, libput, memories, forget, restart, reset
#                                    the Bot's Library, memories, agent restart and screen reset (see the block before the last step)
#   deskput, desk, deskcheck, deskoff
#                                    the Bot's look on this computer's desktop, as on the shared computer (see their block)
set -u
H="${HERMES_HOME:-$HOME/.hermes}"
ok() { if [ -n "${1:-}" ]; then echo "HQ-OK $1"; else echo "HQ-OK {}"; fi; exit 0; }
fail() { echo "HQ-FAIL $*"; exit 1; }
arg() { printf '%s' "${1:-}" | base64 -d 2>/dev/null; }
step="${1:-}"; shift || true

envget() { [ -f "$H/.env" ] && grep -E "^$1=" "$H/.env" | tail -1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'; }
envset() {
  touch "$H/.env"; chmod 600 "$H/.env"
  if grep -qE "^$1=" "$H/.env"; then sed -i "s|^$1=.*|$1=$2|" "$H/.env"; else printf '%s=%s\n' "$1" "$2" >> "$H/.env"; fi
}
port() { p="$(envget API_SERVER_PORT)"; echo "${p:-8642}"; }
health() { curl -fsS -m 3 "http://127.0.0.1:$(port)/health" >/dev/null 2>&1; }
keyok() { curl -fsS -m 4 -H "Authorization: Bearer $1" "http://127.0.0.1:$(port)/v1/models" >/dev/null 2>&1; }
# The Python that Hermes runs with has PyYAML, which the config edit needs for its safety check.
hermes_py() {
  b="$(command -v hermes 2>/dev/null)" || { command -v python3; return; }
  s="$(head -1 "$b" | sed 's/^#!//' | awk '{print $1}')"
  case "$s" in */python*) [ -x "$s" ] && { echo "$s"; return; } ;; esac
  command -v python3
}
jstr() { printf '"%s"' "$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g')"; }
# The value of key=value in setup-tailscale.sh's output.
val() { printf '%s\n' "$1" | sed -n "s/^$2=//p" | tail -1; }

# Bot HQ's link: its own program under supervisor, its own files. Nothing else is touched.
# (HQ_REMOTE_ROOT moves them under another folder, for the tests; on a computer it is not set.)
R="${HQ_REMOTE_ROOT:-}"
LINK_DIR="$R/opt/bothq"
LINK_FILE="$LINK_DIR/hq-link.py"
LINK_CONF="$R/etc/supervisor/conf.d/bothq-link.conf"
LINK_LOG="$R/var/log/bothq/hq-link.log"
link_known() { supervisorctl status bothq-link 2>/dev/null | grep -q '^bothq-link[[:space:]]'; }
link_running() { supervisorctl status bothq-link 2>/dev/null | grep -q '^bothq-link[[:space:]]*RUNNING'; }
sys_py() { command -v python3 || hermes_py; }
# Is nothing listening on this port of 127.0.0.1?
port_free() { "$(sys_py)" -I -c 'import socket,sys; s=socket.socket(); s.bind(("127.0.0.1", int(sys.argv[1])))' "$1" >/dev/null 2>&1; }
link_entry() {
  cat <<EOF
[program:bothq-link]
command=$1 -I $LINK_FILE --listen 127.0.0.1:$2 $3 --target $4
autostart=true
autorestart=true
startsecs=2
stdout_logfile=$LINK_LOG
stdout_logfile_maxbytes=5MB
redirect_stderr=true
EOF
}
unlink_hq() {
  [ -f "$LINK_CONF" ] || [ -f "$LINK_FILE" ] || link_known || return 0
  if link_known; then
    supervisorctl stop bothq-link >/dev/null 2>&1
    supervisorctl remove bothq-link >/dev/null 2>&1
  fi
  rm -f "$LINK_CONF" "$LINK_FILE" "$LINK_LOG" "$LINK_LOG".[0-9]*
  rmdir "$LINK_DIR" "$(dirname "$LINK_LOG")" 2>/dev/null
  supervisorctl reread >/dev/null 2>&1
  ! link_known
}

# The gateway is supervised on Orgo's Hermes template. Ask whichever supervisor runs it to restart
# it; failing that, Hermes itself; failing that, start one by hand.
restart_gateway() {
  if command -v systemctl >/dev/null 2>&1; then
    u="$(systemctl list-units --all --plain --no-legend 2>/dev/null | awk '/hermes/ {print $1; exit}')"
    [ -n "$u" ] && systemctl restart "$u" && return 0
  fi
  if command -v supervisorctl >/dev/null 2>&1; then
    # The program that is really this agent (by its API port, else its home; see `agentname` below).
    # A computer can run more than one Hermes agent, and the first one by name may be someone else's.
    u="$(bash "$0" agentname 2>/dev/null | sed -n 's/^HQ-OK .*"program":"\([^"]*\)".*/\1/p' | tail -1)"
    if [ -z "$u" ]; then
      n="$(supervisorctl status 2>/dev/null | awk 'tolower($0) ~ /hermes/ {print $1}' | grep -c .)"
      if [ "$n" -gt 1 ]; then
        fail "More than one Hermes agent runs on this computer, and Bot HQ could not tell which one is this agent, so it restarted none. Its API server is now switched on in its settings: restart that agent yourself (supervisorctl restart <its program>), then add the computer again."
      fi
      u="$(supervisorctl status 2>/dev/null | awk 'tolower($0) ~ /hermes/ {print $1; exit}')"
    fi
    [ -n "$u" ] && supervisorctl restart "$u" >/dev/null && return 0
  fi
  hermes gateway restart >/dev/null 2>&1 && return 0
  pkill -f 'hermes gateway' >/dev/null 2>&1; sleep 2
  (nohup hermes gateway run >/tmp/hq-gateway.log 2>&1 &) ; return 0
}

case "$step" in
  check)
    mode="$(arg "${1:-}")"
    command -v hermes >/dev/null 2>&1 || fail "This computer has no Hermes agent installed."
    if [ ! -f "$H/config.yaml" ]; then
      [ "$mode" = "new" ] || fail "Hermes is installed on this computer but has no agent set up yet (no $H/config.yaml)."
      mkdir -p "$H" && touch "$H/config.yaml"
    fi
    v="$(hermes --version 2>/dev/null | head -1)"
    ok "{\"version\":$(jstr "$v"),\"home\":$(jstr "$H")}"
    ;;

  api)
    want="$(arg "${1:-}")"
    have="$(envget API_SERVER_KEY)"
    if [ "$(envget API_SERVER_ENABLED)" = "true" ] && [ -n "$have" ] && health && keyok "$have"; then
      ok "{\"key\":$(jstr "$have"),\"port\":$(port),\"changed\":false}"
    fi
    key="${have:-$want}"
    envset API_SERVER_ENABLED true
    envset API_SERVER_KEY "$key"
    [ -n "$(envget API_SERVER_PORT)" ] || envset API_SERVER_PORT 8642
    [ -n "$(envget API_SERVER_HOST)" ] || envset API_SERVER_HOST 127.0.0.1
    restart_gateway
    for i in $(seq 1 45); do
      sleep 2
      health && keyok "$key" && ok "{\"key\":$(jstr "$key"),\"port\":$(port),\"changed\":true}"
    done
    fail "The agent's API server did not come up after it was switched on. See /tmp/hq-gateway.log or the gateway's own log on the computer."
    ;;

  tailnet)
    k="$(arg "${1:-}")"; name="$(arg "${2:-}")"; p="$(arg "${3:-}")"; script="$(arg "${4:-}")"
    [ -n "$script" ] || fail "Bot HQ did not send its Tailscale setup."
    d="$(mktemp -d)"; chmod 700 "$d"
    printf '%s\n' "$script" > "$d/setup-tailscale.sh"
    now="$(bash "$d/setup-tailscale.sh" --status --port "$p" </dev/null 2>&1)"
    state="$(val "$now" state)"
    joined=false
    case "$state" in
      Running) out="$now" ;;
      *)
        # A Tailscale that runs but is signed out is only signed in if Bot HQ set it up (its
        # supervisor program); one the person runs some other way is theirs to sign in.
        if [ "$state" != NotInstalled ] && [ "$state" != NotRunning ] && ! supervisorctl status tailscaled 2>/dev/null | grep -q '^tailscaled[[:space:]]'; then
          rm -rf "$d"
          fail "Tailscale runs on this computer but is not connected to your private network (it says $state). Bot HQ did not set that Tailscale up, so it leaves it alone. Connect it to your network on the computer (tailscale up), then add the computer again."
        fi
        if [ -z "$k" ]; then
          rm -rf "$d"
          fail "This computer is not on your private network, and Bot HQ has no Tailscale key to put it there. The person who runs this Bot HQ can add one in Settings, Setup and health."
        fi
        # The key goes in on standard input only, as setup-tailscale.sh asks.
        out="$(printf '%s\n' "$k" | bash "$d/setup-tailscale.sh" --join --name "$name" --port "$p" 2>&1)"; r=$?
        if [ $r -ne 0 ] || [ "$(val "$out" result)" = failed ]; then
          rm -rf "$d"
          msg="$(val "$out" message)"; [ -n "$msg" ] || msg="$(printf '%s' "$out" | tail -1)"
          case "$(val "$out" error)" in
            bad_key|key_expired)
              msg="$msg The key is the one saved for teammates’ computers: the person who runs this Bot HQ can replace it in Settings, Setup and health."
              # For Bot HQ, not the person: Tailscale refused the key, so its row in Setup and health says so.
              echo "HQ-KEY-REFUSED $(val "$out" error)" ;;
          esac
          fail "The computer could not join your private network: $msg"
        fi
        joined=true
        ;;
    esac
    rm -rf "$d"
    n="$(val "$out" name)"
    [ -n "$n" ] || fail "The computer is on your private network but did not report its name there."
    # How programs on this computer reach the network: directly with a network device; without one
    # (userspace mode), through tailscaled's proxy when it has one, the proven way, else through
    # `tailscale nc`, which goes through the tailscaled that runs and needs nothing changed here.
    route=""
    if [ "$(val "$out" userspace)" = yes ]; then
      route="$(val "$out" proxy)"
      if [ -z "$route" ] && [ -n "$(val "$out" socks5)" ]; then route="socks5://$(val "$out" socks5)"; fi
      if [ -z "$route" ]; then
        cli="$(val "$out" cli)"
        [ -n "$cli" ] || fail "Tailscale on this computer runs without a network device and without a proxy, and Bot HQ could not find its tailscale command, which it would reach your private network through. Bot HQ did not set that Tailscale up, so it does not change it. Put the tailscale command back beside tailscaled (it comes in the same download), then add the computer again."
        ok "{\"name\":$(jstr "$n"),\"proxy\":\"\",\"via\":\"tailscale-nc\",\"tailscale\":$(jstr "$cli"),\"socket\":$(jstr "$(val "$out" socket)"),\"joined\":$joined}"
      fi
    fi
    ok "{\"name\":$(jstr "$n"),\"proxy\":$(jstr "$route"),\"joined\":$joined}"
    ;;

  link)
    px="$(arg "${1:-}")"; target="$(arg "${2:-}")"; script="$(arg "${3:-}")"; tsc="$(arg "${4:-}")"; tss="$(arg "${5:-}")"
    # All of it goes into a supervisor file: only the characters an address has, or a path.
    case "$target" in *[!A-Za-z0-9.:/_\[\]-]*) fail "Bot HQ’s link was given an address it cannot use." ;; esac
    if [ "$px" = tailscale-nc ]; then
      # The tailscale command, and the socket of the tailscaled that runs when it is not the usual
      # one: whole paths of plain characters, nothing that climbs out of a folder, really there.
      for p in "$tsc" "$tss"; do
        [ -n "$p" ] || continue
        case "$p" in /*) ;; *) fail "Bot HQ’s link was given a path it cannot use." ;; esac
        case "$p" in *[!A-Za-z0-9._/-]*|*/../*|*/..|*//*) fail "Bot HQ’s link was given a path it cannot use." ;; esac
      done
      { [ -n "$tsc" ] && [ "${tsc##*/}" = tailscale ]; } || fail "Bot HQ’s link was given a path it cannot use."
      { [ -f "$tsc" ] && [ -x "$tsc" ]; } || fail "Bot HQ’s link would reach your private network through the tailscale command at $tsc, but it is not there."
      [ -z "$tss" ] || [ -S "$tss" ] || fail "Bot HQ’s link would reach your private network through Tailscale at $tss, but Tailscale is not answering there."
      way="--tailscale-nc $tsc${tss:+ --socket $tss}"
    else
      case "$px" in *[!A-Za-z0-9.:/_\[\]-]*) fail "Bot HQ’s link was given an address it cannot use." ;; esac
      [ -z "$tsc$tss" ] || fail "Bot HQ’s link was given an address it cannot use."
      way="--proxy $px"
    fi
    if [ -z "$px" ] || [ -z "$target" ] || [ -z "$script" ]; then fail "Bot HQ did not send its link."; fi
    command -v supervisorctl >/dev/null 2>&1 || fail "This computer has no supervisor to keep Bot HQ’s link running."
    py="$(sys_py)"; if [ -z "$py" ] || [ ! -x "$py" ]; then fail "This computer has no Python 3 for Bot HQ’s link."; fi
    mkdir -p "$LINK_DIR" "$(dirname "$LINK_LOG")" || fail "Could not make $LINK_DIR on the computer."
    # The port it already has, else the first free one of a few.
    lp="$(sed -n -E 's/.*--listen 127\.0\.0\.1:([0-9]+) .*/\1/p' "$LINK_CONF" 2>/dev/null | head -1)"
    # The ports it tries. (HQ_LINK_PORTS="<first> <last>" is for the tests, so runs side by side do not collide.)
    lo=17870; hi=17899
    case "${HQ_LINK_PORTS:-}" in *[0-9]\ [0-9]*) lo="${HQ_LINK_PORTS% *}"; hi="${HQ_LINK_PORTS#* }" ;; esac
    if [ -z "$lp" ]; then
      for c in $(seq "$lo" "$hi"); do port_free "$c" && { lp="$c"; break; }; done
    fi
    [ -n "$lp" ] || fail "There is no free port on the computer for Bot HQ’s link (it tries $lo to $hi)."
    file_changed=false; conf_changed=false
    if [ ! -f "$LINK_FILE" ] || [ "$(cat "$LINK_FILE")" != "$script" ]; then
      if ! { printf '%s\n' "$script" > "$LINK_FILE.new" && chmod 644 "$LINK_FILE.new" && mv -f "$LINK_FILE.new" "$LINK_FILE"; }; then fail "Could not write $LINK_FILE."; fi
      file_changed=true
    fi
    want="$(link_entry "$py" "$lp" "$way" "$target")"
    if [ ! -f "$LINK_CONF" ] || [ "$(cat "$LINK_CONF")" != "$want" ]; then
      if ! { printf '%s\n' "$want" > "$LINK_CONF" && chmod 644 "$LINK_CONF"; }; then fail "Could not write $LINK_CONF."; fi
      conf_changed=true
    fi
    # reread only loads what changed on disk; add, update and restart name this one program.
    if ! link_known; then
      supervisorctl reread >/dev/null 2>&1
      supervisorctl add bothq-link >/dev/null 2>&1 || fail "Supervisor would not add Bot HQ’s link. Its log: $LINK_LOG"
    elif [ "$conf_changed" = true ]; then
      supervisorctl reread >/dev/null 2>&1
      supervisorctl update bothq-link >/dev/null 2>&1 || fail "Supervisor would not restart Bot HQ’s link. Its log: $LINK_LOG"
    elif [ "$file_changed" = true ]; then
      supervisorctl restart bothq-link >/dev/null 2>&1 || fail "Supervisor would not restart Bot HQ’s link. Its log: $LINK_LOG"
    elif ! link_running; then
      supervisorctl start bothq-link >/dev/null 2>&1
    fi
    for i in $(seq 1 20); do
      link_running && ! port_free "$lp" && ok "{\"port\":$lp,\"changed\":$( [ "$file_changed$conf_changed" = falsefalse ] && echo false || echo true)}"
      sleep 1
    done
    fail "Bot HQ’s link did not start on the computer. Its log: $LINK_LOG"
    ;;

  reach)
    u="$(arg "${1:-}")"; shown="$(arg "${2:-}")"
    e="$(mktemp)"
    # A name new on the network, or a link just started, can take a moment. (HQ_REACH_TRIES is for the tests.)
    tries="${HQ_REACH_TRIES:-12}"
    for i in $(seq 1 "$tries"); do
      body="$(curl -sS -m 10 "$u" 2>"$e")"
      case "$body" in *needsSetup*) rm -f "$e"; ok "{\"tries\":$i}" ;; esac
      [ "$i" -lt "$tries" ] && sleep 3
    done
    why="$(tail -1 "$e" 2>/dev/null)"; rm -f "$e"
    [ -n "$why" ] || why="something answered, but it was not Bot HQ"
    hint=""
    case "$u" in http://127.0.0.1:*) hint=" Bot HQ’s link on the computer logs to $LINK_LOG." ;; esac
    fail "The computer cannot reach Bot HQ at ${shown:-$u} over your private network, so its Bot would have none of Bot HQ’s tools ($why). Check that Bot HQ is on the same Tailscale network, and that its address there is right in Settings, Setup and health.$hint"
    ;;

  hq|unhq)
    if [ "$step" = "hq" ]; then entry="$(arg "${1:-}")"; script="$(arg "${2:-}")"; else script="$(arg "${1:-}")"; fi
    d="$(mktemp -d)"; chmod 700 "$d"
    printf '%s\n' "$script" > "$d/add-hq.py"
    if [ "$step" = "hq" ]; then
      printf '%s\n' "$entry" > "$d/entry.yaml"
      out="$("$(hermes_py)" "$d/add-hq.py" --config "$H/config.yaml" --entry "$d/entry.yaml" 2>&1)"; r=$?
    else
      : > "$d/entry.yaml"
      out="$("$(hermes_py)" "$d/add-hq.py" --config "$H/config.yaml" --entry "$d/entry.yaml" --remove 2>&1)"; r=$?
    fi
    rm -rf "$d"
    if [ "$step" = "unhq" ]; then
      # Bot HQ's link goes with its tools, whatever came of the config edit. Tailscale stays.
      unlink_hq; l=$?
      [ $r -eq 0 ] || fail "Bot HQ's tools could not be taken out of the agent's settings: $(printf '%s' "$out" | tail -1)"
      [ $l -eq 0 ] || fail "Bot HQ's tools were taken out of the agent's settings, but its link could not be removed (supervisor program bothq-link)."
    fi
    [ $r -eq 0 ] || fail "Bot HQ's tools could not be added to the agent's settings: $(printf '%s' "$out" | tail -1)"
    ok "{\"said\":$(jstr "$(printf '%s' "$out" | tail -1)")}"
    ;;

  signin)
    p="$(arg "${1:-}")"
    if [ "$p" = "-" ] || [ -z "$p" ]; then cmd="hermes model"; title="Choose a model"
    elif [ "$p" = "anthropic" ]; then cmd="hermes auth add anthropic --type oauth"; title="Sign in: $p"
    else cmd="hermes auth add $p"; title="Sign in: $p"; fi
    export DISPLAY=:99
    for t in xfce4-terminal gnome-terminal x-terminal-emulator xterm; do
      if command -v "$t" >/dev/null 2>&1; then
        case "$t" in
          xfce4-terminal) (nohup xfce4-terminal --title="$title" -x bash -lc "$cmd; exec bash" >/dev/null 2>&1 &) ;;
          gnome-terminal) (nohup gnome-terminal --title="$title" -- bash -lc "$cmd; exec bash" >/dev/null 2>&1 &) ;;
          *) (nohup "$t" -T "$title" -e bash -lc "$cmd; exec bash" >/dev/null 2>&1 &) ;;
        esac
        ok "{\"terminal\":$(jstr "$t")}"
      fi
    done
    fail "There is no terminal app on the computer to sign in with."
    ;;

  usage)
    p="$(arg "${1:-}")"
    out="$(hermes usage --provider "$p" --json 2>/dev/null)"
    j="$(printf '%s' "$out" | sed -n '/{/,$p' | tr -d '\n')"
    [ -n "$j" ] || fail "No limits were reported."
    ok "$j"
    ;;

  # ---------- for the Bot that lives here: its Library, its memories, restarting its agent, resetting its screen ----------
  # (server/src/own-computer-screens.ts) The work is done in Python, which every computer with Hermes has, so
  # file names, memory entries and process lists stay data and never pass through the shell.
  #   library <bot> <path>             list a folder of the Bot's Library ($HOME/bothq/files/<bot>)
  #   libfile <bot> <path>             where one file of it really is, for Orgo to export
  #   libput <bot> <name> <text> <upload>
  #                                    save a file there: the text itself, or an upload Bot HQ sent in pieces
  #   memories                         what the agent's built-in memory holds ($H/memories)
  #   forget <m|u> <entry>             take one entry out of it
  #   restart <created|adopted>        restart this agent, and only this one, and wait for it to answer
  #   reset <created|adopted>          close windows on the desktop: all of them on a computer Bot HQ made,
  #                                    only those of programs this agent started on one that was already theirs
  library|libfile|libput|memories|forget|restart|reset|agentname)
    py="$(sys_py)"; if [ -z "$py" ] || [ ! -x "$py" ]; then fail "This computer has no Python 3 for Bot HQ."; fi
    HQ_H="$H" HQ_ROOT="$R" HQ_PORT="$(port)" "$py" -I - "$step" "$@" <<'PY'
import base64, json, os, re, signal, stat, subprocess, sys, time, urllib.request


def ok(obj=None):
    print('HQ-OK ' + json.dumps(obj or {}, separators=(',', ':')), flush=True)
    sys.exit(0)


def fail(msg):
    print('HQ-FAIL ' + ' '.join(str(msg).split()), flush=True)
    sys.exit(1)


def decode(x):
    try:
        return base64.b64decode(x).decode('utf-8')
    except (ValueError, UnicodeDecodeError):
        fail('Bot HQ sent something the computer could not read.')


STEP = sys.argv[1]
ARGS = [decode(x) for x in sys.argv[2:]]
arg = lambda i: ARGS[i] if len(ARGS) > i else ''
H = os.path.realpath(os.environ.get('HQ_H') or os.path.expanduser('~/.hermes'))
ROOT = os.environ.get('HQ_ROOT', '')
PORT = int(os.environ.get('HQ_PORT') or 8642)
HOME = os.path.expanduser('~')
# The Library lives in a folder of Bot HQ's own in the home folder, one folder per Bot, beside nothing
# that was there before. (On the shared computer it is /root/grokbot/files/<bot>.)
LIB = os.path.join(HOME, 'bothq', 'files')
LINUX = os.path.isdir('/proc/self')


def run(cmd, timeout=30, env=None):
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, timeout=timeout, env=env)
        return r.returncode, r.stdout.decode('utf-8', 'replace')
    except (OSError, subprocess.TimeoutExpired):
        return 127, ''


# ---------- the Library ----------

def inside(real, top):
    return real == top or real.startswith(top + os.sep)


def shelf(bot):
    if not re.match(r'^[A-Za-z0-9_-][A-Za-z0-9_.-]{0,79}$', bot):
        fail('Bot HQ sent a Bot id it cannot use as a folder name.')
    d = os.path.join(LIB, bot)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError as e:
        fail('Could not make the Library folder %s on the computer (%s).' % (d, e.strerror))
    return os.path.realpath(d)


def within(bot, rel):
    """The real place of a path in the Bot's Library. Links are followed first, so none can lead out of it."""
    top = shelf(bot)
    parts = rel.split('/') if rel else []
    if any(p in ('', '.', '..') for p in parts) or '\0' in rel or '\n' in rel:
        fail('That is not a path in the Library.')
    real = os.path.realpath(os.path.join(top, *parts)) if parts else top
    if not inside(real, top):
        fail('That is outside the Library.')
    return top, real


def library():
    top, real = within(arg(0), arg(1))
    if not os.path.isdir(real):
        fail('That folder is not in the Library any more.')
    files = []
    for name in sorted(os.listdir(real))[:5000]:
        p = os.path.join(real, name)
        try:
            name.encode('utf-8')
            if not inside(os.path.realpath(p), top):
                continue
            st = os.stat(p)
        except (OSError, UnicodeEncodeError):
            continue
        files.append({'name': name, 'size': st.st_size, 'modifiedAt': int(st.st_mtime * 1000), 'isDir': stat.S_ISDIR(st.st_mode)})
    ok({'root': LIB, 'files': files})


def libfile():
    top, real = within(arg(0), arg(1))
    if not os.path.isfile(real):
        fail('That file is not in the Library any more.')
    ok({'root': LIB, 'path': real, 'size': os.path.getsize(real)})


def libput():
    top = shelf(arg(0))
    name, upload = arg(1), arg(3)
    if not re.match(r'^[A-Za-z0-9._-]{1,120}$', name) or name in ('.', '..'):
        fail('Bot HQ sent a file name it cannot use.')
    if upload:
        if not re.match(r'^[A-Za-z0-9_-]{8,80}$', upload):
            fail('Bot HQ sent an upload it cannot use.')
        src = os.path.join(HOME, '.bothq', 'uploads', upload)
        try:
            with open(src, 'rb') as f:
                data = base64.b64decode(f.read())
        except (OSError, ValueError):
            fail('The file Bot HQ sent did not arrive whole. Try saving it again.')
        finally:
            try:
                os.unlink(src)
            except OSError:
                pass
    else:
        data = arg(2).encode('utf-8')
    dest = os.path.join(top, name)
    if os.path.isdir(dest) and not os.path.islink(dest):
        fail('There is already a folder called %s in the Library.' % name)
    tmp = os.path.join(top, '.%s.bothq-%d' % (name, os.getpid()))
    try:
        with open(tmp, 'wb') as f:
            f.write(data)
        os.chmod(tmp, 0o644)
        os.replace(tmp, dest)
    except OSError as e:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        fail('Could not save %s in the Library on the computer (%s).' % (name, e.strerror))
    ok({'root': LIB, 'path': os.path.join(LIB, arg(0), name), 'size': len(data)})


# ---------- the agent's built-in memory ----------
# Hermes keeps it in <home>/memories: MEMORY.md (its own notes) and USER.md (what it knows about the
# person), each a list of entries with a line holding only "§" between them. Read loosely, so an older
# Hermes that writes the files a little differently (spaces around the mark, Windows line ends) still reads.

MEM = {'m': 'MEMORY.md', 'u': 'USER.md'}


def entries_of(text):
    out, cur = [], []
    for line in text.replace('\r\n', '\n').split('\n'):
        if line.strip() == '§':
            out.append('\n'.join(cur).strip())
            cur = []
        else:
            cur.append(line)
    out.append('\n'.join(cur).strip())
    return [e for e in out if e]


def read_mem(key):
    path = os.path.join(H, 'memories', MEM[key])
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
        return path, entries_of(text), os.stat(path)
    except OSError:
        return path, [], None


def memories():
    out = {'home': H}
    for key in MEM:
        _, entries, st = read_mem(key)
        out[key] = {'entries': entries, 'mtime': int(st.st_mtime * 1000) if st else 0}
    ok(out)


def forget():
    key, text = arg(0), arg(1)
    if key not in MEM:
        fail('Bot HQ asked for a memory file it does not know.')
    for _ in range(3):
        path, entries, st = read_mem(key)
        keep = [e for e in entries if e != text]
        if st is None or len(keep) == len(entries):
            ok({'removed': 0})
        lock = None
        if os.path.exists(path + '.lock'):
            # Only when the agent itself keeps a lock file here; none is ever made.
            try:
                import fcntl
                lock = open(path + '.lock', 'a')
                fcntl.flock(lock, fcntl.LOCK_EX)
            except (OSError, ImportError):
                lock = None
        try:
            now = os.stat(path)
            if (now.st_mtime_ns, now.st_size) != (st.st_mtime_ns, st.st_size):
                continue          # the agent wrote to it meanwhile: read it again
            tmp = path + '.bothq-%d' % os.getpid()
            with open(tmp, 'w', encoding='utf-8') as f:
                f.write('\n§\n'.join(keep) + ('\n' if keep else ''))
            os.chmod(tmp, stat.S_IMODE(st.st_mode))
            try:
                os.chown(tmp, st.st_uid, st.st_gid)
            except OSError:
                pass
            os.replace(tmp, path)
            ok({'removed': len(entries) - len(keep)})
        finally:
            if lock:
                lock.close()
    fail('The agent kept changing its memory while Bot HQ tried to remove that entry. Try again in a moment.')


# ---------- which program is this agent ----------

def parents():
    out = {}
    if LINUX:
        for d in os.listdir('/proc'):
            if d.isdigit():
                try:
                    with open('/proc/%s/stat' % d) as f:
                        s = f.read()
                    out[int(d)] = int(s[s.rindex(')') + 2:].split()[1])
                except (OSError, ValueError, IndexError):
                    pass
        return out
    for line in run(['ps', '-A', '-o', 'pid=', '-o', 'ppid='])[1].splitlines():
        p = line.split()
        if len(p) == 2 and p[0].isdigit() and p[1].isdigit():
            out[int(p[0])] = int(p[1])
    return out


def environ_of(pid):
    if LINUX:
        try:
            with open('/proc/%d/environ' % pid, 'rb') as f:
                raw = f.read().decode('utf-8', 'replace')
            return dict(x.split('=', 1) for x in raw.split('\0') if '=' in x)
        except OSError:
            return {}
    words = run(['ps', '-E', '-ww', '-o', 'command=', '-p', str(pid)])[1].split()
    return dict(w.split('=', 1) for w in words if re.match(r'^[A-Z_][A-Z0-9_]*=', w))


def cmdline_of(pid):
    if LINUX:
        try:
            with open('/proc/%d/cmdline' % pid, 'rb') as f:
                return [x.decode('utf-8', 'replace') for x in f.read().split(b'\0') if x]
        except OSError:
            return []
    return run(['ps', '-ww', '-o', 'command=', '-p', str(pid)])[1].split()


def listeners(port):
    """The processes listening on this TCP port."""
    pids = set()
    if LINUX:
        inodes = set()
        for name in ('/proc/net/tcp', '/proc/net/tcp6'):
            try:
                with open(name) as f:
                    for line in f.readlines()[1:]:
                        p = line.split()
                        if len(p) > 9 and p[3] == '0A' and int(p[1].rsplit(':', 1)[1], 16) == port:
                            inodes.add('socket:[%s]' % p[9])
            except (OSError, ValueError):
                pass
        if inodes:
            for d in os.listdir('/proc'):
                if not d.isdigit():
                    continue
                try:
                    for fd in os.listdir('/proc/%s/fd' % d):
                        if os.readlink('/proc/%s/fd/%s' % (d, fd)) in inodes:
                            pids.add(int(d))
                            break
                except OSError:
                    pass
        return pids
    for line in run(['lsof', '-nP', '-t', '-iTCP:%d' % port, '-sTCP:LISTEN'])[1].split():
        if line.isdigit():
            pids.add(int(line))
    return pids


def programs():
    """Supervisor's programs, as `supervisorctl status` lists them. None without supervisor."""
    code, out = run(['supervisorctl', 'status'])
    if code == 127:
        return None
    progs = []
    for line in out.splitlines():
        m = re.match(r'^(\S+)\s+([A-Z]+)\b(.*)$', line)
        if m:
            pm = re.search(r'\bpid (\d+)', m.group(3))
            progs.append({'name': m.group(1), 'state': m.group(2), 'pid': int(pm.group(1)) if pm else 0})
    return progs


def same(a, b):
    return bool(a) and bool(b) and os.path.realpath(os.path.expanduser(a)) == os.path.realpath(os.path.expanduser(b))


def home_of(env, argv, user_home):
    """The Hermes home a process or program uses: HERMES_HOME, else a profile under ~/.hermes, else ~/.hermes."""
    if env.get('HERMES_HOME'):
        return env['HERMES_HOME']
    for i, a in enumerate(argv):
        if a in ('-p', '--profile') and i + 1 < len(argv):
            return os.path.join(user_home, '.hermes', 'profiles', argv[i + 1])
        if a.startswith('--profile='):
            return os.path.join(user_home, '.hermes', 'profiles', a.split('=', 1)[1])
    return os.path.join(user_home, '.hermes')


def configs():
    """[program:x] sections in supervisor's files: command and environment, for a program that is not running."""
    found = {}
    files = [ROOT + '/etc/supervisor/supervisord.conf', ROOT + '/etc/supervisord.conf']
    for d in (ROOT + '/etc/supervisor/conf.d', ROOT + '/etc/supervisord.d'):
        try:
            files += sorted(os.path.join(d, n) for n in os.listdir(d))
        except OSError:
            pass
    for path in files:
        try:
            with open(path, encoding='utf-8', errors='replace') as f:
                text = f.read()
        except OSError:
            continue
        name = None
        for line in text.splitlines():
            m = re.match(r'^\s*\[program:([^\]]+)\]', line)
            if m:
                name = m.group(1).strip()
                found[name] = {'command': '', 'environment': {}, 'user': ''}
                continue
            if line.strip().startswith('['):
                name = None
            if not name:
                continue
            m = re.match(r'^\s*(command|environment|user)\s*=\s*(.*)$', line)
            if m and m.group(1) == 'environment':
                for k, v in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("[^"]*"|\'[^\']*\'|[^,]*)', m.group(2)):
                    found[name]['environment'][k] = v.strip().strip('"\'')
            elif m:
                found[name][m.group(1)] = m.group(2).strip()
    return found


def this_agent(origin):
    """(program name, how it was told apart, the program's pid) for this agent, or a plain reason why not."""
    progs = programs()
    if progs is None:
        return None, 'This computer has no supervisor running its agent, so Bot HQ does not know how to restart it safely.', 0
    by_pid = {p['pid']: p for p in progs if p['pid']}
    up = parents()

    def program_of(pid):
        for _ in range(64):
            if pid in by_pid:
                return by_pid[pid]['name']
            pid = up.get(pid, 0)
            if pid <= 1:
                return None
        return None

    # 1. Whatever listens on this agent's API port.
    named = {program_of(p) for p in listeners(PORT)} - {None}
    if len(named) == 1:
        n = named.pop()
        return n, 'port', next(p['pid'] for p in progs if p['name'] == n)
    # 2. A running Hermes whose home is this agent's home.
    kids = {}
    for pid, pp in up.items():
        kids.setdefault(pp, []).append(pid)
    matched = set()
    for p in progs:
        todo = [p['pid']] if p['pid'] else []
        while todo:
            pid = todo.pop()
            argv = cmdline_of(pid)
            if any('hermes' in a.lower() for a in argv) and same(home_of(environ_of(pid), argv, HOME), H):
                matched.add(p['name'])
                break
            todo += kids.get(pid, [])
    if len(matched) == 1:
        n = matched.pop()
        return n, 'home', next(p['pid'] for p in progs if p['name'] == n)
    if len(matched) > 1:
        return None, 'More than one program on this computer runs an agent with this home (%s), so Bot HQ cannot tell which one to restart.' % ', '.join(sorted(matched)), 0
    # 3. A program that is not running: supervisor's own file says which home it runs with.
    conf = configs()
    stopped = [p['name'] for p in progs if not p['pid']]
    matched = set()
    for n in stopped:
        c = conf.get(n.split(':')[-1]) or conf.get(n)
        if not c or 'hermes' not in c['command'].lower():
            continue
        user_home = os.path.expanduser('~' + c['user']) if c['user'] else HOME
        if same(home_of(c['environment'], c['command'].split(), user_home), H):
            matched.add(n)
    if len(matched) == 1:
        return matched.pop(), 'config', 0
    # 4. On a computer Bot HQ made there is one agent: the one Hermes program supervisor runs.
    if origin == 'created':
        hermes = [p['name'] for p in progs if 'hermes' in p['name'].lower()]
        if len(hermes) == 1:
            return hermes[0], 'name', next(p['pid'] for p in progs if p['name'] == hermes[0])
    return None, 'Bot HQ could not tell which program on this computer is this agent (nothing it could match listens on port %d or uses %s), so it restarted nothing.' % (PORT, H), 0


def agentname():
    """Which supervisor program is this agent, without touching it (the setup's own restart asks this)."""
    name, how, _ = this_agent(arg(0))
    if not name:
        fail(how)
    ok({'program': name, 'how': how})


def answering(timeout=3):
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/health' % PORT, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def restart():
    name, how, _ = this_agent(arg(0))
    if not name:
        fail(how)
    code, out = run(['supervisorctl', 'restart', name], timeout=150)
    if code != 0 and 'started' not in out.lower():
        fail('Supervisor would not restart %s: %s' % (name, (out.strip().splitlines() or ['no answer'])[-1]))
    wait = int(os.environ.get('HQ_RESTART_WAIT') or 90)
    start = time.time()
    while time.time() - start < wait:
        if answering():
            ok({'program': name, 'how': how, 'seconds': round(time.time() - start)})
        time.sleep(1)
    fail('Bot HQ restarted %s, but the agent has not answered in %d seconds. It may still be starting: look at the computer’s screen, or try again in a minute.' % (name, wait))


# ---------- the desktop ----------

# hq-shell is Bot HQ's own wallpaper and dock (the deskput step below): part of the desktop, never closed.
DESKTOP = ('xfce4-panel', 'xfdesktop', 'desktop_window', 'plank', 'tint2', 'polybar', 'conky', 'lxpanel', 'pcmanfm-desktop', 'hq-shell', 'hqshell')


def windows(env):
    code, out = run(['wmctrl', '-lpx'], timeout=10, env=env)
    if code == 127:
        return None
    found = []
    for line in out.splitlines():
        p = line.split(None, 5)
        if len(p) >= 4 and p[2].lstrip('-').isdigit():
            found.append({'id': p[0], 'pid': int(p[2]), 'cls': p[3].lower(), 'title': p[5] if len(p) > 5 else ''})
    return [w for w in found if not any(d in w['cls'] for d in DESKTOP)]


def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def reset():
    origin = arg(0)
    env = dict(os.environ, DISPLAY=os.environ.get('HQ_DISPLAY') or ':99')
    wins = windows(env)
    if wins is None:
        fail('This computer has no window tool (wmctrl), so Bot HQ cannot close windows on its screen.')
    progs = programs() or []
    keep = {1, os.getpid(), os.getppid()} | {p['pid'] for p in progs if p['pid']}
    if origin == 'created':
        # A computer Bot HQ made is this Bot's alone: every app window goes, as on the shared computer.
        mine = lambda w: True
    else:
        # Someone's own computer: only windows of programs this agent started itself.
        name, how, root = this_agent(origin)
        roots = {root} if root else listeners(PORT)
        if not roots:
            fail('Bot HQ could not tell which program on this computer is this agent, so it closed nothing.')
        up = parents()
        kids = {}
        for pid, pp in up.items():
            kids.setdefault(pp, []).append(pid)
        tree, todo = set(), list(roots)
        while todo:
            pid = todo.pop()
            if pid not in tree:
                tree.add(pid)
                todo += kids.get(pid, [])
        keep |= set(roots)
        mine = lambda w: w['pid'] in tree
    targets = [w for w in wins if mine(w)]
    others = len(wins) - len(targets)
    for w in targets:
        run(['wmctrl', '-i', '-c', w['id']], timeout=5, env=env)
    end = time.time() + 3
    left = targets
    while left and time.time() < end:
        time.sleep(0.25)
        now = {w['id'] for w in (windows(env) or [])}
        left = [w for w in targets if w['id'] in now]
    for w in left:                                   # did not close when asked
        if w['pid'] > 1 and w['pid'] not in keep:
            try:
                os.kill(w['pid'], signal.SIGTERM)
            except OSError:
                pass
    if left:
        time.sleep(1.5)
        for w in left:
            if w['pid'] > 1 and w['pid'] not in keep and alive(w['pid']):
                try:
                    os.kill(w['pid'], signal.SIGKILL)
                except OSError:
                    pass
        time.sleep(0.3)
        now = {w['id'] for w in (windows(env) or [])}
        left = [w for w in left if w['id'] in now]
    ok({'closed': len(targets) - len(left), 'left': len(left), 'kept': others})


try:
    {'library': library, 'libfile': libfile, 'libput': libput, 'memories': memories, 'forget': forget, 'restart': restart, 'reset': reset, 'agentname': agentname}[STEP]()
except SystemExit:
    raise
except Exception as e:  # anything unforeseen is still said in words, not as a trace
    fail('Something went wrong on the computer (%s: %s).' % (type(e).__name__, e))
PY
    exit $?
    ;;

  # ---------- the Bot's look on this computer's desktop ----------
  # (server/src/own-desk.ts) The same scripts that dress a screen on the shared computer (hq-screen.py
  # and the rest, server/box/), kept in /opt/bothq/desk and run on the computer's own display :99:
  # a wallpaper in the Bot's color with its face, the taskbar hidden, a small dock, a light theme, and a
  # maximized Chrome of Bot HQ's own (its profile in /opt/bothq/desk/chrome) on the home page, which the
  # home screen server (127.0.0.1, a port checked free first) serves. No other Chrome is touched.
  # Every setting they change is recorded first, in /opt/bothq/desk/screens/99, and put back by deskoff,
  # which also closes that Chrome and stops the home screen server.
  #   deskput <created|adopted> <upload>
  #                                    put the scripts Bot HQ sent (in pieces, to ~/.bothq/uploads) in /opt/bothq/desk
  #   desk <created|adopted> <hq-screen.py arguments...>
  #                                    run one command of hq-screen.py there (go, wait, base); says what it answered
  #   deskcheck <created|adopted> <upload or -> <look or ->
  #                                    say what dressing would change, changing nothing: a copy of the scripts runs
  #                                    from a temporary folder (or the ones already in /opt/bothq/desk, with -)
  #   deskoff <created|adopted> <bot>  put the desktop back as it was, then delete /opt/bothq/desk
  deskput|desk|deskcheck|deskoff)
    # The system Python, where the system's GTK for Python is installed.
    py=/usr/bin/python3; [ -x "$py" ] || py="$(sys_py)"
    if [ -z "$py" ] || [ ! -x "$py" ]; then fail "This computer has no Python 3 for Bot HQ."; fi
    HQ_ROOT="$R" "$py" -I - "$step" "$@" <<'PY'
import base64, gzip, json, os, re, shutil, subprocess, sys, tempfile


def ok(obj=None):
    print('HQ-OK ' + json.dumps(obj or {}, separators=(',', ':')), flush=True)
    sys.exit(0)


def fail(msg):
    print('HQ-FAIL ' + ' '.join(str(msg).split()), flush=True)
    sys.exit(1)


def decode(x):
    try:
        return base64.b64decode(x).decode('utf-8')
    except (ValueError, UnicodeDecodeError):
        fail('Bot HQ sent something the computer could not read.')


STEP = sys.argv[1]
ARGS = [decode(x) for x in sys.argv[2:]]
arg = lambda i: ARGS[i] if len(ARGS) > i else ''
DESK = os.environ.get('HQ_ROOT', '') + '/opt/bothq/desk'
SCRIPT = DESK + '/hq-screen.py'
UPLOADS = os.path.join(os.path.expanduser('~'), '.bothq', 'uploads')
KIND = arg(0)
if KIND not in ('created', 'adopted'):
    fail('Bot HQ did not say what kind of computer this is.')


def take_upload(upload):
    """The scripts Bot HQ sent in pieces: {path: text}. The upload is deleted whatever happens."""
    if not re.match(r'^[A-Za-z0-9_-]{8,80}$', upload):
        fail('Bot HQ sent an upload it cannot use.')
    src = os.path.join(UPLOADS, upload)
    try:
        with open(src, 'rb') as f:
            files = json.loads(gzip.decompress(base64.b64decode(f.read())).decode('utf-8'))['files']
    except (OSError, ValueError, KeyError):
        fail('The desktop scripts Bot HQ sent did not arrive whole. Bot HQ tries again later.')
    finally:
        try:
            os.unlink(src)
        except OSError:
            pass
    if not isinstance(files, dict):
        fail('The desktop scripts Bot HQ sent did not arrive whole. Bot HQ tries again later.')
    return files


def unpack(files, into):
    for rel, text in files.items():
        if not isinstance(text, str) or not re.match(r'^[A-Za-z0-9_-][A-Za-z0-9_./-]*$', rel) or '..' in rel.split('/'):
            fail('Bot HQ sent a file it cannot put on the computer.')
        path = os.path.join(into, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + '.new', 'w', encoding='utf-8') as f:
            f.write(text)
        os.chmod(path + '.new', 0o755 if rel.endswith('.py') else 0o644)
        os.replace(path + '.new', path)
    src = os.path.join(into, 'ext', 'src')
    if os.path.isdir(src):
        for name in os.listdir(src):
            if 'ext/src/' + name not in files:
                os.unlink(os.path.join(src, name))


def screen(args, at=DESK, env=None, timeout=110):
    """One command of hq-screen.py: (what it answered, the rest of that line, its whole output)."""
    e = dict(os.environ, HQ_DESK_KIND=KIND, **(env or {}))
    try:
        r = subprocess.run([sys.executable, at + '/hq-screen.py'] + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           stdin=subprocess.DEVNULL, timeout=timeout, env=e)
        out = r.stdout.decode('utf-8', 'replace')
    except subprocess.TimeoutExpired:
        return None, '', 'timed out'
    except OSError as x:
        return None, '', str(x)
    for line in reversed([l.strip() for l in out.splitlines() if l.strip()]):
        m = re.match(r'^HQ_(OK|DONE|RUNNING|NOBASE|BASE_OK)\b ?(.*)$', line)
        if m:
            return m.group(1), m.group(2), out
    return None, '', out


def last_line(out):
    lines = [l.strip() for l in out.splitlines() if l.strip()]
    return lines[-1][:200] if lines else 'no answer'


if STEP == 'deskput':
    files = take_upload(arg(1))
    try:
        unpack(files, DESK)
        with open(DESK + '/place.json.new', 'w') as f:
            json.dump({'kind': KIND}, f)
        os.replace(DESK + '/place.json.new', DESK + '/place.json')
    except OSError as e:
        fail('Could not put Bot HQ’s desktop scripts in %s (%s).' % (DESK, e.strerror))
    ok({'root': DESK, 'files': len(files)})

if STEP == 'desk':
    if not os.path.isfile(SCRIPT):
        ok({'kind': 'NOBASE', 'rest': ''})
    kind, rest, out = screen(ARGS[1:])
    if kind is None:
        fail('Bot HQ’s desktop scripts on the computer did not answer as expected: %s' % last_line(out))
    ok({'kind': kind, 'rest': rest})

if STEP == 'deskcheck':
    upload, look = arg(1), arg(2) or '-'
    tmp = None
    try:
        if upload and upload != '-':
            tmp = tempfile.mkdtemp(prefix='bothq-desk-check-')
            unpack(take_upload(upload), tmp)
            at = tmp
        elif os.path.isfile(SCRIPT):
            at = DESK
        else:
            fail('Bot HQ’s desktop scripts are not on this computer yet, and none were sent to check with.')
        # The copy reads what the real folder holds, and writes nothing.
        kind, rest, out = screen(['plan', '99', look], at=at, env={'HQ_DESK_AT': DESK})
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    if kind != 'DONE':
        fail('The check did not finish on the computer: %s' % last_line(out))
    try:
        ok(json.loads(rest))
    except ValueError:
        fail('The check did not finish on the computer: %s' % rest[:200])

if STEP == 'deskoff':
    if not os.path.isfile(SCRIPT):
        if os.path.isdir(DESK):
            shutil.rmtree(DESK, ignore_errors=True)
        ok({'nothing': True})
    kind, rest, out = screen(['remove', '99', arg(1)])
    try:
        result = json.loads(rest) if kind == 'DONE' else None
    except ValueError:
        result = None
    if not result:
        fail('Bot HQ could not put the desktop back as it was: %s' % last_line(out))
    if not result.get('ok'):
        fail(result.get('error') or 'Bot HQ could not put the desktop back as it was.')
    shutil.rmtree(DESK, ignore_errors=True)
    ok({'putBack': result.get('putBack') or [], 'closed': result.get('closed') or [], 'removed': DESK})
PY
    exit $?
    ;;

  *) fail "Unknown step: $step" ;;
esac
