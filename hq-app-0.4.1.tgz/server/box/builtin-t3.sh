#!/usr/bin/env bash
# The built-in coding machine: stock T3 Code and the Bot HQ helper on this Bot HQ's own Orgo computer
# (Linux, as root), connected to Bot HQ on loopback. Bot HQ runs this itself (server/src/coding/builtin.ts),
# with what it needs in the environment:
#
#   BOTHQ_SERVER  where the helper reaches Bot HQ: http://127.0.0.1:8787
#   BOTHQ_CLAIM   a one-time machine claim (10 minutes), which the helper redeems for its own token
#   BOTHQ_NODE    the Node Bot HQ runs on (22), used for T3 Code and the helper too
#
# It says how it is going, one line at a time: "STEP <id> <what>", "OK <id>", "FAIL <id> <why>", "DONE".
#
# What it puts on the computer, all of it Bot HQ's own and nothing else touched:
#   /opt/bothq-t3/launcher      the npm package t3@0.1.9, checked against its published checksum
#   /opt/bothq-t3/bin/t3-stock  the command, with T3 Code's data in /root/.t3-stock
#   /opt/bothq-t3/tools         Codex and Claude Code, when they are not installed already (npm, in that folder)
#   supervisor programs bothq-t3 (T3 Code on 127.0.0.1:3775, or the next free port) and bothq-helper
#   /root/.bothq-helper         the helper, run every 30 seconds by its supervisor program
#
# Assumed, and not yet tried on a real Orgo computer: T3 Code's launcher (t3@0.1.9) downloads its
# Linux program (linux-x64 or linux-arm64) from T3 Code's releases on first start, as it does the Mac
# one on the fleet's Macs; T3 Code runs as root there; and supervisor runs it as Hermes is run.
#
# Every path and command can be pointed elsewhere (BUILTIN_T3_*), so server/test/machine-setup.test.ts
# runs all of this in a temporary folder with stand-ins.
set -uo pipefail
R="${BUILTIN_T3_ROOT:-}"
SERVER="${BOTHQ_SERVER:?}"; CLAIM="${BOTHQ_CLAIM:?}"; NODE="${BUILTIN_T3_NODE:-${BOTHQ_NODE:-$(command -v node)}}"
SYSPATH="${BUILTIN_T3_SYSPATH:-/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin}"
T3_VERSION=0.1.9
T3_SHA1="${BUILTIN_T3_SHA1:-aa46bf50e9483fedec9edcd7b0422a3aa5bede49}"
T3_TARBALL="${BUILTIN_T3_TARBALL:-https://registry.npmjs.org/t3/-/t3-$T3_VERSION.tgz}"
OS="${BUILTIN_T3_OS:-$(uname -s)}"; ARCH="${BUILTIN_T3_ARCH:-$(uname -m)}"
HOMEDIR="$R/root"
BASE="$R/opt/bothq-t3"
WRAP="$BASE/bin/t3-stock"
TOOLS="$BASE/tools"
T3S="$HOMEDIR/.t3-stock"
LOGS="$R/var/log/bothq-t3"
CONF="${BUILTIN_T3_SUPERVISOR_DIR:-$R/etc/supervisor/conf.d}"
SUPERVISORCTL="${BUILTIN_T3_SUPERVISORCTL:-supervisorctl}"
CURL="${BUILTIN_T3_CURL:-curl}"

step() { echo "STEP $1 $2"; }
ok() { echo "OK $1"; }
fail() { echo "FAIL $1 $2"; exit 1; }
answers() { [ "$("$CURL" -s -o /dev/null -w '%{http_code}' --max-time 5 "http://127.0.0.1:$1/" 2>/dev/null || true)" != 000 ]; }
port_free() { "$NODE" -e 'const s=require("net").connect(+process.argv[1],"127.0.0.1");s.on("connect",()=>{s.destroy();process.exit(1)});s.on("error",()=>process.exit(0))' "$1"; }
known() { "$SUPERVISORCTL" status "$1" 2>/dev/null | grep -q "^$1[[:space:]]"; }

# ---------- checks ----------
step check "Checking this computer"
[ "$OS" = Linux ] || fail check "The built-in machine needs Bot HQ's own Linux computer (this is $OS)."
case "$ARCH" in x86_64|amd64|aarch64|arm64) ;; *) fail check "T3 Code has no build for $ARCH.";; esac
[ -x "$NODE" ] || fail check "Bot HQ's Node was not found."
"$NODE" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 20 ? 0 : 1)' || fail check "Node 20 or later is needed."
command -v "$SUPERVISORCTL" >/dev/null 2>&1 || fail check "This computer has no supervisor to keep T3 Code running."
command -v tar >/dev/null 2>&1 || fail check "tar is missing."
# T3 Code and its runtime take about 0.7 GB; Codex and Claude Code a few hundred MB more.
free_kb="$(df -Pk "${R:-/}" 2>/dev/null | awk 'NR==2 {print $4}')"
[ -z "$free_kb" ] || [ "$free_kb" -ge "${BUILTIN_T3_MIN_KB:-2000000}" ] || fail check "Not enough free disk: T3 Code and the tools need about 2 GB."
ok check

# ---------- T3 Code ----------
step t3 "Installing T3 Code $T3_VERSION (its first start downloads about 350 MB)"
mkdir -p "$BASE/bin" "$T3S/workdir" "$LOGS"
if [ ! -f "$BASE/launcher/package.json" ]; then
  tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
  "$CURL" -fsSL "$T3_TARBALL" -o "$tmp/t3.tgz" || fail t3 "Could not download T3 Code."
  sum="$( (command -v sha1sum >/dev/null && sha1sum "$tmp/t3.tgz" || shasum -a 1 "$tmp/t3.tgz") | cut -d' ' -f1)"
  [ "$sum" = "$T3_SHA1" ] || fail t3 "The T3 Code download did not match its published checksum, so it was not installed."
  tar -xzf "$tmp/t3.tgz" -C "$tmp" || fail t3 "Could not unpack T3 Code."
  mv "$tmp/package" "$BASE/launcher" || fail t3 "Could not put T3 Code in place."
fi
cat > "$WRAP" <<EOF
#!/bin/sh
# Stock T3 Code for Bot HQ's built-in machine, with its data in $T3S.
export T3CODE_HOME="$T3S"
exec "$NODE" "$BASE/launcher/bin/t3.mjs" "\$@"
EOF
chmod 755 "$WRAP"
HOME="$HOMEDIR" "$WRAP" --version >/dev/null 2>&1 || fail t3 "T3 Code did not start (its download from T3 Code's releases may have failed). Try again."
ok t3

# ---------- Codex and Claude Code ----------
if [ "${BUILTIN_T3_NO_TOOLS:-}" != 1 ]; then
  step tools "Installing Codex and Claude Code"
  want=""
  command -v codex >/dev/null 2>&1 || [ -x "$TOOLS/node_modules/.bin/codex" ] || want="$want @openai/codex"
  command -v claude >/dev/null 2>&1 || [ -x "$TOOLS/node_modules/.bin/claude" ] || want="$want @anthropic-ai/claude-code"
  if [ -n "$want" ]; then
    mkdir -p "$TOOLS"
    # shellcheck disable=SC2086
    PATH="$(dirname "$NODE"):$PATH" "$(dirname "$NODE")/npm" install --prefix "$TOOLS" --no-fund --no-audit $want >"$LOGS/tools.log" 2>&1 \
      || echo "Codex or Claude Code could not be installed (see $LOGS/tools.log); coding Bots need one of them."
  fi
  ok tools
fi

# ---------- T3 Code under supervisor ----------
step service "Starting T3 Code"
port="${BUILTIN_T3_PORT:-}"
if [ -z "$port" ] && [ -f "$CONF/bothq-t3.conf" ]; then port="$(sed -n 's/.*--port \([0-9]*\).*/\1/p' "$CONF/bothq-t3.conf" | head -1)"; fi
if [ -z "$port" ]; then for p in $(seq 3775 3799); do port_free "$p" && { port="$p"; break; }; done; fi
[ -n "$port" ] || fail service "No free port for T3 Code between 3775 and 3799."
path="$TOOLS/node_modules/.bin:$BASE/bin:$(dirname "$NODE"):$SYSPATH"
mkdir -p "$CONF"
cat > "$CONF/bothq-t3.conf" <<EOF
; Bot HQ's built-in coding machine: stock T3 Code, on loopback only.
[program:bothq-t3]
command=$WRAP serve --host 127.0.0.1 --port $port --base-dir $T3S --no-browser $T3S/workdir
directory=$T3S/workdir
environment=HOME="$HOMEDIR",T3CODE_HOME="$T3S",PATH="$path"
autostart=true
autorestart=true
startsecs=5
stopasgroup=true
killasgroup=true
stdout_logfile=$LOGS/t3.log
stdout_logfile_maxbytes=5MB
redirect_stderr=true
EOF
"$SUPERVISORCTL" reread >/dev/null 2>&1
if known bothq-t3; then "$SUPERVISORCTL" update bothq-t3 >/dev/null 2>&1; "$SUPERVISORCTL" restart bothq-t3 >/dev/null 2>&1
else "$SUPERVISORCTL" add bothq-t3 >/dev/null 2>&1 || fail service "Supervisor would not start T3 Code. Its log: $LOGS/t3.log"; fi
for _ in $(seq 1 "${BUILTIN_T3_WAIT:-120}"); do answers "$port" && [ -s "$T3S/userdata/environment-id" ] && break; sleep 1; done
answers "$port" || fail service "T3 Code does not answer on 127.0.0.1:$port. Its log: $LOGS/t3.log"
ok service

# ---------- the helper ----------
step helper "Installing the Bot HQ helper and connecting the machine"
"$CURL" -fsSL "$SERVER/fleet/install.sh" -o "$BASE/install.sh" || fail helper "Could not fetch the helper's installer from Bot HQ."
HOME="$HOMEDIR" PATH="$path" BOTHQ_HELPER_NO_SCHEDULE=1 bash "$BASE/install.sh" --server "$SERVER" --claim "$CLAIM" --t3 "$WRAP" --t3-home "$T3S" --base-url "http://127.0.0.1:$port" --name "Built-in" >"$LOGS/helper-install.log" 2>&1 \
  || fail helper "The helper did not join: $(tail -2 "$LOGS/helper-install.log" | tr '\n' ' ')"
# Every 30 seconds, as on a machine; supervisor stands in for the system's schedule here.
cat > "$CONF/bothq-helper.conf" <<EOF
; Bot HQ's helper for its built-in coding machine: one round every 30 seconds.
[program:bothq-helper]
command=/bin/sh -c 'while :; do "$NODE" "$HOMEDIR/.bothq-helper/helper.mjs" --scheduled; sleep 30; done'
environment=HOME="$HOMEDIR",PATH="$path",BOTHQ_HELPER_NO_SCHEDULE="1"
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stdout_logfile=$HOMEDIR/.bothq-helper/helper.log
stdout_logfile_maxbytes=2MB
redirect_stderr=true
EOF
"$SUPERVISORCTL" reread >/dev/null 2>&1
if known bothq-helper; then "$SUPERVISORCTL" update bothq-helper >/dev/null 2>&1; else "$SUPERVISORCTL" add bothq-helper >/dev/null 2>&1 || fail helper "Supervisor would not start the helper."; fi
ok helper
echo "DONE"
