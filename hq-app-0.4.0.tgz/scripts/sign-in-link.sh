#!/usr/bin/env bash
# Print a link that signs one browser in to the app, once, within 15 minutes. Run ON the computer, as root.
#   bash sign-in-link.sh you@example.com [--setup]
# For when Google sign-in is not set up or not working. The address must already have an account, or
# be invited (or in ALLOWED_EMAILS). Nobody can sign in this way before the owner exists: a fresh
# Bot HQ is set up with setup-link.sh. With --setup, the link goes on to the rest of the setup wizard
# (for an owner the installer made in the terminal). The key it uses never leaves this machine.
set -euo pipefail
email="${1:?usage: sign-in-link.sh <email> [--setup]}"
then=""; [ "${2:-}" != "--setup" ] || then="?then=setup"
ENV_FILE="${ENV_FILE:-/opt/hq/app/.env}"
val() { grep -E "^$1=" "$ENV_FILE" | tail -1 | cut -d= -f2-; }
key="$(printf 'owner-login' | openssl dgst -sha256 -hmac "$(val SESSION_SECRET)" -r | cut -d' ' -f1)"
url="$(curl -fsS -X POST "http://127.0.0.1:$(val PORT)/api/auth/owner" \
  -H "authorization: Bearer $key" -H 'content-type: application/json' \
  -d "{\"email\":\"$email\",\"link\":true}" | sed -E 's/.*"url":"([^"]+)".*/\1/')"
echo "$url$then"
