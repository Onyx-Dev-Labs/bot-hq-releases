#!/usr/bin/env bash
# Print the link that opens the setup wizard on a fresh Bot HQ. Run ON the computer, as root.
#   bash setup-link.sh
# The code in it is derived from the app's session secret, which never leaves this machine. The link
# works until the owner's account exists; after that, sign in instead.
set -euo pipefail
ENV_FILE="${ENV_FILE:-/opt/hq/app/.env}"
val() { { grep -E "^$1=" "$ENV_FILE" 2>/dev/null || true; } | tail -1 | cut -d= -f2-; }
secret="$(val SESSION_SECRET)"
if [ -z "$secret" ]; then
  # No SESSION_SECRET in the settings file: the app made its own, beside the database.
  db="$(val DB_PATH)"; secret="$(cat "$(dirname "${db:-/opt/hq/data/hq.db}")/session.secret" 2>/dev/null || true)"
fi
[ -n "$secret" ] || { echo "No session secret found. Start the app once, then run this again." >&2; exit 1; }
h="$(printf 'setup-code' | openssl dgst -sha256 -hmac "$secret" -r | cut -c1-16 | tr 'a-f' 'A-F')"
code="${h:0:4}-${h:4:4}-${h:8:4}-${h:12:4}"
url="$(val APP_URL)"
echo "Setup code: $code"
echo "Setup link: ${url:-http://localhost:8787}/?setup=$code"
